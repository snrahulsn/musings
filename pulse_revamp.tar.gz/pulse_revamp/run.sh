#!/bin/bash

# Workflow Analytics App - Comprehensive Run Script
# This script handles ALL setup and startup automatically

set -e  # Exit on error

echo "🚀 Starting Workflow Analytics App..."
echo ""

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Function to print colored messages
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Function to cleanup on exit
cleanup() {
    echo ""
    echo "🛑 Stopping services..."

    # Kill processes if they exist
    [ ! -z "$FLASK_PID" ] && kill $FLASK_PID 2>/dev/null && echo "  Stopped Flask API"
    [ ! -z "$DASHBOARD_PID" ] && kill $DASHBOARD_PID 2>/dev/null && echo "  Stopped Dashboard"
    [ ! -z "$CHAT_PID" ] && kill $CHAT_PID 2>/dev/null && echo "  Stopped Chat"

    # Kill any remaining Python processes for this app
    pkill -f "streamlit run app/ui" 2>/dev/null || true
    pkill -f "app/api/routes.py" 2>/dev/null || true

    print_success "All services stopped"
    exit 0
}

# Trap Ctrl+C and errors
trap cleanup INT TERM

# 1. Check if Python 3 is installed
echo "🔍 Checking prerequisites..."
if ! command -v python3 &> /dev/null; then
    print_error "Python 3 is not installed. Please install Python 3.10 or higher."
    exit 1
fi
PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
print_success "Python $PYTHON_VERSION found"

# 2. Check if Docker is installed and running
if ! command -v docker &> /dev/null; then
    print_error "Docker is not installed. Please install Docker Desktop."
    exit 1
fi

if ! docker info &> /dev/null; then
    print_error "Docker is not running. Please start Docker Desktop."
    exit 1
fi
print_success "Docker is running"

# 3. Check/Create virtual environment
if [ ! -d "venv" ]; then
    print_warning "Virtual environment not found. Creating..."
    python3 -m venv venv
    print_success "Virtual environment created"
else
    print_success "Virtual environment exists"
fi

# 4. Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate || {
    print_error "Failed to activate virtual environment"
    exit 1
}
print_success "Virtual environment activated"

# 5. Check/Install dependencies
echo "📦 Checking dependencies..."
if ! python -c "import flask" 2>/dev/null; then
    print_warning "Dependencies not installed. Installing from requirements.txt..."
    pip install --quiet --upgrade pip
    pip install --quiet -r requirements.txt
    print_success "Dependencies installed"
else
    print_success "Dependencies already installed"
fi

# 6. Check/Create .env file
if [ ! -f .env ]; then
    print_warning ".env file not found. Copying from .env.example..."
    cp .env.example .env
    print_warning "⚠️  IMPORTANT: Edit .env and add your LLM_API_KEY!"
    echo ""
    echo "Press Enter after you've updated .env, or Ctrl+C to exit and do it later..."
    read -r
fi
print_success ".env file exists"

# 7. Create necessary directories
mkdir -p data logs
print_success "Directories created"

# 8. Check/Start PostgreSQL
echo "🐘 Checking PostgreSQL..."
if ! docker-compose ps | grep -q "workflow-analytics-db.*Up"; then
    print_warning "PostgreSQL not running. Starting..."
    docker-compose up -d
    echo "⏳ Waiting for PostgreSQL to be ready..."

    # Wait for PostgreSQL to be healthy
    for i in {1..30}; do
        if docker-compose exec -T postgres pg_isready -U workflow_user &>/dev/null; then
            break
        fi
        sleep 1
        echo -n "."
    done
    echo ""
    print_success "PostgreSQL started"
else
    print_success "PostgreSQL is running"
fi

# 9. Initialize database
echo "🗄️  Initializing database..."
if python init_db.py; then
    print_success "Database initialized"
else
    print_warning "Database might already be initialized"
fi

# 10. Check for port conflicts
echo "🔌 Checking ports..."
check_port() {
    if lsof -Pi :$1 -sTCP:LISTEN -t >/dev/null 2>&1; then
        print_warning "Port $1 is already in use. Attempting to free it..."
        lsof -ti:$1 | xargs kill -9 2>/dev/null || true
        sleep 1
    fi
}

check_port 5000
check_port 8501
check_port 8502
print_success "Ports are available"

echo ""
echo "═══════════════════════════════════════════════════════════"
print_success "Setup complete! Starting services..."
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "📍 Services will be available at:"
echo "   - Flask API:     http://localhost:5000"
echo "   - Dashboard:     http://localhost:8501"
echo "   - Chat:          http://localhost:8502"
echo ""
echo "📝 Logs will be saved to: logs/app.log"
echo ""
echo "Press Ctrl+C to stop all services"
echo ""
echo "═══════════════════════════════════════════════════════════"
echo ""

# Start Flask API in background
echo "🔧 Starting Flask API..."
python app/api/routes.py > logs/flask.log 2>&1 &
FLASK_PID=$!
sleep 2

# Check if Flask started successfully
if kill -0 $FLASK_PID 2>/dev/null; then
    print_success "Flask API started (PID: $FLASK_PID)"
else
    print_error "Failed to start Flask API. Check logs/flask.log"
    exit 1
fi

# Start Streamlit Dashboard
echo "📊 Starting Dashboard..."
streamlit run app/ui/dashboard.py \
    --server.port 8501 \
    --server.headless true \
    --browser.gatherUsageStats false \
    --server.fileWatcherType none \
    > logs/dashboard.log 2>&1 &
DASHBOARD_PID=$!
sleep 2

if kill -0 $DASHBOARD_PID 2>/dev/null; then
    print_success "Dashboard started (PID: $DASHBOARD_PID)"
else
    print_error "Failed to start Dashboard. Check logs/dashboard.log"
    cleanup
    exit 1
fi

# Start Streamlit Chat
echo "💬 Starting Chat Interface..."
streamlit run app/ui/chat.py \
    --server.port 8502 \
    --server.headless true \
    --browser.gatherUsageStats false \
    --server.fileWatcherType none \
    > logs/chat.log 2>&1 &
CHAT_PID=$!
sleep 2

if kill -0 $CHAT_PID 2>/dev/null; then
    print_success "Chat Interface started (PID: $CHAT_PID)"
else
    print_error "Failed to start Chat Interface. Check logs/chat.log"
    cleanup
    exit 1
fi

echo ""
echo "═══════════════════════════════════════════════════════════"
print_success "All services are running!"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "🌐 Open in your browser:"
echo "   Dashboard: http://localhost:8501"
echo "   Chat:      http://localhost:8502"
echo ""
echo "📊 Check service health:"
echo "   curl http://localhost:5000/health"
echo ""
echo "📋 View logs:"
echo "   tail -f logs/flask.log"
echo "   tail -f logs/dashboard.log"
echo "   tail -f logs/chat.log"
echo ""
echo "🛑 To stop: Press Ctrl+C"
echo ""

# Keep script running and wait for processes
wait
