"""Tests for database models"""

import pytest
from datetime import datetime
from app.models import Team, Member, Commit


def test_team_creation():
    """Test team model creation"""
    team = Team(name="Engineering", type="engineering")
    assert team.name == "Engineering"
    assert team.type == "engineering"


def test_member_creation():
    """Test member model creation"""
    member = Member(
        name="John Doe",
        email="john@example.com",
        team_id=1,
        role="Developer"
    )
    assert member.name == "John Doe"
    assert member.email == "john@example.com"


def test_commit_creation():
    """Test commit model creation"""
    commit = Commit(
        sha="abc123",
        author_id=1,
        repo="test-repo",
        message="Test commit",
        additions=10,
        deletions=5,
        timestamp=datetime.now()
    )
    assert commit.sha == "abc123"
    assert commit.additions == 10
