#!/usr/bin/env python
"""Database initialization script"""

from app.models import init_db
from app.config import get_config

if __name__ == "__main__":
    config = get_config()
    config.ensure_directories()

    print("Initializing database...")
    print(f"Database URL: {config.DATABASE_URL}")

    try:
        init_db()
        print("✅ Database initialized successfully!")
    except Exception as e:
        print(f"❌ Error initializing database: {e}")
        exit(1)
