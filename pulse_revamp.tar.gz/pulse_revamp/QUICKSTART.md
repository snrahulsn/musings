# Quick Start Guide

Get the Workflow Analytics App running in **1 command**!

## Prerequisites

✅ Python 3.10+ installed
✅ Docker Desktop installed and running
✅ Terminal/Command Line access

## 🚀 Fastest Way to Start

### Step 1: Run the Script

```bash
./run.sh
```

**That's literally it!** The script handles everything:
- Checks Python and Docker
- Creates virtual environment
- Installs all dependencies
- Starts PostgreSQL
- Initializes database
- Launches all 3 services

### Step 2: Configure API Key (First Time Only)

When prompted, edit `.env` and add your LLM API key:

```bash
LLM_API_KEY=your-actual-api-key-here
```

Then press Enter to continue.

### Step 3: Open Your Browser

- **Dashboard**: http://localhost:8501
- **Chat**: http://localhost:8502

## 🛑 Stop Everything

```bash
./stop.sh
```

Or just press `Ctrl+C` in the terminal running the app.

---

## What the Run Script Does

The `run.sh` script is **comprehensive** and handles:

1. ✅ **Prerequisites Check**
   - Verifies Python 3.10+ is installed
   - Checks Docker is running
   - Shows helpful error messages if missing

2. ✅ **Environment Setup**
   - Creates `venv/` if it doesn't exist
   - Activates virtual environment automatically
   - Installs/updates dependencies from `requirements.txt`
   - Creates `.env` from template if needed

3. ✅ **Database Setup**
   - Starts PostgreSQL container via Docker Compose
   - Waits for database to be healthy
   - Initializes database schema

4. ✅ **Port Management**
   - Checks if ports 5000, 8501, 8502 are available
   - Frees up ports if they're occupied

5. ✅ **Service Launch**
   - Starts Flask API (backend)
   - Starts Streamlit Dashboard
   - Starts Streamlit Chat
   - Verifies each service started successfully

6. ✅ **Monitoring**
   - Logs output to `logs/` directory
   - Shows service status and URLs
   - Provides helpful commands for debugging

7. ✅ **Cleanup**
   - Gracefully stops all services on Ctrl+C
   - Ensures no orphaned processes

## Troubleshooting

### "Docker is not running"
Start Docker Desktop and try again.

### "Port already in use"
The script automatically kills processes on ports 5000, 8501, 8502. If issues persist:
```bash
./stop.sh
./run.sh
```

### "Failed to start Flask API"
Check the logs:
```bash
cat logs/flask.log
```

### Dependencies installation is slow
This is normal the first time. Subsequent runs are instant.

---

## Advanced: Manual Control

If you prefer manual control:

```bash
# Just start PostgreSQL
docker-compose up -d

# Just initialize database
python init_db.py

# Start services individually
python app/api/routes.py                    # Terminal 1
streamlit run app/ui/dashboard.py           # Terminal 2
streamlit run app/ui/chat.py --server.port 8502  # Terminal 3
```

---

## Add Sample Data (Optional)

To test with sample data:

```python
python3

from app.models import get_db, Team, Member, Commit
from datetime import datetime, timedelta
import random

db = next(get_db())

# Create team
team = Team(name="Engineering", type="engineering")
db.add(team)
db.commit()

# Create members
members = []
for name in ["Alice", "Bob", "Charlie", "Diana"]:
    member = Member(
        name=f"{name} Developer",
        email=f"{name.lower()}@example.com",
        team_id=team.id,
        role="Developer"
    )
    db.add(member)
    members.append(member)
db.commit()

# Create commits
base_date = datetime.now() - timedelta(days=30)
for i in range(100):
    commit = Commit(
        sha=f"abc{i:04d}",
        author_id=random.choice(members).id,
        repo="main-app",
        message=f"Feature update {i}",
        additions=random.randint(10, 100),
        deletions=random.randint(1, 20),
        timestamp=base_date + timedelta(hours=i*3)
    )
    db.add(commit)

db.commit()
print(f"✅ Created {len(members)} members and 100 commits!")
```

---

## Verify Everything Works

### 1. Check API Health
```bash
curl http://localhost:5000/health
```

Should return:
```json
{"status": "healthy", "timestamp": "..."}
```

### 2. Check Dashboard
Visit http://localhost:8501 - you should see the dashboard with filters.

### 3. Check Chat
Visit http://localhost:8502 - you should see the chat interface.

---

## View Logs

All services log to `logs/` directory:

```bash
# Watch Flask API logs
tail -f logs/flask.log

# Watch Dashboard logs
tail -f logs/dashboard.log

# Watch Chat logs
tail -f logs/chat.log
```

---

## What's Next?

1. ✅ **App is running!**
2. 📊 **Add sample data** (see above)
3. 💬 **Try the chat interface** (though Text-to-SQL needs LLM implementation)
4. 📈 **Explore the dashboard**
5. 🔌 **Set up data sources** (Phase 2 - see ROADMAP.md)

---

## Full Documentation

- [README.md](README.md) - Complete project documentation
- [ROADMAP.md](ROADMAP.md) - Development phases and timeline
- [PROJECT_STATUS.md](PROJECT_STATUS.md) - What's done and what's next

---

## The Magic of `run.sh`

**Before (old way):**
```bash
# User had to do all this manually:
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit .env manually
docker-compose up -d
python init_db.py
# open 3 terminals
python app/api/routes.py
streamlit run app/ui/dashboard.py
streamlit run app/ui/chat.py --server.port 8502
```

**After (new way):**
```bash
./run.sh
# Done! 🎉
```

**That's the difference!** The script handles everything automatically, with clear feedback and error messages.

---

Happy analyzing! 📊✨
