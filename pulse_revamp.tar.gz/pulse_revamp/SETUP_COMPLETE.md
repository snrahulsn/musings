# Setup Complete - Workflow Analytics App

## ✅ What's Working

### 1. PostgreSQL Database
- **Status**: Running on port 5433
- **Container**: workflow-analytics-db
- **Database**: workflow_analytics
- **All tables created**: teams, members, commits, pull_requests, issues, tasks, deals, insights, metrics

**Verify**:
```bash
docker-compose ps
```

### 2. Flask API
- **Status**: Running on port 5001
- **Health endpoint**: http://localhost:5001/health
- **All endpoints functional**

**Verify**:
```bash
curl http://localhost:5001/health
```

### 3. Database Schema
- All models created successfully
- Foreign keys and relationships configured
- Ready to accept data

## 📝 Key Changes Made

1. **Fixed Meltano dependency** - Commented out incompatible version
2. **Changed PostgreSQL port** - Using 5433 instead of 5432 (port conflict)
3. **Changed Flask port** - Using 5001 instead of 5000 (AirPlay conflict)
4. **Fixed reserved keyword** - Changed `metadata` columns to `extra_data`
5. **Created startup script** - `start_flask.sh` for easy Flask launch

## 🚀 How to Start Everything

### Quick Start
```bash
# 1. Start PostgreSQL (if not running)
docker-compose up -d

# 2. Start Flask API
./start_flask.sh &

# 3. For Streamlit (install dependencies first)
source venv/bin/activate
pip install streamlit plotly pandas requests

# Then start dashboard
streamlit run app/ui/dashboard.py

# And chat (in another terminal)
streamlit run app/ui/chat.py --server.port 8502
```

## 📊 Testing the Setup

### Test 1: Database Connection
```bash
source venv/bin/activate
python -c "from app.models import get_db; db = next(get_db()); print('✅ Database connected')"
```

### Test 2: API Health
```bash
curl http://localhost:5001/health
# Should return: {"status": "healthy", "timestamp": "..."}
```

### Test 3: API Endpoints
```bash
# Get teams
curl http://localhost:5001/api/teams

# Get members
curl http://localhost:5001/api/members

# Get metrics
curl http://localhost:5001/api/metrics
```

## 🐛 Known Issues & Solutions

### Issue 1: "metadata is reserved"
**Fixed** - All `metadata` columns renamed to `extra_data`

### Issue 2: Port 5432 in use
**Fixed** - PostgreSQL now on port 5433

### Issue 3: Port 5000 in use (AirPlay)
**Fixed** - Flask now on port 5001

### Issue 4: ModuleNotFoundError for 'app'
**Fixed** - Use `start_flask.sh` which sets PYTHONPATH

## 📁 Configuration Files

### .env
```bash
DATABASE_URL=postgresql://workflow_user:workflow_pass@localhost:5433/workflow_analytics
APP_PORT=5001
LLM_API_KEY=your-api-key-here
```

### docker-compose.yml
- PostgreSQL 16-alpine
- Port: 5433:5432
- Volume: postgres_data

## 🔧 Useful Commands

```bash
# View Flask logs
tail -f logs/flask.log

# Stop Flask
pkill -f "app/api/routes.py"

# Stop PostgreSQL
docker-compose down

# Restart PostgreSQL
docker-compose restart

# View database tables
docker exec -it workflow-analytics-db psql -U workflow_user -d workflow_analytics -c "\dt"
```

## 📦 Installed Dependencies

Core packages installed:
- flask + flask-cors
- sqlalchemy
- psycopg2-binary
- python-dotenv

**Still need to install for Streamlit**:
```bash
pip install streamlit plotly pandas requests
```

## ✨ Next Steps

1. **Install Streamlit dependencies**:
   ```bash
   source venv/bin/activate
   pip install streamlit plotly pandas requests
   ```

2. **Start Streamlit interfaces**:
   ```bash
   streamlit run app/ui/dashboard.py
   streamlit run app/ui/chat.py --server.port 8502
   ```

3. **Add sample data** (optional):
   ```python
   from app.models import get_db, Team, Member
   db = next(get_db())
   team = Team(name="Engineering", type="engineering")
   db.add(team)
   db.commit()
   ```

4. **Implement Text-to-SQL** with LangChain + LLM

5. **Set up ETL pipelines** with Meltano for data sources

## 🎯 Summary

**Status**: Foundation is complete and functional!

- ✅ PostgreSQL running
- ✅ Database schema created
- ✅ Flask API running and tested
- ⏳ Streamlit UIs ready (need dependency install)
- ⏳ LLM integration pending
- ⏳ ETL pipelines pending

The core infrastructure is solid. You can now:
1. Use the API endpoints
2. Insert data into the database
3. Install Streamlit deps and run the UIs
4. Implement the LLM features
5. Add data sources via ETL

**Everything is ready for the next development phase!**
