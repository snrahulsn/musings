#!/bin/bash

# Workflow Analytics App - Stop Script
# This script stops all running services

echo "🛑 Stopping Workflow Analytics App..."

# Kill Flask API
pkill -f "app/api/routes.py" 2>/dev/null && echo "✅ Stopped Flask API" || echo "ℹ️  Flask API not running"

# Kill Streamlit processes
pkill -f "streamlit run app/ui/dashboard.py" 2>/dev/null && echo "✅ Stopped Dashboard" || echo "ℹ️  Dashboard not running"
pkill -f "streamlit run app/ui/chat.py" 2>/dev/null && echo "✅ Stopped Chat Interface" || echo "ℹ️  Chat Interface not running"

# Stop PostgreSQL (optional - uncomment if you want to stop the database too)
# docker-compose down && echo "✅ Stopped PostgreSQL" || echo "ℹ️  PostgreSQL not running"

echo ""
echo "✅ All services stopped"
