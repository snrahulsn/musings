#!/bin/bash
cd /Users/rahulnatarajan/Documents/pulse_revamp
source venv/bin/activate
export PYTHONPATH=/Users/rahulnatarajan/Documents/pulse_revamp
export APP_PORT=5001
export DATABASE_URL="postgresql://workflow_user:workflow_pass@localhost:5433/workflow_analytics"
python app/api/routes.py
