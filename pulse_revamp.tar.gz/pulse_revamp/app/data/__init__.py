"""Data processing module"""
