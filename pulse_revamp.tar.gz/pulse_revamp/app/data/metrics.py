"""Metrics calculation module"""

from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import pandas as pd
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models import Commit, PullRequest, Issue, Task, Deal, Member, Team, Metric
import logging

logger = logging.getLogger(__name__)


class MetricsCalculator:
    """Calculate KPIs and metrics from raw data"""

    def __init__(self, db: Session):
        self.db = db

    def calculate_commit_velocity(
        self,
        start_date: datetime,
        end_date: datetime,
        team_id: Optional[int] = None,
        member_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """Calculate commit velocity (commits per week)"""
        query = self.db.query(Commit).filter(
            Commit.timestamp >= start_date,
            Commit.timestamp <= end_date
        )

        if member_id:
            query = query.filter(Commit.author_id == member_id)
        elif team_id:
            query = query.join(Member).filter(Member.team_id == team_id)

        commits = query.all()

        if not commits:
            return {
                "total_commits": 0,
                "commits_per_week": 0,
                "avg_additions": 0,
                "avg_deletions": 0
            }

        # Convert to DataFrame for analysis
        df = pd.DataFrame([{
            "timestamp": c.timestamp,
            "additions": c.additions,
            "deletions": c.deletions
        } for c in commits])

        weeks = (end_date - start_date).days / 7
        weeks = max(weeks, 1)  # Avoid division by zero

        return {
            "total_commits": len(commits),
            "commits_per_week": len(commits) / weeks,
            "avg_additions": df['additions'].mean(),
            "avg_deletions": df['deletions'].mean(),
            "total_lines_changed": df['additions'].sum() + df['deletions'].sum()
        }

    def calculate_pr_metrics(
        self,
        start_date: datetime,
        end_date: datetime,
        team_id: Optional[int] = None,
        member_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """Calculate pull request metrics"""
        query = self.db.query(PullRequest).filter(
            PullRequest.created_at >= start_date,
            PullRequest.created_at <= end_date
        )

        if member_id:
            query = query.filter(PullRequest.author_id == member_id)
        elif team_id:
            query = query.join(Member).filter(Member.team_id == team_id)

        prs = query.all()

        if not prs:
            return {
                "total_prs": 0,
                "merged_prs": 0,
                "avg_merge_time_hours": 0,
                "merge_rate": 0
            }

        merged_prs = [pr for pr in prs if pr.merged_at is not None]

        # Calculate merge times
        merge_times = []
        for pr in merged_prs:
            if pr.merged_at and pr.created_at:
                delta = (pr.merged_at - pr.created_at).total_seconds() / 3600
                merge_times.append(delta)

        return {
            "total_prs": len(prs),
            "merged_prs": len(merged_prs),
            "open_prs": len([pr for pr in prs if pr.state == 'open']),
            "avg_merge_time_hours": sum(merge_times) / len(merge_times) if merge_times else 0,
            "merge_rate": len(merged_prs) / len(prs) if prs else 0
        }

    def calculate_issue_metrics(
        self,
        start_date: datetime,
        end_date: datetime,
        team_id: Optional[int] = None,
        member_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """Calculate issue tracking metrics"""
        query = self.db.query(Issue).filter(
            Issue.created_at >= start_date,
            Issue.created_at <= end_date
        )

        if member_id:
            query = query.filter(Issue.assignee_id == member_id)
        elif team_id:
            query = query.join(Member).filter(Member.team_id == team_id)

        issues = query.all()

        if not issues:
            return {
                "total_issues": 0,
                "resolved_issues": 0,
                "avg_resolution_time_hours": 0,
                "bugs_count": 0
            }

        resolved_issues = [i for i in issues if i.resolved_at is not None]
        bugs = [i for i in issues if i.issue_type == 'bug']

        # Calculate resolution times
        resolution_times = []
        for issue in resolved_issues:
            if issue.resolved_at and issue.created_at:
                delta = (issue.resolved_at - issue.created_at).total_seconds() / 3600
                resolution_times.append(delta)

        return {
            "total_issues": len(issues),
            "resolved_issues": len(resolved_issues),
            "open_issues": len([i for i in issues if not i.resolved_at]),
            "bugs_count": len(bugs),
            "avg_resolution_time_hours": sum(resolution_times) / len(resolution_times) if resolution_times else 0,
            "resolution_rate": len(resolved_issues) / len(issues) if issues else 0
        }

    def calculate_task_completion(
        self,
        start_date: datetime,
        end_date: datetime,
        team_id: Optional[int] = None,
        member_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """Calculate task completion metrics"""
        query = self.db.query(Task).filter(
            Task.created_at >= start_date,
            Task.created_at <= end_date
        )

        if member_id:
            query = query.filter(Task.assignee_id == member_id)
        elif team_id:
            query = query.join(Member).filter(Member.team_id == team_id)

        tasks = query.all()

        if not tasks:
            return {
                "total_tasks": 0,
                "completed_tasks": 0,
                "completion_rate": 0
            }

        completed_tasks = [t for t in tasks if t.completed_at is not None]

        return {
            "total_tasks": len(tasks),
            "completed_tasks": len(completed_tasks),
            "pending_tasks": len([t for t in tasks if not t.completed_at]),
            "completion_rate": len(completed_tasks) / len(tasks) if tasks else 0
        }

    def calculate_sales_metrics(
        self,
        start_date: datetime,
        end_date: datetime,
        team_id: Optional[int] = None,
        member_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """Calculate sales/deal metrics"""
        query = self.db.query(Deal).filter(
            Deal.created_at >= start_date,
            Deal.created_at <= end_date
        )

        if member_id:
            query = query.filter(Deal.owner_id == member_id)
        elif team_id:
            query = query.join(Member).filter(Member.team_id == team_id)

        deals = query.all()

        if not deals:
            return {
                "total_deals": 0,
                "closed_deals": 0,
                "total_value": 0,
                "avg_deal_value": 0
            }

        closed_deals = [d for d in deals if d.closed_at is not None]
        closed_value = sum(d.value for d in closed_deals if d.value)

        return {
            "total_deals": len(deals),
            "closed_deals": len(closed_deals),
            "open_deals": len([d for d in deals if not d.closed_at]),
            "total_value": closed_value,
            "avg_deal_value": closed_value / len(closed_deals) if closed_deals else 0,
            "close_rate": len(closed_deals) / len(deals) if deals else 0
        }

    def calculate_team_metrics(
        self,
        team_id: int,
        start_date: datetime,
        end_date: datetime
    ) -> Dict[str, Any]:
        """Calculate comprehensive team metrics"""
        team = self.db.query(Team).filter(Team.id == team_id).first()
        if not team:
            raise ValueError(f"Team {team_id} not found")

        metrics = {
            "team_id": team_id,
            "team_name": team.name,
            "team_type": team.type,
            "period_start": start_date.isoformat(),
            "period_end": end_date.isoformat()
        }

        # Calculate based on team type
        if team.type in ['engineering', 'development']:
            metrics.update({
                "commits": self.calculate_commit_velocity(start_date, end_date, team_id=team_id),
                "pull_requests": self.calculate_pr_metrics(start_date, end_date, team_id=team_id),
                "issues": self.calculate_issue_metrics(start_date, end_date, team_id=team_id)
            })
        elif team.type == 'sales':
            metrics.update({
                "deals": self.calculate_sales_metrics(start_date, end_date, team_id=team_id)
            })
        else:
            # General teams get task metrics
            metrics.update({
                "tasks": self.calculate_task_completion(start_date, end_date, team_id=team_id)
            })

        return metrics

    def store_metrics(
        self,
        metric_name: str,
        metric_type: str,
        value: float,
        entity_type: str,
        entity_id: int,
        period_start: datetime,
        period_end: datetime,
        metadata: Optional[Dict] = None
    ):
        """Store computed metric in database"""
        metric = Metric(
            metric_name=metric_name,
            metric_type=metric_type,
            value=value,
            entity_type=entity_type,
            entity_id=entity_id,
            period_start=period_start,
            period_end=period_end,
            metadata=metadata
        )

        self.db.add(metric)
        self.db.commit()
        logger.info(f"Stored metric: {metric_name} for {entity_type} {entity_id}")


def compute_all_metrics(db: Session, days_back: int = 30):
    """Compute and store all metrics for recent period"""
    calculator = MetricsCalculator(db)
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=days_back)

    # Get all teams
    teams = db.query(Team).all()

    for team in teams:
        try:
            metrics = calculator.calculate_team_metrics(team.id, start_date, end_date)
            logger.info(f"Computed metrics for team {team.name}: {metrics}")
            # Store individual metrics here if needed
        except Exception as e:
            logger.error(f"Error computing metrics for team {team.id}: {e}")
