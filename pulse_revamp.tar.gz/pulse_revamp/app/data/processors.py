"""Data processing and normalization utilities"""

import pandas as pd
from typing import Dict, List, Any
import logging

logger = logging.getLogger(__name__)


class DataProcessor:
    """Process and normalize data from external sources"""

    @staticmethod
    def normalize_github_commits(raw_data: List[Dict]) -> pd.DataFrame:
        """Normalize GitHub commit data"""
        if not raw_data:
            return pd.DataFrame()

        df = pd.DataFrame(raw_data)

        # Normalize structure
        normalized = pd.DataFrame({
            'sha': df.get('sha', ''),
            'author': df.get('author', {}).apply(lambda x: x.get('login', '') if isinstance(x, dict) else ''),
            'message': df.get('commit', {}).apply(lambda x: x.get('message', '') if isinstance(x, dict) else ''),
            'timestamp': pd.to_datetime(df.get('commit', {}).apply(
                lambda x: x.get('author', {}).get('date', '') if isinstance(x, dict) else ''
            )),
            'additions': df.get('stats', {}).apply(lambda x: x.get('additions', 0) if isinstance(x, dict) else 0),
            'deletions': df.get('stats', {}).apply(lambda x: x.get('deletions', 0) if isinstance(x, dict) else 0)
        })

        return normalized

    @staticmethod
    def normalize_github_pulls(raw_data: List[Dict]) -> pd.DataFrame:
        """Normalize GitHub pull request data"""
        if not raw_data:
            return pd.DataFrame()

        df = pd.DataFrame(raw_data)

        normalized = pd.DataFrame({
            'pr_number': df.get('number', 0),
            'author': df.get('user', {}).apply(lambda x: x.get('login', '') if isinstance(x, dict) else ''),
            'title': df.get('title', ''),
            'state': df.get('state', ''),
            'created_at': pd.to_datetime(df.get('created_at')),
            'merged_at': pd.to_datetime(df.get('merged_at')),
            'closed_at': pd.to_datetime(df.get('closed_at')),
            'additions': df.get('additions', 0),
            'deletions': df.get('deletions', 0)
        })

        return normalized

    @staticmethod
    def normalize_jira_issues(raw_data: List[Dict]) -> pd.DataFrame:
        """Normalize Jira issue data"""
        if not raw_data:
            return pd.DataFrame()

        # This is a placeholder - actual structure depends on Jira API response
        df = pd.DataFrame(raw_data)

        try:
            normalized = pd.DataFrame({
                'external_id': df.get('key', ''),
                'title': df.get('fields', {}).apply(lambda x: x.get('summary', '') if isinstance(x, dict) else ''),
                'assignee': df.get('fields', {}).apply(
                    lambda x: x.get('assignee', {}).get('displayName', '') if isinstance(x, dict) else ''
                ),
                'status': df.get('fields', {}).apply(lambda x: x.get('status', {}).get('name', '') if isinstance(x, dict) else ''),
                'priority': df.get('fields', {}).apply(lambda x: x.get('priority', {}).get('name', '') if isinstance(x, dict) else ''),
                'issue_type': df.get('fields', {}).apply(lambda x: x.get('issuetype', {}).get('name', '') if isinstance(x, dict) else ''),
                'created_at': pd.to_datetime(df.get('fields', {}).apply(lambda x: x.get('created', '') if isinstance(x, dict) else '')),
                'resolved_at': pd.to_datetime(df.get('fields', {}).apply(lambda x: x.get('resolutiondate', '') if isinstance(x, dict) else ''))
            })
            return normalized
        except Exception as e:
            logger.error(f"Error normalizing Jira data: {e}")
            return pd.DataFrame()

    @staticmethod
    def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
        """Clean and prepare dataframe for database insertion"""
        # Remove duplicates
        df = df.drop_duplicates()

        # Handle missing values
        df = df.fillna({
            col: '' if df[col].dtype == 'object' else 0
            for col in df.columns
        })

        # Remove rows with critical missing data
        # (This depends on which fields are required)

        return df

    @staticmethod
    def aggregate_time_series(
        df: pd.DataFrame,
        date_column: str,
        value_column: str,
        frequency: str = 'W'
    ) -> pd.DataFrame:
        """Aggregate data by time period

        Args:
            df: Input dataframe
            date_column: Name of date column
            value_column: Name of value column to aggregate
            frequency: Pandas frequency string (D=daily, W=weekly, M=monthly)

        Returns:
            Aggregated dataframe
        """
        df[date_column] = pd.to_datetime(df[date_column])
        df = df.set_index(date_column)

        aggregated = df.resample(frequency)[value_column].agg(['count', 'sum', 'mean'])
        return aggregated.reset_index()


# Utility functions for common transformations
def map_external_ids(
    df: pd.DataFrame,
    external_col: str,
    mapping: Dict[str, int]
) -> pd.DataFrame:
    """Map external IDs (e.g., GitHub usernames) to internal member IDs

    Args:
        df: Input dataframe
        external_col: Column containing external identifiers
        mapping: Dictionary mapping external IDs to internal IDs

    Returns:
        Dataframe with new 'member_id' column
    """
    df['member_id'] = df[external_col].map(mapping)
    return df


def validate_required_fields(df: pd.DataFrame, required_fields: List[str]) -> bool:
    """Validate that dataframe has all required fields

    Args:
        df: Input dataframe
        required_fields: List of required column names

    Returns:
        True if all fields present, False otherwise
    """
    missing = set(required_fields) - set(df.columns)
    if missing:
        logger.warning(f"Missing required fields: {missing}")
        return False
    return True
