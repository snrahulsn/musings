"""Unified Streamlit application with Dashboard and Chat tabs"""

import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta

# Page config
st.set_page_config(
    page_title="Workflow Analytics",
    page_icon="📊",
    layout="wide"
)

# Configuration
API_BASE_URL = "http://localhost:5001/api"


# ============================================================================
# Helper Functions
# ============================================================================

def fetch_teams():
    """Fetch all teams from API"""
    try:
        response = requests.get(f"{API_BASE_URL}/teams")
        if response.status_code == 200:
            return response.json()
        return []
    except Exception as e:
        st.error(f"Failed to fetch teams: {e}")
        return []


def fetch_members(team_id=None):
    """Fetch members, optionally filtered by team"""
    try:
        url = f"{API_BASE_URL}/members"
        if team_id:
            url += f"?team_id={team_id}"
        response = requests.get(url)
        if response.status_code == 200:
            return response.json()
        return []
    except Exception as e:
        st.error(f"Failed to fetch members: {e}")
        return []


def fetch_pinned_insights():
    """Fetch pinned insights from API"""
    try:
        response = requests.get(f"{API_BASE_URL}/insights?pinned=true")
        if response.status_code == 200:
            return response.json()
        return []
    except Exception as e:
        st.error(f"Failed to fetch insights: {e}")
        return []


def unpin_insight(insight_id):
    """Unpin an insight"""
    try:
        response = requests.put(f"{API_BASE_URL}/insights/{insight_id}/pin")
        return response.status_code == 200
    except Exception as e:
        st.error(f"Failed to unpin insight: {e}")
        return False


def save_insight(query: str, sql: str, results: dict, summary: str, pinned: bool = False):
    """Save insight to database via API"""
    try:
        response = requests.post(
            f"{API_BASE_URL}/insights",
            json={
                "query": query,
                "sql_query": sql,
                "result_data": results,
                "summary": summary,
                "pinned": pinned
            }
        )
        return response.status_code == 201
    except Exception as e:
        st.error(f"Failed to save insight: {e}")
        return False


def query_api(user_query: str):
    """Send query to backend API for Text-to-SQL processing"""
    try:
        response = requests.post(
            f"{API_BASE_URL}/query",
            json={"query": user_query},
            timeout=30
        )
        if response.status_code == 200:
            return response.json()
        else:
            return {
                "error": f"API returned status code {response.status_code}",
                "query": user_query
            }
    except requests.exceptions.RequestException as e:
        return {
            "error": f"Failed to connect to API: {str(e)}",
            "query": user_query
        }


def fetch_commits(filters):
    """Fetch commits with filters"""
    try:
        params = {}
        if filters.get("start_date"):
            params["start_date"] = filters["start_date"].isoformat()
        if filters.get("end_date"):
            params["end_date"] = filters["end_date"].isoformat()
        if filters.get("author_id"):
            params["author_id"] = filters["author_id"]

        response = requests.get(f"{API_BASE_URL}/data/commits", params=params)
        if response.status_code == 200:
            return response.json()
        return []
    except Exception as e:
        st.error(f"Failed to fetch commits: {e}")
        return []


def fetch_pull_requests(filters):
    """Fetch pull requests with filters"""
    try:
        params = {}
        if filters.get("author_id"):
            params["author_id"] = filters["author_id"]
        if filters.get("state"):
            params["state"] = filters["state"]

        response = requests.get(f"{API_BASE_URL}/data/pull_requests", params=params)
        if response.status_code == 200:
            return response.json()
        return []
    except Exception as e:
        st.error(f"Failed to fetch pull requests: {e}")
        return []


def create_commits_chart(commits_data):
    """Create commits over time chart"""
    if not commits_data:
        return None

    df = pd.DataFrame(commits_data)
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df['date'] = df['timestamp'].dt.date

    daily_commits = df.groupby('date').size().reset_index(name='count')

    fig = px.line(
        daily_commits,
        x='date',
        y='count',
        title='Commits Over Time',
        labels={'date': 'Date', 'count': 'Number of Commits'}
    )
    fig.update_traces(mode='lines+markers')
    return fig


def create_pr_state_chart(pr_data):
    """Create PR state distribution chart"""
    if not pr_data:
        return None

    df = pd.DataFrame(pr_data)
    state_counts = df['state'].value_counts().reset_index()
    state_counts.columns = ['state', 'count']

    fig = px.pie(
        state_counts,
        values='count',
        names='state',
        title='Pull Request Status Distribution'
    )
    return fig


# ============================================================================
# Initialize Session State
# ============================================================================

if "messages" not in st.session_state:
    st.session_state.messages = []


# ============================================================================
# Main App Header
# ============================================================================

st.title("📊 Workflow Analytics")
st.markdown("Monitor performance across tech and non-tech teams with AI-powered insights")

# ============================================================================
# Tabs
# ============================================================================

tab1, tab2 = st.tabs(["📊 Dashboard", "💬 Chat"])

# ============================================================================
# TAB 1: DASHBOARD
# ============================================================================

with tab1:
    st.header("Analytics Dashboard")

    # Sidebar filters
    with st.sidebar:
        st.header("🔍 Filters")

        # Date range
        col1, col2 = st.columns(2)
        with col1:
            start_date = st.date_input(
                "Start Date",
                value=datetime.now() - timedelta(days=30)
            )
        with col2:
            end_date = st.date_input(
                "End Date",
                value=datetime.now()
            )

        # Team filter
        teams = fetch_teams()
        team_options = {team['name']: team['id'] for team in teams}
        selected_team = st.selectbox(
            "Team",
            options=["All"] + list(team_options.keys())
        )

        # Member filter
        team_id = team_options.get(selected_team) if selected_team != "All" else None
        members = fetch_members(team_id)
        member_options = {member['name']: member['id'] for member in members}
        selected_member = st.selectbox(
            "Member",
            options=["All"] + list(member_options.keys())
        )

        # Refresh button
        if st.button("🔄 Refresh Data"):
            st.rerun()

    # Build filters dict
    filters = {
        "start_date": datetime.combine(start_date, datetime.min.time()),
        "end_date": datetime.combine(end_date, datetime.max.time()),
        "team_id": team_id,
        "author_id": member_options.get(selected_member) if selected_member != "All" else None
    }

    # Create sub-tabs for different views
    dashboard_tabs = st.tabs(["📈 Overview", "💻 Engineering", "📌 Pinned Insights"])

    with dashboard_tabs[0]:  # Overview
        st.subheader("Overview")

        # KPI cards
        col1, col2, col3, col4 = st.columns(4)

        commits_data = fetch_commits(filters)
        pr_data = fetch_pull_requests(filters)

        with col1:
            st.metric("Total Commits", len(commits_data))

        with col2:
            st.metric("Pull Requests", len(pr_data))

        with col3:
            merged_prs = len([pr for pr in pr_data if pr['state'] == 'merged'])
            st.metric("Merged PRs", merged_prs)

        with col4:
            if commits_data:
                total_changes = sum(c.get('additions', 0) + c.get('deletions', 0) for c in commits_data)
                st.metric("Lines Changed", f"{total_changes:,}")
            else:
                st.metric("Lines Changed", "0")

        st.divider()

        # Charts
        col1, col2 = st.columns(2)

        with col1:
            fig = create_commits_chart(commits_data)
            if fig:
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("No commit data available for the selected filters")

        with col2:
            fig = create_pr_state_chart(pr_data)
            if fig:
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("No PR data available for the selected filters")

    with dashboard_tabs[1]:  # Engineering
        st.subheader("Engineering Metrics")

        # Recent commits table
        st.subheader("Recent Commits")
        if commits_data:
            df = pd.DataFrame(commits_data)
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            display_df = df[['timestamp', 'repo', 'message', 'additions', 'deletions']].head(10)
            st.dataframe(display_df, use_container_width=True)
        else:
            st.info("No commits found")

        # Recent PRs table
        st.subheader("Recent Pull Requests")
        if pr_data:
            df = pd.DataFrame(pr_data)
            df['created_at'] = pd.to_datetime(df['created_at'])
            display_df = df[['created_at', 'repo', 'title', 'state']].head(10)
            st.dataframe(display_df, use_container_width=True)
        else:
            st.info("No pull requests found")

    with dashboard_tabs[2]:  # Pinned Insights
        st.subheader("📌 Pinned Insights")

        pinned = fetch_pinned_insights()

        if not pinned:
            st.info("No pinned insights yet. Use the chat interface to create and pin insights!")
        else:
            for insight in pinned:
                with st.expander(f"💡 {insight['query']}", expanded=True):
                    st.markdown(insight['summary'])

                    # Show SQL if available
                    if insight.get('sql_query'):
                        with st.expander("View SQL"):
                            st.code(insight['sql_query'], language='sql')

                    # Show results if available
                    if insight.get('result_data'):
                        results = insight['result_data']
                        if isinstance(results, list) and len(results) > 0:
                            st.dataframe(results, use_container_width=True)

                    # Unpin button
                    col1, col2, col3 = st.columns([1, 1, 4])
                    with col1:
                        if st.button("📌 Unpin", key=f"unpin_{insight['id']}"):
                            if unpin_insight(insight['id']):
                                st.success("Insight unpinned")
                                st.rerun()
                    with col2:
                        st.caption(f"Created: {insight['created_at'][:10]}")


# ============================================================================
# TAB 2: CHAT
# ============================================================================

with tab2:
    st.header("💬 Ask Questions About Your Workflow")
    st.markdown("Ask questions in natural language and get AI-powered insights from your data.")

    # Sidebar with help
    with st.sidebar:
        st.header("📚 Help")
        st.markdown("""
        ### Example Questions:
        - Show me commits from last week
        - Which developer merged the most PRs this month?
        - What's the average PR merge time?
        - How many bugs were resolved this quarter?
        - Show sales velocity for Q4
        - Compare engineering team performance

        ### Tips:
        - Be specific with time periods
        - Mention team or person names when relevant
        - Use clear, simple language
        """)

        st.divider()

        if st.button("🗑️ Clear Chat History"):
            st.session_state.messages = []
            st.rerun()

    # Display chat messages
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

            # Display SQL query if available
            if "sql" in message and message["sql"]:
                with st.expander("🔍 View SQL Query"):
                    st.code(message["sql"], language="sql")

            # Display results if available
            if "results" in message and message["results"]:
                if isinstance(message["results"], list) and len(message["results"]) > 0:
                    st.dataframe(message["results"], use_container_width=True)
                elif isinstance(message["results"], dict):
                    st.json(message["results"])

            # Pin button for assistant messages
            if message["role"] == "assistant" and "query" in message:
                col1, col2 = st.columns([1, 5])
                with col1:
                    if st.button("📌 Pin", key=f"pin_{message.get('timestamp', '')}"):
                        if save_insight(
                            message["query"],
                            message.get("sql", ""),
                            message.get("results", {}),
                            message["content"],
                            pinned=True
                        ):
                            st.success("Insight pinned to dashboard!")
                        else:
                            st.error("Failed to pin insight")

    # Chat input
    if prompt := st.chat_input("Ask about your workflow metrics..."):
        # Add user message
        st.session_state.messages.append({
            "role": "user",
            "content": prompt,
            "timestamp": datetime.now().isoformat()
        })

        # Display user message
        with st.chat_message("user"):
            st.markdown(prompt)

        # Get response from API
        with st.chat_message("assistant"):
            with st.spinner("Analyzing..."):
                response = query_api(prompt)

            if "error" in response:
                error_message = f"❌ {response['error']}"
                st.error(error_message)

                # Add error to chat history
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": error_message,
                    "timestamp": datetime.now().isoformat()
                })
            else:
                # Display summary
                summary = response.get("summary", "No insights generated yet.")
                st.markdown(summary)

                # Show SQL
                if response.get("sql"):
                    with st.expander("🔍 View SQL Query"):
                        st.code(response["sql"], language="sql")

                # Show results
                if response.get("results"):
                    results = response["results"]
                    if isinstance(results, list) and len(results) > 0:
                        st.dataframe(results, use_container_width=True)
                    elif isinstance(results, dict):
                        st.json(results)

                # Add to chat history
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": summary,
                    "query": prompt,
                    "sql": response.get("sql", ""),
                    "results": response.get("results", {}),
                    "timestamp": datetime.now().isoformat()
                })

                # Pin button
                col1, col2 = st.columns([1, 5])
                with col1:
                    if st.button("📌 Pin", key=f"pin_latest"):
                        if save_insight(
                            prompt,
                            response.get("sql", ""),
                            response.get("results", {}),
                            summary,
                            pinned=True
                        ):
                            st.success("Insight pinned to dashboard!")
                        else:
                            st.error("Failed to pin insight")
