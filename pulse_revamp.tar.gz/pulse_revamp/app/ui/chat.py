"""Streamlit chat interface for natural language queries"""

import streamlit as st
import requests
from datetime import datetime
import json

# Page config
st.set_page_config(
    page_title="Workflow Analytics - Chat",
    page_icon="💬",
    layout="wide"
)

# Configuration
API_BASE_URL = "http://localhost:5000/api"


def init_session_state():
    """Initialize session state variables"""
    if "messages" not in st.session_state:
        st.session_state.messages = []


def save_insight(query: str, sql: str, results: dict, summary: str, pinned: bool = False):
    """Save insight to database via API"""
    try:
        response = requests.post(
            f"{API_BASE_URL}/insights",
            json={
                "query": query,
                "sql_query": sql,
                "result_data": results,
                "summary": summary,
                "pinned": pinned
            }
        )
        return response.status_code == 201
    except Exception as e:
        st.error(f"Failed to save insight: {e}")
        return False


def query_api(user_query: str):
    """Send query to backend API"""
    try:
        response = requests.post(
            f"{API_BASE_URL}/query",
            json={"query": user_query},
            timeout=30
        )
        if response.status_code == 200:
            return response.json()
        else:
            return {
                "error": f"API returned status code {response.status_code}",
                "query": user_query
            }
    except requests.exceptions.RequestException as e:
        return {
            "error": f"Failed to connect to API: {str(e)}",
            "query": user_query
        }


def main():
    """Main chat interface"""
    init_session_state()

    # Header
    st.title("💬 Workflow Analytics Chat")
    st.markdown("Ask questions about your organization's workflow metrics in natural language.")

    # Sidebar with help and examples
    with st.sidebar:
        st.header("📚 Help")
        st.markdown("""
        ### Example Questions:
        - Show me commits from last week
        - Which developer merged the most PRs this month?
        - What's the average PR merge time?
        - How many bugs were resolved this quarter?
        - Show sales velocity for Q4
        - Compare engineering team performance

        ### Tips:
        - Be specific with time periods
        - Mention team or person names when relevant
        - Use clear, simple language
        """)

        st.divider()

        if st.button("🗑️ Clear Chat History"):
            st.session_state.messages = []
            st.rerun()

    # Display chat messages
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

            # Display SQL query if available
            if "sql" in message and message["sql"]:
                with st.expander("🔍 View SQL Query"):
                    st.code(message["sql"], language="sql")

            # Display results if available
            if "results" in message and message["results"]:
                if isinstance(message["results"], list) and len(message["results"]) > 0:
                    st.dataframe(message["results"], use_container_width=True)
                elif isinstance(message["results"], dict):
                    st.json(message["results"])

            # Pin button for assistant messages
            if message["role"] == "assistant" and "query" in message:
                col1, col2 = st.columns([1, 5])
                with col1:
                    if st.button("📌 Pin", key=f"pin_{message.get('timestamp', '')}"):
                        if save_insight(
                            message["query"],
                            message.get("sql", ""),
                            message.get("results", {}),
                            message["content"],
                            pinned=True
                        ):
                            st.success("Insight pinned to dashboard!")
                        else:
                            st.error("Failed to pin insight")

    # Chat input
    if prompt := st.chat_input("Ask about your workflow metrics..."):
        # Add user message
        st.session_state.messages.append({
            "role": "user",
            "content": prompt,
            "timestamp": datetime.now().isoformat()
        })

        # Display user message
        with st.chat_message("user"):
            st.markdown(prompt)

        # Get response from API
        with st.chat_message("assistant"):
            with st.spinner("Analyzing..."):
                response = query_api(prompt)

            if "error" in response:
                error_message = f"❌ {response['error']}"
                st.error(error_message)

                # Add error to chat history
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": error_message,
                    "timestamp": datetime.now().isoformat()
                })
            else:
                # Display summary
                summary = response.get("summary", "No insights generated yet.")
                st.markdown(summary)

                # Show SQL
                if response.get("sql"):
                    with st.expander("🔍 View SQL Query"):
                        st.code(response["sql"], language="sql")

                # Show results
                if response.get("results"):
                    results = response["results"]
                    if isinstance(results, list) and len(results) > 0:
                        st.dataframe(results, use_container_width=True)
                    elif isinstance(results, dict):
                        st.json(results)

                # Add to chat history
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": summary,
                    "query": prompt,
                    "sql": response.get("sql", ""),
                    "results": response.get("results", {}),
                    "timestamp": datetime.now().isoformat()
                })

                # Pin button
                col1, col2 = st.columns([1, 5])
                with col1:
                    if st.button("📌 Pin", key=f"pin_latest"):
                        if save_insight(
                            prompt,
                            response.get("sql", ""),
                            response.get("results", {}),
                            summary,
                            pinned=True
                        ):
                            st.success("Insight pinned to dashboard!")
                        else:
                            st.error("Failed to pin insight")


if __name__ == "__main__":
    main()
