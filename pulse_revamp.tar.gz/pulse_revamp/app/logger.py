"""Logging configuration for the application"""

import logging
import logging.handlers
from pathlib import Path
from app.config import get_config

config = get_config()


def setup_logger(name: str = __name__, log_file: Path = None) -> logging.Logger:
    """Set up logger with file and console handlers

    Args:
        name: Logger name (typically __name__)
        log_file: Optional specific log file path

    Returns:
        Configured logger instance
    """
    # Ensure logs directory exists
    config.ensure_directories()

    # Create logger
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, config.LOG_LEVEL))

    # Avoid duplicate handlers
    if logger.handlers:
        return logger

    # Create formatters
    detailed_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    simple_formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # File handler
    log_file = log_file or config.LOG_FILE
    file_handler = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=5
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(detailed_formatter)

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(simple_formatter)

    # Add handlers
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger


def get_logger(name: str = __name__) -> logging.Logger:
    """Get or create logger instance

    Args:
        name: Logger name

    Returns:
        Logger instance
    """
    return setup_logger(name)
