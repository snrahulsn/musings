"""Flask API routes"""

from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime, timedelta
from app.config import get_config
from app.models import (
    init_db, get_db,
    Team, Member, Commit, PullRequest, Issue, Task, Deal, Insight, Metric
)
import logging

# Initialize Flask app
app = Flask(__name__)
config = get_config()
app.config.from_object(config)

# Enable CORS for Streamlit
CORS(app)

# Setup logging
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@app.before_request
def before_request():
    """Initialize database before first request"""
    if not hasattr(app, 'db_initialized'):
        init_db()
        app.db_initialized = True


# Health check endpoint
@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat()
    })


# Teams endpoints
@app.route('/api/teams', methods=['GET'])
def get_teams():
    """Get all teams"""
    try:
        db = next(get_db())
        teams = db.query(Team).all()
        return jsonify([{
            "id": team.id,
            "name": team.name,
            "type": team.type,
            "extra_data": team.metadata
        } for team in teams])
    except Exception as e:
        logger.error(f"Error fetching teams: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/api/teams/<int:team_id>', methods=['GET'])
def get_team(team_id):
    """Get team by ID"""
    try:
        db = next(get_db())
        team = db.query(Team).filter(Team.id == team_id).first()
        if not team:
            return jsonify({"error": "Team not found"}), 404
        return jsonify({
            "id": team.id,
            "name": team.name,
            "type": team.type,
            "extra_data": team.metadata,
            "member_count": len(team.members)
        })
    except Exception as e:
        logger.error(f"Error fetching team: {e}")
        return jsonify({"error": str(e)}), 500


# Members endpoints
@app.route('/api/members', methods=['GET'])
def get_members():
    """Get all members, optionally filtered by team"""
    try:
        db = next(get_db())
        team_id = request.args.get('team_id', type=int)

        query = db.query(Member)
        if team_id:
            query = query.filter(Member.team_id == team_id)

        members = query.all()
        return jsonify([{
            "id": member.id,
            "name": member.name,
            "email": member.email,
            "team_id": member.team_id,
            "role": member.role
        } for member in members])
    except Exception as e:
        logger.error(f"Error fetching members: {e}")
        return jsonify({"error": str(e)}), 500


# Metrics endpoints
@app.route('/api/metrics', methods=['GET'])
def get_metrics():
    """Get metrics with optional filters"""
    try:
        db = next(get_db())

        # Parse filters from query params
        metric_type = request.args.get('type')
        entity_type = request.args.get('entity_type')
        entity_id = request.args.get('entity_id', type=int)
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')

        query = db.query(Metric)

        if metric_type:
            query = query.filter(Metric.metric_type == metric_type)
        if entity_type:
            query = query.filter(Metric.entity_type == entity_type)
        if entity_id:
            query = query.filter(Metric.entity_id == entity_id)
        if start_date:
            query = query.filter(Metric.period_start >= datetime.fromisoformat(start_date))
        if end_date:
            query = query.filter(Metric.period_end <= datetime.fromisoformat(end_date))

        metrics = query.all()
        return jsonify([{
            "id": metric.id,
            "metric_name": metric.metric_name,
            "metric_type": metric.metric_type,
            "entity_type": metric.entity_type,
            "entity_id": metric.entity_id,
            "value": metric.value,
            "period_start": metric.period_start.isoformat() if metric.period_start else None,
            "period_end": metric.period_end.isoformat() if metric.period_end else None,
            "computed_at": metric.computed_at.isoformat()
        } for metric in metrics])
    except Exception as e:
        logger.error(f"Error fetching metrics: {e}")
        return jsonify({"error": str(e)}), 500


# Data endpoints
@app.route('/api/data/commits', methods=['GET'])
def get_commits():
    """Get commits with optional filters"""
    try:
        db = next(get_db())

        author_id = request.args.get('author_id', type=int)
        repo = request.args.get('repo')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        limit = request.args.get('limit', 100, type=int)

        query = db.query(Commit)

        if author_id:
            query = query.filter(Commit.author_id == author_id)
        if repo:
            query = query.filter(Commit.repo == repo)
        if start_date:
            query = query.filter(Commit.timestamp >= datetime.fromisoformat(start_date))
        if end_date:
            query = query.filter(Commit.timestamp <= datetime.fromisoformat(end_date))

        commits = query.order_by(Commit.timestamp.desc()).limit(limit).all()

        return jsonify([{
            "id": commit.id,
            "sha": commit.sha,
            "author_id": commit.author_id,
            "repo": commit.repo,
            "message": commit.message,
            "additions": commit.additions,
            "deletions": commit.deletions,
            "timestamp": commit.timestamp.isoformat()
        } for commit in commits])
    except Exception as e:
        logger.error(f"Error fetching commits: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/api/data/pull_requests', methods=['GET'])
def get_pull_requests():
    """Get pull requests with optional filters"""
    try:
        db = next(get_db())

        author_id = request.args.get('author_id', type=int)
        repo = request.args.get('repo')
        state = request.args.get('state')
        limit = request.args.get('limit', 100, type=int)

        query = db.query(PullRequest)

        if author_id:
            query = query.filter(PullRequest.author_id == author_id)
        if repo:
            query = query.filter(PullRequest.repo == repo)
        if state:
            query = query.filter(PullRequest.state == state)

        prs = query.order_by(PullRequest.created_at.desc()).limit(limit).all()

        return jsonify([{
            "id": pr.id,
            "pr_number": pr.pr_number,
            "author_id": pr.author_id,
            "repo": pr.repo,
            "title": pr.title,
            "state": pr.state,
            "created_at": pr.created_at.isoformat(),
            "merged_at": pr.merged_at.isoformat() if pr.merged_at else None,
            "closed_at": pr.closed_at.isoformat() if pr.closed_at else None
        } for pr in prs])
    except Exception as e:
        logger.error(f"Error fetching pull requests: {e}")
        return jsonify({"error": str(e)}), 500


# Insights endpoints
@app.route('/api/insights', methods=['GET'])
def get_insights():
    """Get insights, optionally filtered by pinned status"""
    try:
        db = next(get_db())
        pinned = request.args.get('pinned', type=bool)

        query = db.query(Insight)
        if pinned is not None:
            query = query.filter(Insight.pinned == pinned)

        insights = query.order_by(Insight.created_at.desc()).all()

        return jsonify([{
            "id": insight.id,
            "query": insight.query,
            "sql_query": insight.sql_query,
            "result_data": insight.result_data,
            "summary": insight.summary,
            "pinned": insight.pinned,
            "created_at": insight.created_at.isoformat()
        } for insight in insights])
    except Exception as e:
        logger.error(f"Error fetching insights: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/api/insights', methods=['POST'])
def create_insight():
    """Create new insight"""
    try:
        db = next(get_db())
        data = request.json

        insight = Insight(
            query=data.get('query'),
            sql_query=data.get('sql_query'),
            result_data=data.get('result_data'),
            summary=data.get('summary'),
            pinned=data.get('pinned', False)
        )

        db.add(insight)
        db.commit()
        db.refresh(insight)

        return jsonify({
            "id": insight.id,
            "message": "Insight created successfully"
        }), 201
    except Exception as e:
        logger.error(f"Error creating insight: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/api/insights/<int:insight_id>/pin', methods=['PUT'])
def toggle_pin_insight(insight_id):
    """Toggle pin status of insight"""
    try:
        db = next(get_db())
        insight = db.query(Insight).filter(Insight.id == insight_id).first()

        if not insight:
            return jsonify({"error": "Insight not found"}), 404

        insight.pinned = not insight.pinned
        db.commit()

        return jsonify({
            "id": insight.id,
            "pinned": insight.pinned,
            "message": "Pin status updated"
        })
    except Exception as e:
        logger.error(f"Error toggling pin: {e}")
        return jsonify({"error": str(e)}), 500


# Query endpoint (for Text-to-SQL)
@app.route('/api/query', methods=['POST'])
def execute_query():
    """Execute natural language query using Text-to-SQL"""
    try:
        from app.api.query_engine import query_engine

        data = request.json
        query_text = data.get('query')

        if not query_text:
            return jsonify({"error": "Query text is required"}), 400

        # Process query using query engine
        result = query_engine.process_query(query_text)

        if result.get('success'):
            return jsonify({
                "query": result['query'],
                "sql": result['sql'],
                "results": result['results'],
                "summary": result['summary']
            })
        else:
            return jsonify({
                "error": result.get('error', 'Unknown error'),
                "query": query_text
            }), 500

    except Exception as e:
        logger.error(f"Error executing query: {e}")
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    config.ensure_directories()
    app.run(
        host=config.APP_HOST,
        port=config.APP_PORT,
        debug=config.DEBUG
    )
