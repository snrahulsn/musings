"""Query engine for Text-to-SQL and LLM integration"""

from typing import Dict, List, Any, Optional
import logging
import re
from sqlalchemy import create_engine, text
from langchain_community.utilities import SQLDatabase
from langchain.chains import create_sql_query_chain
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI
from app.config import get_config

logger = logging.getLogger(__name__)
config = get_config()


class QueryEngine:
    """Handle natural language to SQL conversion and insight generation"""

    def __init__(self):
        self.config = config
        self.db = None
        self.llm = None
        self.sql_chain = None
        self._initialize()

    def _initialize(self):
        """Initialize database connection and LLM"""
        try:
            # Initialize SQLDatabase for LangChain
            self.db = SQLDatabase.from_uri(
                self.config.DATABASE_URL,
                include_tables=['teams', 'members', 'commits', 'pull_requests',
                               'issues', 'tasks', 'deals', 'insights', 'metrics']
            )

            # Initialize LLM (configure for xAI Grok or OpenAI)
            if self.config.LLM_API_KEY:
                self.llm = ChatOpenAI(
                    api_key=self.config.LLM_API_KEY,
                    base_url=self.config.LLM_API_BASE,
                    model=self.config.LLM_MODEL,
                    temperature=0
                )

                # Create SQL generation chain
                self.sql_chain = create_sql_query_chain(self.llm, self.db)

                logger.info("Query engine initialized successfully")
            else:
                logger.warning("LLM_API_KEY not set - Text-to-SQL will not work")

        except Exception as e:
            logger.error(f"Error initializing query engine: {e}")

    def get_database_schema(self) -> str:
        """Generate database schema context for LLM"""
        if self.db:
            return self.db.get_table_info()

        # Fallback schema description
        schema = """
        Database Schema:

        1. teams: id (INTEGER), name (VARCHAR), type (VARCHAR), extra_data (JSON)
        2. members: id (INTEGER), name (VARCHAR), email (VARCHAR), team_id (INTEGER), role (VARCHAR), external_ids (JSON)
        3. commits: id (INTEGER), sha (VARCHAR), author_id (INTEGER), repo (VARCHAR), message (TEXT), additions (INTEGER), deletions (INTEGER), timestamp (TIMESTAMP)
        4. pull_requests: id (INTEGER), pr_number (INTEGER), author_id (INTEGER), repo (VARCHAR), title (VARCHAR), state (VARCHAR), created_at (TIMESTAMP), merged_at (TIMESTAMP), closed_at (TIMESTAMP)
        5. issues: id (INTEGER), external_id (VARCHAR), assignee_id (INTEGER), project (VARCHAR), title (VARCHAR), status (VARCHAR), priority (VARCHAR), issue_type (VARCHAR), created_at (TIMESTAMP), resolved_at (TIMESTAMP)
        6. tasks: id (INTEGER), external_id (VARCHAR), assignee_id (INTEGER), project (VARCHAR), title (VARCHAR), status (VARCHAR), created_at (TIMESTAMP), completed_at (TIMESTAMP)
        7. deals: id (INTEGER), external_id (VARCHAR), owner_id (INTEGER), name (VARCHAR), stage (VARCHAR), value (FLOAT), created_at (TIMESTAMP), closed_at (TIMESTAMP)
        8. metrics: id (INTEGER), metric_name (VARCHAR), metric_type (VARCHAR), entity_type (VARCHAR), entity_id (INTEGER), value (FLOAT), period_start (TIMESTAMP), period_end (TIMESTAMP)

        Relationships:
        - members.team_id -> teams.id
        - commits.author_id -> members.id
        - pull_requests.author_id -> members.id
        - issues.assignee_id -> members.id
        - tasks.assignee_id -> members.id
        - deals.owner_id -> members.id
        """
        return schema

    def _validate_sql(self, sql_query: str) -> bool:
        """Validate SQL query for safety (read-only operations)

        Args:
            sql_query: SQL query to validate

        Returns:
            True if safe, False otherwise
        """
        # Remove comments and normalize
        sql_normalized = re.sub(r'--.*?$', '', sql_query, flags=re.MULTILINE)
        sql_normalized = re.sub(r'/\*.*?\*/', '', sql_normalized, flags=re.DOTALL)
        sql_normalized = sql_normalized.upper()

        # Check for dangerous keywords
        dangerous_keywords = [
            'DROP', 'DELETE', 'INSERT', 'UPDATE', 'ALTER',
            'CREATE', 'TRUNCATE', 'REPLACE', 'GRANT', 'REVOKE'
        ]

        for keyword in dangerous_keywords:
            if keyword in sql_normalized:
                logger.warning(f"Dangerous keyword '{keyword}' found in SQL query")
                return False

        return True

    def text_to_sql(self, natural_query: str) -> str:
        """Convert natural language query to SQL using LangChain

        Args:
            natural_query: Natural language question

        Returns:
            Generated SQL query
        """
        if not self.sql_chain:
            logger.error("SQL chain not initialized - check LLM_API_KEY")
            return "-- Error: LLM not configured. Please set LLM_API_KEY in .env"

        try:
            logger.info(f"Converting query to SQL: {natural_query}")

            # Generate SQL using LangChain
            sql_query = self.sql_chain.invoke({"question": natural_query})

            # Clean up the SQL (remove markdown code blocks if present)
            sql_query = sql_query.replace('```sql', '').replace('```', '').strip()

            logger.info(f"Generated SQL: {sql_query}")
            return sql_query

        except Exception as e:
            logger.error(f"Error in text_to_sql: {e}")
            return f"-- Error generating SQL: {str(e)}"

    def execute_sql(self, sql_query: str) -> List[Dict[str, Any]]:
        """Execute SQL query and return results

        Args:
            sql_query: SQL query to execute

        Returns:
            List of dictionaries with query results
        """
        # Skip if error message
        if sql_query.startswith("-- Error"):
            return []

        # Validate SQL for safety
        if not self._validate_sql(sql_query):
            logger.error("SQL query failed validation")
            return []

        try:
            logger.info(f"Executing SQL: {sql_query}")

            # Use SQLDatabase to execute
            if self.db:
                result = self.db.run(sql_query)
                logger.info(f"Query result: {result}")

                # Parse result if it's a string
                if isinstance(result, str):
                    # Try to convert to structured format
                    return [{"result": result}]
                return result if isinstance(result, list) else [result]
            else:
                logger.error("Database not initialized")
                return []

        except Exception as e:
            logger.error(f"Error executing SQL: {e}")
            return []

    def generate_insight(self, query: str, sql_query: str, results: List[Dict[str, Any]]) -> str:
        """Generate human-readable insight from query results using LLM

        Args:
            query: Original natural language query
            sql_query: SQL query that was executed
            results: Query results

        Returns:
            Human-readable summary and insights
        """
        if not self.llm:
            # Fallback without LLM
            if not results:
                return "No data found for your query."
            return f"Query returned {len(results)} result(s). Results are displayed in the table above."

        try:
            logger.info(f"Generating insight for query: {query}")

            # Create prompt for insight generation
            insight_prompt = PromptTemplate.from_template(
                """You are a helpful data analyst. Based on the following:

                User Question: {question}
                SQL Query: {sql}
                Query Results: {results}

                Provide a clear, concise insight that answers the user's question.
                If there are no results, explain what that means.
                If there are results, summarize the key findings in 2-3 sentences.
                Be specific with numbers and trends if applicable.

                Insight:"""
            )

            # Create chain
            insight_chain = insight_prompt | self.llm | StrOutputParser()

            # Generate insight
            insight = insight_chain.invoke({
                "question": query,
                "sql": sql_query,
                "results": str(results)[:1000]  # Limit result size
            })

            logger.info(f"Generated insight: {insight}")
            return insight

        except Exception as e:
            logger.error(f"Error generating insight: {e}")
            # Fallback
            if not results:
                return "No data found for your query."
            return f"Query executed successfully. Found {len(results)} result(s)."

    def process_query(self, natural_query: str) -> Dict[str, Any]:
        """Process complete query pipeline

        Args:
            natural_query: Natural language query from user

        Returns:
            Dictionary with SQL, results, and insights
        """
        try:
            # Step 1: Convert to SQL
            sql_query = self.text_to_sql(natural_query)

            # Step 2: Execute SQL
            results = self.execute_sql(sql_query)

            # Step 3: Generate insights
            summary = self.generate_insight(natural_query, sql_query, results)

            return {
                "success": True,
                "query": natural_query,
                "sql": sql_query,
                "results": results,
                "summary": summary
            }
        except Exception as e:
            logger.error(f"Error processing query: {e}")
            return {
                "success": False,
                "error": str(e),
                "query": natural_query,
                "sql": "",
                "results": [],
                "summary": f"Error processing query: {str(e)}"
            }


# Singleton instance
query_engine = QueryEngine()
