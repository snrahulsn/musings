"""Database models for workflow analytics"""

from datetime import datetime
from sqlalchemy import (
    create_engine,
    Column,
    Integer,
    String,
    DateTime,
    Float,
    Boolean,
    Text,
    ForeignKey,
    JSON
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from app.config import get_config

Base = declarative_base()
config = get_config()


class Team(Base):
    """Team model"""
    __tablename__ = "teams"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False, unique=True)
    type = Column(String(100))  # engineering, sales, marketing, etc.
    extra_data = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    members = relationship("Member", back_populates="team")


class Member(Base):
    """Team member model"""
    __tablename__ = "members"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    email = Column(String(255), unique=True)
    team_id = Column(Integer, ForeignKey("teams.id"))
    role = Column(String(100))
    external_ids = Column(JSON)  # Store IDs from external systems (GitHub, Jira, etc.)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    team = relationship("Team", back_populates="members")
    commits = relationship("Commit", back_populates="author")
    pull_requests = relationship("PullRequest", back_populates="author")
    issues = relationship("Issue", back_populates="assignee")
    tasks = relationship("Task", back_populates="assignee")
    deals = relationship("Deal", back_populates="owner")


class Commit(Base):
    """Git commit model"""
    __tablename__ = "commits"

    id = Column(Integer, primary_key=True)
    sha = Column(String(40), unique=True, nullable=False)
    author_id = Column(Integer, ForeignKey("members.id"))
    repo = Column(String(255), nullable=False)
    message = Column(Text)
    additions = Column(Integer, default=0)
    deletions = Column(Integer, default=0)
    timestamp = Column(DateTime, nullable=False)
    extra_data = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    author = relationship("Member", back_populates="commits")


class PullRequest(Base):
    """Pull request model"""
    __tablename__ = "pull_requests"

    id = Column(Integer, primary_key=True)
    pr_number = Column(Integer, nullable=False)
    author_id = Column(Integer, ForeignKey("members.id"))
    repo = Column(String(255), nullable=False)
    title = Column(String(500))
    state = Column(String(50))  # open, closed, merged
    created_at = Column(DateTime, nullable=False)
    merged_at = Column(DateTime)
    closed_at = Column(DateTime)
    additions = Column(Integer, default=0)
    deletions = Column(Integer, default=0)
    extra_data = Column(JSON)

    # Relationships
    author = relationship("Member", back_populates="pull_requests")


class Issue(Base):
    """Issue tracking model (Jira, GitHub Issues, etc.)"""
    __tablename__ = "issues"

    id = Column(Integer, primary_key=True)
    external_id = Column(String(255), unique=True, nullable=False)
    assignee_id = Column(Integer, ForeignKey("members.id"))
    project = Column(String(255))
    title = Column(String(500))
    description = Column(Text)
    status = Column(String(100))
    priority = Column(String(50))
    issue_type = Column(String(50))  # bug, feature, task, etc.
    created_at = Column(DateTime, nullable=False)
    resolved_at = Column(DateTime)
    closed_at = Column(DateTime)
    extra_data = Column(JSON)

    # Relationships
    assignee = relationship("Member", back_populates="issues")


class Task(Base):
    """Task management model (Asana, Trello, etc.)"""
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True)
    external_id = Column(String(255), unique=True, nullable=False)
    assignee_id = Column(Integer, ForeignKey("members.id"))
    project = Column(String(255))
    title = Column(String(500))
    description = Column(Text)
    status = Column(String(100))
    created_at = Column(DateTime, nullable=False)
    completed_at = Column(DateTime)
    due_date = Column(DateTime)
    extra_data = Column(JSON)

    # Relationships
    assignee = relationship("Member", back_populates="tasks")


class Deal(Base):
    """Sales deal model (Salesforce, HubSpot, etc.)"""
    __tablename__ = "deals"

    id = Column(Integer, primary_key=True)
    external_id = Column(String(255), unique=True, nullable=False)
    owner_id = Column(Integer, ForeignKey("members.id"))
    name = Column(String(500))
    stage = Column(String(100))
    value = Column(Float)
    probability = Column(Float)
    created_at = Column(DateTime, nullable=False)
    closed_at = Column(DateTime)
    expected_close_date = Column(DateTime)
    extra_data = Column(JSON)

    # Relationships
    owner = relationship("Member", back_populates="deals")


class Insight(Base):
    """Saved insights from chat interface"""
    __tablename__ = "insights"

    id = Column(Integer, primary_key=True)
    query = Column(Text, nullable=False)
    sql_query = Column(Text)
    result_data = Column(JSON)
    summary = Column(Text)
    pinned = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Metric(Base):
    """Computed metrics cache"""
    __tablename__ = "metrics"

    id = Column(Integer, primary_key=True)
    metric_name = Column(String(255), nullable=False)
    metric_type = Column(String(100))  # velocity, throughput, cycle_time, etc.
    entity_type = Column(String(100))  # team, member, project
    entity_id = Column(Integer)
    value = Column(Float)
    period_start = Column(DateTime)
    period_end = Column(DateTime)
    extra_data = Column(JSON)
    computed_at = Column(DateTime, default=datetime.utcnow)


# Database engine and session setup
engine = None
SessionLocal = None


def init_db():
    """Initialize database connection and create tables"""
    global engine, SessionLocal

    engine = create_engine(
        config.DATABASE_URL,
        echo=config.DEBUG,
        pool_pre_ping=True
    )

    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

    # Create all tables
    Base.metadata.create_all(bind=engine)
    print("Database initialized successfully")


def get_db():
    """Get database session"""
    if SessionLocal is None:
        init_db()
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
