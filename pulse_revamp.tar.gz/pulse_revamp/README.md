# Workflow Analytics App

A comprehensive web application for tracking and analyzing organizational workflow metrics across technical and non-technical teams.

## Features

- 🔄 **Data Integration**: Connect to multiple data sources (GitHub, Jira, Salesforce, etc.) via ETL pipelines
- 💬 **Chat Interface**: Natural language queries powered by LLM (Text-to-SQL)
- 📊 **Interactive Dashboard**: Visualize KPIs, metrics, and trends
- 📌 **Insight Pinning**: Save valuable insights from chat to dashboard
- 🔒 **Self-Hosted**: All components run locally (except LLM API)

## Architecture

```
┌─────────────────────────────────────┐
│   Streamlit UI (Unified Tabbed)    │
│   • Dashboard Tab                   │
│   • Chat Tab                        │
└─────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────┐
│         Flask API Backend           │
│   • REST Endpoints                  │
│   • Text-to-SQL Engine (LangChain)  │
└─────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────┐
│      PostgreSQL Database            │
└─────────────────────────────────────┘
                 ▲
                 │
┌─────────────────────────────────────┐
│    Meltano ETL Pipelines            │
│  (GitHub, Jira, Salesforce, etc.)   │
└─────────────────────────────────────┘
```

## Tech Stack

- **Backend**: Flask, SQLAlchemy
- **Frontend**: Streamlit
- **Database**: PostgreSQL
- **ETL**: Meltano
- **Data Processing**: Pandas
- **Visualization**: Plotly
- **LLM Integration**: LangChain + xAI Grok (or OpenAI compatible)

## Prerequisites

- Python 3.10 or higher
- Docker and Docker Compose (for PostgreSQL)
- API key for LLM service (xAI Grok or OpenAI compatible)

## Quick Start (Easiest Method)

### One-Command Setup & Run

```bash
./run.sh
```

That's it! The script will:
- ✅ Check prerequisites (Python, Docker)
- ✅ Create virtual environment if needed
- ✅ Install dependencies automatically
- ✅ Start PostgreSQL container
- ✅ Initialize database
- ✅ Start all services (Flask API, Dashboard, Chat)

**First time?** The script will prompt you to add your LLM API key to `.env`

### Stop the Application

```bash
./stop.sh
```

Or press `Ctrl+C` if using `./run.sh`

---

## Manual Setup (If You Prefer)

### 1. Navigate to Project

```bash
cd pulse_revamp
```

### 2. Configure Environment

```bash
cp .env.example .env
```

Edit `.env` and add your LLM API key:
```bash
LLM_API_KEY=your-actual-api-key-here
```

### 3. Create Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 4. Install Dependencies

```bash
pip install -r requirements.txt
```

### 5. Start PostgreSQL

```bash
docker-compose up -d
```

### 6. Initialize Database

```bash
python init_db.py
```

### 7. Start Services Manually

**Terminal 1 - Flask API:**
```bash
export PYTHONPATH=/path/to/pulse_revamp
python app/api/routes.py
```

**Terminal 2 - Streamlit UI:**
```bash
export PYTHONPATH=/path/to/pulse_revamp
streamlit run app/ui/main_app.py
```

### 8. Access the Application

- **Streamlit UI (Dashboard + Chat)**: http://localhost:8501
- **API Health Check**: http://localhost:5001/health

## Project Structure

```
pulse_revamp/
├── app/
│   ├── __init__.py
│   ├── config.py              # Configuration management
│   ├── models.py              # Database models
│   ├── logger.py              # Logging setup
│   ├── api/
│   │   ├── routes.py          # Flask API endpoints
│   │   └── query_engine.py    # Text-to-SQL engine (LangChain)
│   ├── data/
│   │   ├── metrics.py         # KPI calculations
│   │   └── processors.py      # Data normalization
│   └── ui/
│       └── main_app.py        # Unified Streamlit app (Dashboard + Chat tabs)
├── data/                       # Data cache
├── logs/                       # Application logs
├── tests/                      # Test files
├── docker-compose.yml          # PostgreSQL container
├── requirements.txt            # Python dependencies
├── .env.example                # Environment template
└── README.md
```

## Database Schema

### Core Tables

- **teams**: Team information (id, name, type, metadata)
- **members**: Team members (id, name, email, team_id, role)
- **commits**: Git commits (sha, author_id, repo, timestamp, additions, deletions)
- **pull_requests**: PRs (pr_number, author_id, repo, state, created_at, merged_at)
- **issues**: Issue tracking (external_id, assignee_id, project, status, priority)
- **tasks**: Task management (external_id, assignee_id, project, status, completed_at)
- **deals**: Sales deals (external_id, owner_id, stage, value, closed_at)
- **insights**: Saved chat insights (query, sql_query, result_data, summary, pinned)
- **metrics**: Computed metrics cache (metric_name, value, entity_type, period)

## Usage

### Adding Sample Data

To test the application with sample data:

```python
from app.models import init_db, get_db, Team, Member, Commit
from datetime import datetime

db = next(get_db())

# Create a team
team = Team(name="Engineering", type="engineering")
db.add(team)
db.commit()

# Create a member
member = Member(name="John Doe", email="john@example.com", team_id=team.id, role="Developer")
db.add(member)
db.commit()

# Create a commit
commit = Commit(
    sha="abc123",
    author_id=member.id,
    repo="my-repo",
    message="Fix bug",
    additions=10,
    deletions=5,
    timestamp=datetime.now()
)
db.add(commit)
db.commit()
```

### Setting Up ETL Pipelines

ETL pipelines will be added incrementally. Example for GitHub:

```bash
# Initialize Meltano (when ready)
meltano init

# Add GitHub tap
meltano add extractor tap-github

# Configure in meltano.yml
# Run pipeline
meltano run tap-github target-postgres
```

### Using the Application

1. Navigate to http://localhost:8501
2. The app has two tabs:

**📊 Dashboard Tab:**
- Use sidebar filters to select date range, team, and members
- View metrics in sub-tabs:
  - **Overview**: KPI cards and charts
  - **Engineering**: Detailed engineering metrics
  - **Pinned Insights**: Saved insights from chat

**💬 Chat Tab:**
- Type natural language queries like:
  - "Show me commits from last week"
  - "Which developer merged the most PRs?"
  - "What's the average PR merge time?"
- View SQL queries and results
- Click "📌 Pin" to save insights to dashboard

## API Endpoints

### Teams
- `GET /api/teams` - List all teams
- `GET /api/teams/<id>` - Get team details

### Members
- `GET /api/members` - List members (optional: ?team_id=X)

### Data
- `GET /api/data/commits` - Get commits (filters: author_id, repo, start_date, end_date)
- `GET /api/data/pull_requests` - Get PRs (filters: author_id, repo, state)

### Metrics
- `GET /api/metrics` - Get metrics (filters: type, entity_type, entity_id, dates)

### Insights
- `GET /api/insights` - Get insights (optional: ?pinned=true)
- `POST /api/insights` - Create insight
- `PUT /api/insights/<id>/pin` - Toggle pin status

### Query
- `POST /api/query` - Execute natural language query (Text-to-SQL)

## Development

### Running Tests

```bash
pytest tests/
```

### Code Formatting

```bash
black app/
flake8 app/
```

### Adding New Data Sources

1. Add Meltano tap: `meltano add extractor tap-<source>`
2. Configure in `meltano.yml`
3. Create normalization function in `app/data/processors.py`
4. Add models to `app/models.py` if needed
5. Update metrics calculations in `app/data/metrics.py`

## Troubleshooting

### Database Connection Issues

```bash
# Check PostgreSQL is running
docker-compose ps

# View PostgreSQL logs
docker-compose logs postgres

# Restart PostgreSQL
docker-compose restart postgres
```

### Port Already in Use

If ports 5001 or 8501 are in use:

```bash
# Change Flask port in .env
APP_PORT=5002

# Change Streamlit port
streamlit run app/ui/main_app.py --server.port 8502
```

### Dependencies Installation Fails

```bash
# Upgrade pip
pip install --upgrade pip

# Install dependencies one by one to identify issues
pip install flask
pip install streamlit
# etc.
```

## Next Steps

- [x] Implement Text-to-SQL with LangChain
- [x] Add LLM insight generation
- [x] Create unified tabbed interface
- [ ] Set up Meltano pipelines for data sources
- [ ] Add data source connectors (GitHub, Jira, etc.)
- [ ] Implement scheduled ETL jobs with APScheduler
- [ ] Add more visualization types
- [ ] Implement advanced metrics calculations
- [ ] Add export functionality
- [ ] Add alerting system
- [ ] Write comprehensive tests

## Contributing

This is a vibe-coded project - iterate fast, test often, and keep it hackable!

## License

MIT License - feel free to modify and use as needed.
