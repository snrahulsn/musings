-- GitHub Data PostgreSQL Schema
-- This schema stores incremental data from GitHub APIs

-- Organizations
CREATE TABLE IF NOT EXISTS github_organizations (
    org_id BIGINT PRIMARY KEY,
    login VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255),
    description TEXT,
    url TEXT,
    avatar_url TEXT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Repositories
CREATE TABLE IF NOT EXISTS github_repositories (
    repo_id BIGINT PRIMARY KEY,
    org_login VARCHAR(255) REFERENCES github_organizations(login),
    repo_name VARCHAR(255) NOT NULL,
    full_name VARCHAR(500) UNIQUE NOT NULL,
    description TEXT,
    private BOOLEAN DEFAULT FALSE,
    fork BOOLEAN DEFAULT FALSE,
    default_branch VARCHAR(100),
    language VARCHAR(50),
    size_kb BIGINT,
    stargazers_count INTEGER,
    watchers_count INTEGER,
    forks_count INTEGER,
    open_issues_count INTEGER,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    pushed_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Users/Contributors
CREATE TABLE IF NOT EXISTS github_users (
    user_id BIGINT PRIMARY KEY,
    login VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255),
    email VARCHAR(255),
    avatar_url TEXT,
    user_type VARCHAR(50), -- User, Bot, Organization
    site_admin BOOLEAN DEFAULT FALSE,
    company VARCHAR(255),
    location VARCHAR(255),
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Pull Requests
CREATE TABLE IF NOT EXISTS github_pull_requests (
    pr_id BIGINT PRIMARY KEY,
    repo_full_name VARCHAR(500) REFERENCES github_repositories(full_name),
    pr_number INTEGER NOT NULL,
    title TEXT NOT NULL,
    body TEXT,
    state VARCHAR(20), -- open, closed
    draft BOOLEAN DEFAULT FALSE,
    author_login VARCHAR(255) REFERENCES github_users(login),
    assignees TEXT[], -- Array of logins
    requested_reviewers TEXT[], -- Array of logins
    labels TEXT[], -- Array of label names
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    closed_at TIMESTAMP,
    merged_at TIMESTAMP,
    merged_by_login VARCHAR(255) REFERENCES github_users(login),
    base_branch VARCHAR(255),
    head_branch VARCHAR(255),
    additions INTEGER,
    deletions INTEGER,
    changed_files INTEGER,
    commits_count INTEGER,
    comments_count INTEGER,
    review_comments_count INTEGER,
    synced_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(repo_full_name, pr_number)
);

-- Commits
CREATE TABLE IF NOT EXISTS github_commits (
    commit_sha VARCHAR(40) PRIMARY KEY,
    repo_full_name VARCHAR(500) REFERENCES github_repositories(full_name),
    author_login VARCHAR(255) REFERENCES github_users(login),
    committer_login VARCHAR(255) REFERENCES github_users(login),
    message TEXT,
    committed_at TIMESTAMP,
    additions INTEGER,
    deletions INTEGER,
    total_changes INTEGER,
    files_changed INTEGER,
    parents TEXT[], -- Array of parent SHAs
    synced_at TIMESTAMP DEFAULT NOW()
);

-- PR Commits (many-to-many)
CREATE TABLE IF NOT EXISTS github_pr_commits (
    id SERIAL PRIMARY KEY,
    pr_id BIGINT REFERENCES github_pull_requests(pr_id) ON DELETE CASCADE,
    commit_sha VARCHAR(40) REFERENCES github_commits(commit_sha) ON DELETE CASCADE,
    synced_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(pr_id, commit_sha)
);

-- PR Reviews
CREATE TABLE IF NOT EXISTS github_pr_reviews (
    review_id BIGINT PRIMARY KEY,
    pr_id BIGINT REFERENCES github_pull_requests(pr_id) ON DELETE CASCADE,
    reviewer_login VARCHAR(255) REFERENCES github_users(login),
    state VARCHAR(50), -- APPROVED, CHANGES_REQUESTED, COMMENTED, DISMISSED, PENDING
    body TEXT,
    submitted_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- PR Review Comments
CREATE TABLE IF NOT EXISTS github_pr_review_comments (
    comment_id BIGINT PRIMARY KEY,
    pr_id BIGINT REFERENCES github_pull_requests(pr_id) ON DELETE CASCADE,
    review_id BIGINT REFERENCES github_pr_reviews(review_id) ON DELETE CASCADE,
    author_login VARCHAR(255) REFERENCES github_users(login),
    body TEXT,
    path VARCHAR(500), -- File path
    position INTEGER, -- Line position
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Issues
CREATE TABLE IF NOT EXISTS github_issues (
    issue_id BIGINT PRIMARY KEY,
    repo_full_name VARCHAR(500) REFERENCES github_repositories(full_name),
    issue_number INTEGER NOT NULL,
    title TEXT NOT NULL,
    body TEXT,
    state VARCHAR(20), -- open, closed
    state_reason VARCHAR(50), -- completed, reopened, not_planned
    author_login VARCHAR(255) REFERENCES github_users(login),
    assignees TEXT[], -- Array of logins
    labels TEXT[], -- Array of label names
    milestone_title VARCHAR(255),
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    closed_at TIMESTAMP,
    closed_by_login VARCHAR(255) REFERENCES github_users(login),
    comments_count INTEGER,
    synced_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(repo_full_name, issue_number)
);

-- Issue Comments
CREATE TABLE IF NOT EXISTS github_issue_comments (
    comment_id BIGINT PRIMARY KEY,
    issue_id BIGINT REFERENCES github_issues(issue_id) ON DELETE CASCADE,
    author_login VARCHAR(255) REFERENCES github_users(login),
    body TEXT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Releases
CREATE TABLE IF NOT EXISTS github_releases (
    release_id BIGINT PRIMARY KEY,
    repo_full_name VARCHAR(500) REFERENCES github_repositories(full_name),
    tag_name VARCHAR(255) NOT NULL,
    release_name VARCHAR(500),
    body TEXT,
    draft BOOLEAN DEFAULT FALSE,
    prerelease BOOLEAN DEFAULT FALSE,
    author_login VARCHAR(255) REFERENCES github_users(login),
    created_at TIMESTAMP,
    published_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Workflows (GitHub Actions)
CREATE TABLE IF NOT EXISTS github_workflows (
    workflow_id BIGINT PRIMARY KEY,
    repo_full_name VARCHAR(500) REFERENCES github_repositories(full_name),
    workflow_name VARCHAR(255) NOT NULL,
    path VARCHAR(500),
    state VARCHAR(50), -- active, disabled
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Workflow Runs
CREATE TABLE IF NOT EXISTS github_workflow_runs (
    run_id BIGINT PRIMARY KEY,
    workflow_id BIGINT REFERENCES github_workflows(workflow_id),
    repo_full_name VARCHAR(500) REFERENCES github_repositories(full_name),
    run_number INTEGER,
    status VARCHAR(50), -- queued, in_progress, completed
    conclusion VARCHAR(50), -- success, failure, cancelled, skipped
    head_branch VARCHAR(255),
    head_sha VARCHAR(40),
    triggering_actor_login VARCHAR(255) REFERENCES github_users(login),
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    run_started_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Custom fields for Issues and PRs (GitHub Projects)
CREATE TABLE IF NOT EXISTS github_custom_fields (
    id SERIAL PRIMARY KEY,
    item_type VARCHAR(20), -- issue, pull_request
    item_id BIGINT, -- issue_id or pr_id
    field_name VARCHAR(255),
    field_type VARCHAR(50), -- text, number, date, single_select
    string_value TEXT,
    number_value DECIMAL(20,4),
    date_value TIMESTAMP,
    json_value JSONB,
    synced_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(item_type, item_id, field_name)
);

-- Sync metadata
CREATE TABLE IF NOT EXISTS github_sync_metadata (
    api_endpoint VARCHAR(100) PRIMARY KEY,
    last_sync_timestamp TIMESTAMP NOT NULL,
    last_sync_status VARCHAR(50) DEFAULT 'success',
    records_synced INTEGER DEFAULT 0,
    error_message TEXT,
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_github_repos_org ON github_repositories(org_login);
CREATE INDEX IF NOT EXISTS idx_github_repos_name ON github_repositories(repo_name);
CREATE INDEX IF NOT EXISTS idx_github_repos_updated ON github_repositories(updated_at DESC);

CREATE INDEX IF NOT EXISTS idx_github_users_login ON github_users(login);
CREATE INDEX IF NOT EXISTS idx_github_users_email ON github_users(email);

CREATE INDEX IF NOT EXISTS idx_github_prs_repo ON github_pull_requests(repo_full_name);
CREATE INDEX IF NOT EXISTS idx_github_prs_state ON github_pull_requests(state);
CREATE INDEX IF NOT EXISTS idx_github_prs_author ON github_pull_requests(author_login);
CREATE INDEX IF NOT EXISTS idx_github_prs_created ON github_pull_requests(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_github_prs_merged ON github_pull_requests(merged_at DESC);

CREATE INDEX IF NOT EXISTS idx_github_commits_repo ON github_commits(repo_full_name);
CREATE INDEX IF NOT EXISTS idx_github_commits_author ON github_commits(author_login);
CREATE INDEX IF NOT EXISTS idx_github_commits_date ON github_commits(committed_at DESC);

CREATE INDEX IF NOT EXISTS idx_github_pr_reviews_pr ON github_pr_reviews(pr_id);
CREATE INDEX IF NOT EXISTS idx_github_pr_reviews_reviewer ON github_pr_reviews(reviewer_login);

CREATE INDEX IF NOT EXISTS idx_github_issues_repo ON github_issues(repo_full_name);
CREATE INDEX IF NOT EXISTS idx_github_issues_state ON github_issues(state);
CREATE INDEX IF NOT EXISTS idx_github_issues_author ON github_issues(author_login);
CREATE INDEX IF NOT EXISTS idx_github_issues_created ON github_issues(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_github_workflow_runs_workflow ON github_workflow_runs(workflow_id);
CREATE INDEX IF NOT EXISTS idx_github_workflow_runs_status ON github_workflow_runs(status);

CREATE INDEX IF NOT EXISTS idx_github_custom_fields_item ON github_custom_fields(item_type, item_id);
CREATE INDEX IF NOT EXISTS idx_github_custom_fields_json ON github_custom_fields USING gin(json_value);

-- Comments
COMMENT ON TABLE github_organizations IS 'GitHub organizations';
COMMENT ON TABLE github_repositories IS 'Repositories with metadata';
COMMENT ON TABLE github_users IS 'GitHub users and contributors';
COMMENT ON TABLE github_pull_requests IS 'Pull requests with all metadata';
COMMENT ON TABLE github_commits IS 'Git commits';
COMMENT ON TABLE github_pr_commits IS 'Commits in pull requests';
COMMENT ON TABLE github_pr_reviews IS 'Pull request reviews';
COMMENT ON TABLE github_pr_review_comments IS 'Review comments on code';
COMMENT ON TABLE github_issues IS 'GitHub issues';
COMMENT ON TABLE github_issue_comments IS 'Comments on issues';
COMMENT ON TABLE github_releases IS 'Repository releases';
COMMENT ON TABLE github_workflows IS 'GitHub Actions workflows';
COMMENT ON TABLE github_workflow_runs IS 'Workflow execution history';
COMMENT ON TABLE github_custom_fields IS 'Custom fields from GitHub Projects';
COMMENT ON TABLE github_sync_metadata IS 'Tracks sync status for incremental ingestion';
