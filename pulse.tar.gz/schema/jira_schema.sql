-- JIRA Data PostgreSQL Schema
-- This schema stores incremental data from JIRA APIs

-- Projects table
CREATE TABLE IF NOT EXISTS jira_projects (
    project_key VARCHAR(50) PRIMARY KEY,
    project_id VARCHAR(50) UNIQUE NOT NULL,
    project_name VARCHAR(255),
    project_type VARCHAR(50), -- software, business, service_desk
    lead_account_id VARCHAR(255),
    description TEXT,
    url TEXT,
    created_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Users table (JIRA users/assignees)
CREATE TABLE IF NOT EXISTS jira_users (
    account_id VARCHAR(255) PRIMARY KEY,
    email VARCHAR(255),
    display_name VARCHAR(255),
    active BOOLEAN DEFAULT TRUE,
    time_zone VARCHAR(100),
    account_type VARCHAR(50), -- atlassian, app, customer
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Issues table (main ticket data)
CREATE TABLE IF NOT EXISTS jira_issues (
    issue_id VARCHAR(50) PRIMARY KEY,
    issue_key VARCHAR(50) UNIQUE NOT NULL,
    project_key VARCHAR(50) REFERENCES jira_projects(project_key),
    summary TEXT NOT NULL,
    description TEXT,
    issue_type VARCHAR(50), -- Story, Bug, Task, Epic, Subtask
    status VARCHAR(100),
    priority VARCHAR(50),
    resolution VARCHAR(100),
    assignee_account_id VARCHAR(255) REFERENCES jira_users(account_id),
    reporter_account_id VARCHAR(255) REFERENCES jira_users(account_id),
    creator_account_id VARCHAR(255) REFERENCES jira_users(account_id),
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    resolved_at TIMESTAMP,
    due_date DATE,
    parent_issue_key VARCHAR(50),
    epic_key VARCHAR(50),
    story_points DECIMAL(10,2),
    original_estimate_seconds BIGINT,
    remaining_estimate_seconds BIGINT,
    time_spent_seconds BIGINT,
    labels TEXT[], -- Array of labels
    components TEXT[], -- Array of component names
    fix_versions TEXT[], -- Array of version names
    synced_at TIMESTAMP DEFAULT NOW(),
    CONSTRAINT fk_parent FOREIGN KEY (parent_issue_key) REFERENCES jira_issues(issue_key) ON DELETE SET NULL,
    CONSTRAINT fk_epic FOREIGN KEY (epic_key) REFERENCES jira_issues(issue_key) ON DELETE SET NULL
);

-- Issue transitions/changelog (status changes, assignments, etc.)
CREATE TABLE IF NOT EXISTS jira_issue_changelog (
    id SERIAL PRIMARY KEY,
    issue_key VARCHAR(50) REFERENCES jira_issues(issue_key) ON DELETE CASCADE,
    change_id VARCHAR(50),
    created_at TIMESTAMP,
    author_account_id VARCHAR(255) REFERENCES jira_users(account_id),
    field_name VARCHAR(100), -- status, assignee, priority, etc.
    from_string TEXT,
    to_string TEXT,
    from_value TEXT,
    to_value TEXT,
    synced_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(issue_key, change_id, field_name)
);

-- Comments
CREATE TABLE IF NOT EXISTS jira_comments (
    comment_id VARCHAR(50) PRIMARY KEY,
    issue_key VARCHAR(50) REFERENCES jira_issues(issue_key) ON DELETE CASCADE,
    author_account_id VARCHAR(255) REFERENCES jira_users(account_id),
    body TEXT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Worklogs (time tracking)
CREATE TABLE IF NOT EXISTS jira_worklogs (
    worklog_id VARCHAR(50) PRIMARY KEY,
    issue_key VARCHAR(50) REFERENCES jira_issues(issue_key) ON DELETE CASCADE,
    author_account_id VARCHAR(255) REFERENCES jira_users(account_id),
    time_spent_seconds BIGINT,
    comment TEXT,
    started_at TIMESTAMP,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Boards (Scrum/Kanban)
CREATE TABLE IF NOT EXISTS jira_boards (
    board_id BIGINT PRIMARY KEY,
    board_name VARCHAR(255),
    board_type VARCHAR(50), -- scrum, kanban, simple
    project_key VARCHAR(50) REFERENCES jira_projects(project_key),
    location_type VARCHAR(50),
    location_key VARCHAR(50),
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Sprints
CREATE TABLE IF NOT EXISTS jira_sprints (
    sprint_id BIGINT PRIMARY KEY,
    sprint_name VARCHAR(255),
    board_id BIGINT REFERENCES jira_boards(board_id),
    state VARCHAR(50), -- future, active, closed
    start_date TIMESTAMP,
    end_date TIMESTAMP,
    complete_date TIMESTAMP,
    goal TEXT,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Sprint issues (many-to-many relationship)
CREATE TABLE IF NOT EXISTS jira_sprint_issues (
    id SERIAL PRIMARY KEY,
    sprint_id BIGINT REFERENCES jira_sprints(sprint_id) ON DELETE CASCADE,
    issue_key VARCHAR(50) REFERENCES jira_issues(issue_key) ON DELETE CASCADE,
    added_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(sprint_id, issue_key)
);

-- Issue links (blocks, relates to, etc.)
CREATE TABLE IF NOT EXISTS jira_issue_links (
    link_id BIGINT PRIMARY KEY,
    link_type VARCHAR(100), -- Blocks, Clones, Duplicates, Relates
    inward_issue_key VARCHAR(50) REFERENCES jira_issues(issue_key) ON DELETE CASCADE,
    outward_issue_key VARCHAR(50) REFERENCES jira_issues(issue_key) ON DELETE CASCADE,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Attachments metadata
CREATE TABLE IF NOT EXISTS jira_attachments (
    attachment_id VARCHAR(50) PRIMARY KEY,
    issue_key VARCHAR(50) REFERENCES jira_issues(issue_key) ON DELETE CASCADE,
    filename VARCHAR(500),
    author_account_id VARCHAR(255) REFERENCES jira_users(account_id),
    created_at TIMESTAMP,
    size_bytes BIGINT,
    mime_type VARCHAR(100),
    content_url TEXT,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Custom fields (flexible storage for any custom field)
CREATE TABLE IF NOT EXISTS jira_custom_fields (
    id SERIAL PRIMARY KEY,
    issue_key VARCHAR(50) REFERENCES jira_issues(issue_key) ON DELETE CASCADE,
    field_id VARCHAR(100), -- e.g., customfield_10016
    field_name VARCHAR(255), -- e.g., Story Points, Sprint
    field_type VARCHAR(50), -- string, number, date, array, object
    string_value TEXT,
    number_value DECIMAL(20,4),
    date_value TIMESTAMP,
    json_value JSONB, -- For complex objects/arrays
    synced_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(issue_key, field_id)
);

-- Sync metadata table (tracks last successful sync)
CREATE TABLE IF NOT EXISTS jira_sync_metadata (
    api_endpoint VARCHAR(100) PRIMARY KEY,
    last_sync_timestamp TIMESTAMP NOT NULL,
    last_sync_status VARCHAR(50) DEFAULT 'success',
    records_synced INTEGER DEFAULT 0,
    error_message TEXT,
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_jira_projects_key ON jira_projects(project_key);

CREATE INDEX IF NOT EXISTS idx_jira_users_email ON jira_users(email);
CREATE INDEX IF NOT EXISTS idx_jira_users_active ON jira_users(active);

CREATE INDEX IF NOT EXISTS idx_jira_issues_key ON jira_issues(issue_key);
CREATE INDEX IF NOT EXISTS idx_jira_issues_project ON jira_issues(project_key);
CREATE INDEX IF NOT EXISTS idx_jira_issues_status ON jira_issues(status);
CREATE INDEX IF NOT EXISTS idx_jira_issues_assignee ON jira_issues(assignee_account_id);
CREATE INDEX IF NOT EXISTS idx_jira_issues_reporter ON jira_issues(reporter_account_id);
CREATE INDEX IF NOT EXISTS idx_jira_issues_created ON jira_issues(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_jira_issues_updated ON jira_issues(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_jira_issues_type ON jira_issues(issue_type);
CREATE INDEX IF NOT EXISTS idx_jira_issues_epic ON jira_issues(epic_key);

CREATE INDEX IF NOT EXISTS idx_jira_changelog_issue ON jira_issue_changelog(issue_key);
CREATE INDEX IF NOT EXISTS idx_jira_changelog_created ON jira_issue_changelog(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_jira_changelog_field ON jira_issue_changelog(field_name);

CREATE INDEX IF NOT EXISTS idx_jira_comments_issue ON jira_comments(issue_key);
CREATE INDEX IF NOT EXISTS idx_jira_comments_author ON jira_comments(author_account_id);
CREATE INDEX IF NOT EXISTS idx_jira_comments_created ON jira_comments(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_jira_worklogs_issue ON jira_worklogs(issue_key);
CREATE INDEX IF NOT EXISTS idx_jira_worklogs_author ON jira_worklogs(author_account_id);
CREATE INDEX IF NOT EXISTS idx_jira_worklogs_started ON jira_worklogs(started_at DESC);

CREATE INDEX IF NOT EXISTS idx_jira_boards_project ON jira_boards(project_key);
CREATE INDEX IF NOT EXISTS idx_jira_boards_type ON jira_boards(board_type);

CREATE INDEX IF NOT EXISTS idx_jira_sprints_board ON jira_sprints(board_id);
CREATE INDEX IF NOT EXISTS idx_jira_sprints_state ON jira_sprints(state);
CREATE INDEX IF NOT EXISTS idx_jira_sprints_start ON jira_sprints(start_date DESC);

CREATE INDEX IF NOT EXISTS idx_jira_sprint_issues_sprint ON jira_sprint_issues(sprint_id);
CREATE INDEX IF NOT EXISTS idx_jira_sprint_issues_issue ON jira_sprint_issues(issue_key);

CREATE INDEX IF NOT EXISTS idx_jira_links_inward ON jira_issue_links(inward_issue_key);
CREATE INDEX IF NOT EXISTS idx_jira_links_outward ON jira_issue_links(outward_issue_key);

CREATE INDEX IF NOT EXISTS idx_jira_attachments_issue ON jira_attachments(issue_key);

CREATE INDEX IF NOT EXISTS idx_jira_custom_fields_issue ON jira_custom_fields(issue_key);
CREATE INDEX IF NOT EXISTS idx_jira_custom_fields_field_id ON jira_custom_fields(field_id);
CREATE INDEX IF NOT EXISTS idx_jira_custom_fields_json ON jira_custom_fields USING gin(json_value);

-- Comments
COMMENT ON TABLE jira_projects IS 'JIRA projects and their metadata';
COMMENT ON TABLE jira_users IS 'JIRA users (assignees, reporters, etc.)';
COMMENT ON TABLE jira_issues IS 'Main JIRA issues/tickets table with all fields';
COMMENT ON TABLE jira_issue_changelog IS 'History of changes to issues (status, assignee, etc.)';
COMMENT ON TABLE jira_comments IS 'Comments on issues';
COMMENT ON TABLE jira_worklogs IS 'Time tracking worklogs';
COMMENT ON TABLE jira_boards IS 'Scrum and Kanban boards';
COMMENT ON TABLE jira_sprints IS 'Sprint definitions';
COMMENT ON TABLE jira_sprint_issues IS 'Issues in sprints (many-to-many)';
COMMENT ON TABLE jira_issue_links IS 'Links between issues (blocks, relates, etc.)';
COMMENT ON TABLE jira_attachments IS 'File attachments metadata';
COMMENT ON TABLE jira_custom_fields IS 'Flexible storage for all custom fields with JSONB support';
COMMENT ON TABLE jira_sync_metadata IS 'Tracks sync status for incremental ingestion';
