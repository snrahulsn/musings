-- Windsurf Analytics PostgreSQL Schema
-- This schema stores incremental data from Windsurf APIs

-- User activity table (from UserPageAnalytics API)
CREATE TABLE IF NOT EXISTS windsurf_users (
    email VARCHAR(255) PRIMARY KEY,
    name VARCHAR(255),
    api_key_hash VARCHAR(255),
    active_days INTEGER,
    disable_codeium BOOLEAN DEFAULT FALSE,
    last_update_time TIMESTAMP,
    last_autocomplete_usage_time TIMESTAMP,
    last_chat_usage_time TIMESTAMP,
    last_command_usage_time TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW(),
    CONSTRAINT windsurf_users_email_check CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);

-- Cascade lines (from CascadeAnalytics API)
CREATE TABLE IF NOT EXISTS windsurf_cascade_lines (
    id SERIAL PRIMARY KEY,
    day DATE NOT NULL,
    email VARCHAR(255),
    lines_suggested INTEGER DEFAULT 0,
    lines_accepted INTEGER DEFAULT 0,
    synced_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(day, email)
);

-- Cascade runs (from CascadeAnalytics API)
CREATE TABLE IF NOT EXISTS windsurf_cascade_runs (
    cascade_id VARCHAR(255) PRIMARY KEY,
    day DATE NOT NULL,
    email VARCHAR(255),
    model VARCHAR(100),
    mode VARCHAR(50), -- DEFAULT, READ_ONLY, NO_TOOL, UNKNOWN
    messages_sent INTEGER DEFAULT 0,
    prompts_used INTEGER DEFAULT 0,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Cascade tool usage (from CascadeAnalytics API)
CREATE TABLE IF NOT EXISTS windsurf_cascade_tools (
    id SERIAL PRIMARY KEY,
    day DATE NOT NULL,
    email VARCHAR(255),
    tool VARCHAR(100) NOT NULL,
    count INTEGER DEFAULT 0,
    synced_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(day, email, tool)
);

-- Autocomplete data (from CustomAnalytics API - USER_DATA)
CREATE TABLE IF NOT EXISTS windsurf_autocomplete (
    id SERIAL PRIMARY KEY,
    date DATE NOT NULL,
    email VARCHAR(255),
    language VARCHAR(50),
    ide VARCHAR(50),
    num_acceptances INTEGER DEFAULT 0,
    num_lines_accepted INTEGER DEFAULT 0,
    synced_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(date, email, language, ide)
);

-- Chat data (from CustomAnalytics API - CHAT_DATA)
CREATE TABLE IF NOT EXISTS windsurf_chat (
    id SERIAL PRIMARY KEY,
    date DATE NOT NULL,
    email VARCHAR(255),
    model_id VARCHAR(100),
    latest_intent_type VARCHAR(100),
    num_chats_received INTEGER DEFAULT 0,
    chat_accepted INTEGER DEFAULT 0,
    chat_inserted_at_cursor INTEGER DEFAULT 0,
    synced_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(date, email, model_id, latest_intent_type)
);

-- Command data (from CustomAnalytics API - COMMAND_DATA)
CREATE TABLE IF NOT EXISTS windsurf_commands (
    id SERIAL PRIMARY KEY,
    date DATE NOT NULL,
    email VARCHAR(255),
    language VARCHAR(50),
    ide VARCHAR(50),
    command_source VARCHAR(100),
    provider_source VARCHAR(100),
    lines_added INTEGER DEFAULT 0,
    lines_removed INTEGER DEFAULT 0,
    accepted BOOLEAN,
    synced_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(date, email, language, ide, command_source, provider_source, accepted)
);

-- Percent Code Written (from CustomAnalytics API - PCW_DATA)
CREATE TABLE IF NOT EXISTS windsurf_code_written (
    id SERIAL PRIMARY KEY,
    date DATE NOT NULL,
    email VARCHAR(255),
    percent_code_written DECIMAL(5,2),
    codeium_bytes BIGINT DEFAULT 0,
    user_bytes BIGINT DEFAULT 0,
    codeium_bytes_by_autocomplete BIGINT DEFAULT 0,
    codeium_bytes_by_command BIGINT DEFAULT 0,
    synced_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(date, email)
);

-- Sync metadata table (tracks last successful sync)
CREATE TABLE IF NOT EXISTS windsurf_sync_metadata (
    api_endpoint VARCHAR(100) PRIMARY KEY,
    last_sync_timestamp TIMESTAMP NOT NULL,
    last_sync_status VARCHAR(50) DEFAULT 'success',
    records_synced INTEGER DEFAULT 0,
    error_message TEXT,
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_windsurf_users_email ON windsurf_users(email);
CREATE INDEX IF NOT EXISTS idx_windsurf_users_last_update ON windsurf_users(last_update_time DESC);

CREATE INDEX IF NOT EXISTS idx_cascade_lines_day ON windsurf_cascade_lines(day DESC);
CREATE INDEX IF NOT EXISTS idx_cascade_lines_email ON windsurf_cascade_lines(email);

CREATE INDEX IF NOT EXISTS idx_cascade_runs_day ON windsurf_cascade_runs(day DESC);
CREATE INDEX IF NOT EXISTS idx_cascade_runs_email ON windsurf_cascade_runs(email);

CREATE INDEX IF NOT EXISTS idx_cascade_tools_day ON windsurf_cascade_tools(day DESC);
CREATE INDEX IF NOT EXISTS idx_cascade_tools_email ON windsurf_cascade_tools(email);

CREATE INDEX IF NOT EXISTS idx_autocomplete_date ON windsurf_autocomplete(date DESC);
CREATE INDEX IF NOT EXISTS idx_autocomplete_email ON windsurf_autocomplete(email);

CREATE INDEX IF NOT EXISTS idx_chat_date ON windsurf_chat(date DESC);
CREATE INDEX IF NOT EXISTS idx_chat_email ON windsurf_chat(email);

CREATE INDEX IF NOT EXISTS idx_commands_date ON windsurf_commands(date DESC);
CREATE INDEX IF NOT EXISTS idx_commands_email ON windsurf_commands(email);

CREATE INDEX IF NOT EXISTS idx_code_written_date ON windsurf_code_written(date DESC);
CREATE INDEX IF NOT EXISTS idx_code_written_email ON windsurf_code_written(email);

-- Comments
COMMENT ON TABLE windsurf_users IS 'User activity and profile data from Windsurf UserPageAnalytics API';
COMMENT ON TABLE windsurf_cascade_lines IS 'Daily cascade lines suggested and accepted per user';
COMMENT ON TABLE windsurf_cascade_runs IS 'Cascade execution runs with model and mode information';
COMMENT ON TABLE windsurf_cascade_tools IS 'Tool usage statistics from cascade runs';
COMMENT ON TABLE windsurf_autocomplete IS 'Autocomplete acceptance metrics by language and IDE';
COMMENT ON TABLE windsurf_chat IS 'Chat interaction metrics including intent types';
COMMENT ON TABLE windsurf_commands IS 'Command execution data with acceptance status';
COMMENT ON TABLE windsurf_code_written IS 'Percent of code written by AI vs user';
COMMENT ON TABLE windsurf_sync_metadata IS 'Tracks sync status for incremental ingestion';
