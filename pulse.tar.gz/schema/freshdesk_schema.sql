-- Freshdesk Data PostgreSQL Schema
-- This schema stores incremental data from Freshdesk APIs

-- Agents
CREATE TABLE IF NOT EXISTS freshdesk_agents (
    agent_id BIGINT PRIMARY KEY,
    email VARCHAR(255),
    name VARCHAR(255),
    role_name VARCHAR(100), -- Agent, Admin, Account Admin
    signature TEXT,
    available BOOLEAN DEFAULT TRUE,
    occasional BOOLEAN DEFAULT FALSE,
    ticket_scope INTEGER, -- 1=Global, 2=Group, 3=Restricted
    group_ids BIGINT[], -- Array of group IDs
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Groups
CREATE TABLE IF NOT EXISTS freshdesk_groups (
    group_id BIGINT PRIMARY KEY,
    group_name VARCHAR(255) NOT NULL,
    description TEXT,
    escalate_to_agent_id BIGINT REFERENCES freshdesk_agents(agent_id),
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Companies
CREATE TABLE IF NOT EXISTS freshdesk_companies (
    company_id BIGINT PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    description TEXT,
    domains TEXT[], -- Array of domains
    health_score VARCHAR(50),
    account_tier VARCHAR(50),
    renewal_date DATE,
    industry VARCHAR(100),
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Contacts (Requesters)
CREATE TABLE IF NOT EXISTS freshdesk_contacts (
    contact_id BIGINT PRIMARY KEY,
    name VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(50),
    mobile VARCHAR(50),
    company_id BIGINT REFERENCES freshdesk_companies(company_id),
    job_title VARCHAR(255),
    language VARCHAR(50),
    time_zone VARCHAR(100),
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Tickets
CREATE TABLE IF NOT EXISTS freshdesk_tickets (
    ticket_id BIGINT PRIMARY KEY,
    display_id BIGINT UNIQUE NOT NULL, -- Friendly ticket number
    subject TEXT NOT NULL,
    description TEXT,
    description_text TEXT, -- Plain text version
    status VARCHAR(50), -- Open, Pending, Resolved, Closed
    priority VARCHAR(50), -- Low, Medium, High, Urgent
    ticket_type VARCHAR(100), -- Question, Incident, Problem, Feature Request
    source VARCHAR(50), -- Email, Portal, Phone, Chat, Feedback Widget
    requester_id BIGINT REFERENCES freshdesk_contacts(contact_id),
    responder_id BIGINT REFERENCES freshdesk_agents(agent_id),
    group_id BIGINT REFERENCES freshdesk_groups(group_id),
    company_id BIGINT REFERENCES freshdesk_companies(company_id),
    product_id BIGINT,
    tags TEXT[], -- Array of tags
    cc_emails TEXT[], -- Array of CC'd emails
    fwd_emails TEXT[], -- Array of forwarded emails
    spam BOOLEAN DEFAULT FALSE,
    deleted BOOLEAN DEFAULT FALSE,
    fr_escalated BOOLEAN DEFAULT FALSE, -- First response escalated
    fr_due_by TIMESTAMP, -- First response due by
    is_escalated BOOLEAN DEFAULT FALSE,
    due_by TIMESTAMP, -- Resolution due by
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    resolved_at TIMESTAMP,
    closed_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Conversations (Ticket replies and notes)
CREATE TABLE IF NOT EXISTS freshdesk_conversations (
    conversation_id BIGINT PRIMARY KEY,
    ticket_id BIGINT REFERENCES freshdesk_tickets(ticket_id) ON DELETE CASCADE,
    body TEXT,
    body_text TEXT, -- Plain text version
    user_id BIGINT, -- Can be agent_id or contact_id
    incoming BOOLEAN, -- True if from customer, false if from agent
    private BOOLEAN DEFAULT FALSE, -- Private note vs public reply
    source VARCHAR(50), -- Reply, Note, Email, Phone
    to_emails TEXT[], -- Array of recipient emails
    from_email VARCHAR(255),
    cc_emails TEXT[], -- Array of CC'd emails
    bcc_emails TEXT[], -- Array of BCC'd emails
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Ticket Time Entries
CREATE TABLE IF NOT EXISTS freshdesk_time_entries (
    time_entry_id BIGINT PRIMARY KEY,
    ticket_id BIGINT REFERENCES freshdesk_tickets(ticket_id) ON DELETE CASCADE,
    agent_id BIGINT REFERENCES freshdesk_agents(agent_id),
    time_spent_seconds BIGINT,
    billable BOOLEAN DEFAULT FALSE,
    note TEXT,
    executed_at TIMESTAMP,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Ticket Field Descriptions (for custom fields)
CREATE TABLE IF NOT EXISTS freshdesk_ticket_fields (
    field_id BIGINT PRIMARY KEY,
    field_name VARCHAR(255) NOT NULL,
    label VARCHAR(255),
    field_type VARCHAR(50), -- custom_text, custom_number, custom_date, custom_dropdown
    default_value TEXT,
    choices TEXT[], -- Array of choices for dropdown
    required_for_closure BOOLEAN DEFAULT FALSE,
    required_for_agents BOOLEAN DEFAULT FALSE,
    required_for_customers BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Custom field values
CREATE TABLE IF NOT EXISTS freshdesk_custom_fields (
    id SERIAL PRIMARY KEY,
    ticket_id BIGINT REFERENCES freshdesk_tickets(ticket_id) ON DELETE CASCADE,
    field_id BIGINT,
    field_name VARCHAR(255),
    field_type VARCHAR(50), -- text, number, date, dropdown, checkbox
    string_value TEXT,
    number_value DECIMAL(20,4),
    date_value TIMESTAMP,
    boolean_value BOOLEAN,
    json_value JSONB, -- For complex values
    synced_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(ticket_id, field_id)
);

-- Satisfaction Ratings (CSAT)
CREATE TABLE IF NOT EXISTS freshdesk_satisfaction_ratings (
    rating_id BIGINT PRIMARY KEY,
    ticket_id BIGINT REFERENCES freshdesk_tickets(ticket_id) ON DELETE CASCADE,
    agent_id BIGINT REFERENCES freshdesk_agents(agent_id),
    group_id BIGINT REFERENCES freshdesk_groups(group_id),
    rating VARCHAR(50), -- good, okay, bad
    feedback TEXT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- SLA Policies
CREATE TABLE IF NOT EXISTS freshdesk_sla_policies (
    sla_policy_id BIGINT PRIMARY KEY,
    policy_name VARCHAR(255) NOT NULL,
    description TEXT,
    is_default BOOLEAN DEFAULT FALSE,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Products
CREATE TABLE IF NOT EXISTS freshdesk_products (
    product_id BIGINT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    synced_at TIMESTAMP DEFAULT NOW()
);

-- Sync metadata
CREATE TABLE IF NOT EXISTS freshdesk_sync_metadata (
    api_endpoint VARCHAR(100) PRIMARY KEY,
    last_sync_timestamp TIMESTAMP NOT NULL,
    last_sync_status VARCHAR(50) DEFAULT 'success',
    records_synced INTEGER DEFAULT 0,
    error_message TEXT,
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_freshdesk_agents_email ON freshdesk_agents(email);
CREATE INDEX IF NOT EXISTS idx_freshdesk_agents_role ON freshdesk_agents(role_name);

CREATE INDEX IF NOT EXISTS idx_freshdesk_contacts_email ON freshdesk_contacts(email);
CREATE INDEX IF NOT EXISTS idx_freshdesk_contacts_company ON freshdesk_contacts(company_id);

CREATE INDEX IF NOT EXISTS idx_freshdesk_tickets_display_id ON freshdesk_tickets(display_id);
CREATE INDEX IF NOT EXISTS idx_freshdesk_tickets_status ON freshdesk_tickets(status);
CREATE INDEX IF NOT EXISTS idx_freshdesk_tickets_priority ON freshdesk_tickets(priority);
CREATE INDEX IF NOT EXISTS idx_freshdesk_tickets_requester ON freshdesk_tickets(requester_id);
CREATE INDEX IF NOT EXISTS idx_freshdesk_tickets_responder ON freshdesk_tickets(responder_id);
CREATE INDEX IF NOT EXISTS idx_freshdesk_tickets_group ON freshdesk_tickets(group_id);
CREATE INDEX IF NOT EXISTS idx_freshdesk_tickets_company ON freshdesk_tickets(company_id);
CREATE INDEX IF NOT EXISTS idx_freshdesk_tickets_created ON freshdesk_tickets(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_freshdesk_tickets_updated ON freshdesk_tickets(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_freshdesk_tickets_resolved ON freshdesk_tickets(resolved_at DESC);

CREATE INDEX IF NOT EXISTS idx_freshdesk_conversations_ticket ON freshdesk_conversations(ticket_id);
CREATE INDEX IF NOT EXISTS idx_freshdesk_conversations_user ON freshdesk_conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_freshdesk_conversations_created ON freshdesk_conversations(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_freshdesk_time_entries_ticket ON freshdesk_time_entries(ticket_id);
CREATE INDEX IF NOT EXISTS idx_freshdesk_time_entries_agent ON freshdesk_time_entries(agent_id);

CREATE INDEX IF NOT EXISTS idx_freshdesk_custom_fields_ticket ON freshdesk_custom_fields(ticket_id);
CREATE INDEX IF NOT EXISTS idx_freshdesk_custom_fields_field ON freshdesk_custom_fields(field_id);
CREATE INDEX IF NOT EXISTS idx_freshdesk_custom_fields_json ON freshdesk_custom_fields USING gin(json_value);

CREATE INDEX IF NOT EXISTS idx_freshdesk_ratings_ticket ON freshdesk_satisfaction_ratings(ticket_id);
CREATE INDEX IF NOT EXISTS idx_freshdesk_ratings_agent ON freshdesk_satisfaction_ratings(agent_id);
CREATE INDEX IF NOT EXISTS idx_freshdesk_ratings_rating ON freshdesk_satisfaction_ratings(rating);

-- Comments
COMMENT ON TABLE freshdesk_agents IS 'Support agents and admins';
COMMENT ON TABLE freshdesk_groups IS 'Agent groups/teams';
COMMENT ON TABLE freshdesk_companies IS 'Customer companies';
COMMENT ON TABLE freshdesk_contacts IS 'Customer contacts/requesters';
COMMENT ON TABLE freshdesk_tickets IS 'Support tickets with all metadata';
COMMENT ON TABLE freshdesk_conversations IS 'Ticket replies and notes';
COMMENT ON TABLE freshdesk_time_entries IS 'Time tracking on tickets';
COMMENT ON TABLE freshdesk_ticket_fields IS 'Custom field definitions';
COMMENT ON TABLE freshdesk_custom_fields IS 'Custom field values for tickets';
COMMENT ON TABLE freshdesk_satisfaction_ratings IS 'Customer satisfaction ratings (CSAT)';
COMMENT ON TABLE freshdesk_sla_policies IS 'SLA policy definitions';
COMMENT ON TABLE freshdesk_products IS 'Product catalog';
COMMENT ON TABLE freshdesk_sync_metadata IS 'Tracks sync status for incremental ingestion';
