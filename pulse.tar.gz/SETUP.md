# Pulse - Complete Setup Guide

Production-grade chatbot for operational metrics tracking across Windsurf, JIRA, GitHub, and Freshdesk.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     Application Layer                        │
│  ┌──────────────┐  ┌─────────────┐  ┌──────────────────┐   │
│  │   Chainlit   │  │   Vanna     │  │  Query Router    │   │
│  │     UI       │  │ (Text2SQL)  │  │                  │   │
│  └──────────────┘  └─────────────┘  └──────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                      Data Layer                              │
│  ┌──────────────┐  ┌─────────────┐  ┌──────────────────┐   │
│  │  PostgreSQL  │  │   Qdrant    │  │     Redis        │   │
│  │ (Structured) │  │  (Vectors)  │  │    (Cache)       │   │
│  └──────────────┘  └─────────────┘  └──────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                  Orchestration Layer                         │
│  ┌──────────────┐  ┌─────────────┐  ┌──────────────────┐   │
│  │   Prefect    │  │   Ollama    │  │  Claude API      │   │
│  │  (Workflows) │  │ (Embeddings)│  │   (LLM)          │   │
│  └──────────────┘  └─────────────┘  └──────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                  Monitoring Layer                            │
│  ┌──────────────┐  ┌─────────────┐  ┌──────────────────┐   │
│  │   Grafana    │  │     Loki    │  │    Promtail      │   │
│  │ (Dashboards) │  │    (Logs)   │  │  (Log Shipper)   │   │
│  └──────────────┘  └─────────────┘  └──────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

## Service Ports

| Service | Port | URL | Purpose |
|---------|------|-----|---------|
| PostgreSQL | 5432 | localhost:5432 | Main database |
| Qdrant | 6333 | http://localhost:6333 | Vector database |
| Ollama | 11434 | http://localhost:11434 | Embedding model |
| Redis | 6379 | localhost:6379 | Cache |
| Prefect | 4200 | http://localhost:4200 | Workflow UI |
| Grafana | 3000 | http://localhost:3000 | Monitoring UI |
| Loki | 3100 | http://localhost:3100 | Log aggregation |
| Chainlit | 8000 | http://localhost:8000 | Chat UI (future) |

## Prerequisites

- **Docker** & Docker Compose
- **Python 3.9+**
- **Git**
- **4GB+ RAM** (Ollama requires memory)
- **10GB+ disk space**

## Step 1: Clone and Setup

```bash
cd /Users/rahulnatarajan/Documents/pulse_final

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Create .env from template
cp .env.example .env
```

## Step 2: Configure Environment

Edit `.env` and add:

```bash
# Required: Windsurf service key
WINDSURF_SERVICE_KEY=your_actual_service_key

# Required: Anthropic API key
ANTHROPIC_API_KEY=your_anthropic_api_key

# Optional: Change default passwords
DB_PASSWORD=your_secure_password
GRAFANA_PASSWORD=your_grafana_password
```

## Step 3: Start Infrastructure

```bash
# Start all services
docker compose up -d

# Check status
docker compose ps

# View logs
docker compose logs -f
```

**Services starting:**
- PostgreSQL (with schema auto-loaded)
- Qdrant
- Ollama
- Redis
- Prefect Server
- Loki
- Promtail
- Grafana

## Step 4: Initialize Ollama Embedding Model

```bash
# Pull nomic-embed-text model (required for similarity search)
docker exec -it pulse_ollama ollama pull nomic-embed-text

# Verify
docker exec -it pulse_ollama ollama list
```

## Step 5: Verify Services

### Check PostgreSQL

```bash
# Connect to database
docker exec -it pulse_postgres psql -U pulse_user -d pulse

# List tables
\dt

# Should see:
# - windsurf_users
# - windsurf_cascade_lines
# - windsurf_cascade_runs
# ... (9 tables total)

\q
```

### Check Qdrant

```bash
curl http://localhost:6333/health
# Expected: {"title":"healthz","version":"1.x.x"}
```

### Check Prefect

Open http://localhost:4200 in browser. Should see Prefect UI.

### Check Grafana

Open http://localhost:3000 in browser.
- Username: `admin`
- Password: Value from `.env` (default: `admin`)

## Step 6: Deploy Prefect Flows

```bash
# Activate venv
source venv/bin/activate

# Deploy flows with schedules
python deploy_flows.py
```

This starts:
- **Windsurf Incremental Sync**: Every hour
- **Windsurf Full Sync**: Daily at 2 AM UTC

Leave this running in a terminal or use a process manager (systemd, supervisor, etc.)

## Step 7: Run First Ingestion

### Manual Run

```bash
source venv/bin/activate
python ingestors/windsurf_ingestor.py
```

### Via Prefect (Recommended)

Go to http://localhost:4200 and click "Quick Run" on any deployment.

## Step 8: Configure Grafana Dashboards

1. Open http://localhost:3000
2. Login (admin/admin)
3. Go to **Configuration > Data Sources**
4. Verify:
   - Loki (for logs)
   - Pulse PostgreSQL (for metrics)
5. Import dashboards:
   - Navigate to **Dashboards > Import**
   - Use dashboard JSON files (create custom ones)

### Sample Grafana Queries

**User Activity Over Time:**
```sql
SELECT
  date_trunc('day', last_update_time) as time,
  count(*) as active_users
FROM windsurf_users
WHERE last_update_time >= NOW() - INTERVAL '30 days'
GROUP BY 1
ORDER BY 1
```

**Cascade Lines Accepted (7 days):**
```sql
SELECT
  day as time,
  SUM(lines_accepted) as lines
FROM windsurf_cascade_lines
WHERE day >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY day
ORDER BY day
```

## Step 9: Monitor Logs in Grafana

1. Go to **Explore** in Grafana
2. Select **Loki** datasource
3. Query examples:
   ```
   {app="windsurf_ingestor"}
   {app="prefect"} |= "error"
   {job="pulse"} |= "failed"
   ```

## Step 10: Test End-to-End

```bash
# Run test suite
source venv/bin/activate
python tests/test_windsurf_setup.py

# Should see all tests pass
```

## Monitoring & Troubleshooting

### View Service Logs

```bash
# All services
docker compose logs -f

# Specific service
docker compose logs -f postgres
docker compose logs -f prefect-server
docker compose logs -f loki
```

### Check Prefect Flow Runs

```bash
# Via UI
open http://localhost:4200

# Via CLI
source venv/bin/activate
prefect deployment ls
prefect flow-run ls --limit 10
```

### Database Queries

```bash
# Check sync status
docker exec -it pulse_postgres psql -U pulse_user -d pulse -c "
SELECT * FROM windsurf_sync_metadata ORDER BY updated_at DESC;
"

# Count records
docker exec -it pulse_postgres psql -U pulse_user -d pulse -c "
SELECT
  'users' as table_name, COUNT(*) as count FROM windsurf_users
UNION ALL
SELECT 'cascade_lines', COUNT(*) FROM windsurf_cascade_lines
UNION ALL
SELECT 'cascade_runs', COUNT(*) FROM windsurf_cascade_runs;
"
```

### Common Issues

**"Connection refused" to PostgreSQL:**
```bash
# Check if container is running
docker compose ps postgres

# Restart
docker compose restart postgres
```

**Prefect flows not running:**
```bash
# Check Prefect server
curl http://localhost:4200/api/health

# Restart Prefect
docker compose restart prefect-server
```

**Ollama model not loading:**
```bash
# Check Ollama
docker logs pulse_ollama

# Re-pull model
docker exec -it pulse_ollama ollama pull nomic-embed-text
```

## Stopping Services

```bash
# Stop all services
docker compose down

# Stop and remove volumes (CAREFUL: deletes all data)
docker compose down -v
```

## Backup & Restore

### Backup PostgreSQL

```bash
docker exec pulse_postgres pg_dump -U pulse_user pulse > backup_$(date +%Y%m%d).sql
```

### Restore PostgreSQL

```bash
cat backup_20251009.sql | docker exec -i pulse_postgres psql -U pulse_user pulse
```

### Backup Qdrant

```bash
docker exec pulse_qdrant tar czf /qdrant/backup.tar.gz /qdrant/storage
docker cp pulse_qdrant:/qdrant/backup.tar.gz ./qdrant_backup_$(date +%Y%m%d).tar.gz
```

## Production Deployment Checklist

- [ ] Change all default passwords in `.env`
- [ ] Set up SSL/TLS for external services
- [ ] Configure firewall rules
- [ ] Set up automated backups
- [ ] Enable Grafana alerts
- [ ] Configure log retention policies
- [ ] Set up monitoring alerts (Slack/email)
- [ ] Document runbooks for common issues
- [ ] Test disaster recovery procedures
- [ ] Set up CI/CD for flow deployments

## Next Steps

1. ✅ Windsurf data ingestion running
2. Build JIRA, GitHub, Freshdesk ingestors (same pattern)
3. Implement Vanna for text-to-SQL queries
4. Add Qdrant similarity search
5. Build Chainlit chat UI
6. Create Grafana dashboards for operational metrics
7. Add cross-source analytics queries

## Architecture Decisions

### Why Prefect over Airflow?
- Lighter weight
- Better Python-native API
- Built-in retries and monitoring
- Easier local development

### Why Qdrant over Pinecone/Weaviate?
- FOSS and self-hosted
- Superior filtering (metadata + vector)
- Better performance for our scale

### Why Vanna for Text-to-SQL?
- Self-learning (improves over time)
- Works with any SQL database
- Built-in visualization support

### Why Loki over ELK Stack?
- Lighter weight
- Purpose-built for logs
- Native Grafana integration
- Lower resource footprint

## Support

- **Docs**: See README_WINDSURF.md for Windsurf-specific details
- **Logs**: Check `logs/` directory
- **Grafana**: http://localhost:3000
- **Prefect UI**: http://localhost:4200

## File Structure

```
pulse_final/
├── config/                      # Service configurations
│   ├── loki-config.yml
│   ├── promtail-config.yml
│   └── grafana-datasources.yml
├── flows/                       # Prefect workflows
│   └── windsurf_flow.py
├── ingestors/                   # Data ingestion scripts
│   └── windsurf_ingestor.py
├── logs/                        # Application logs
├── schema/                      # Database schemas
│   └── windsurf_schema.sql
├── tests/                       # Test suites
│   └── test_windsurf_setup.py
├── venv/                        # Python virtual environment
├── docker-compose.yml           # Infrastructure definition
├── deploy_flows.py              # Prefect deployment script
├── requirements.txt             # Python dependencies
├── .env.example                 # Configuration template
├── .env                         # Your configuration (gitignored)
├── SETUP.md                     # This file
├── QUICKSTART.md                # Quick setup guide
├── README_WINDSURF.md           # Windsurf-specific docs
└── WINDSURF_ANALYSIS.md         # Data analysis reference
```

**You're now running a production-grade data pipeline!**
