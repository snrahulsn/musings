"""
GitHub Data Ingestion Prefect Flow

This module defines Prefect flows for GitHub data ingestion:
- github_sync_flow: Full sync with configurable lookback
- github_incremental_flow: Incremental sync for recent changes
"""

from prefect import flow, task
from prefect.task_runners import ConcurrentTaskRunner
from datetime import timedelta
import logging
import os
import sys

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ingestors.github_ingestor import GitHubIngestor

# Configure logging to write to file for Loki ingestion
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/github_flow.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


@task(name="validate-github-config", retries=0, retry_delay_seconds=10)
def validate_config():
    """Validate GitHub configuration"""
    required_vars = ['GITHUB_TOKEN', 'GITHUB_ORG']
    missing = [var for var in required_vars if not os.getenv(var)]

    if missing:
        raise ValueError(f"Missing required environment variables: {', '.join(missing)}")

    logger.info("✅ GitHub configuration validated")
    return True


@task(name="ingest-github-org", retries=2, retry_delay_seconds=60)
def ingest_organization():
    """Ingest GitHub organization metadata"""
    logger.info("Starting GitHub organization ingestion...")
    ingestor = GitHubIngestor()
    try:
        ingestor.ingest_organization()
        logger.info("✅ Organization ingestion completed")
        return True
    except Exception as e:
        logger.error(f"❌ Organization ingestion failed: {e}")
        raise
    finally:
        ingestor.close_db()


@task(name="ingest-github-repos", retries=2, retry_delay_seconds=60)
def ingest_repositories(repo_names=None):
    """
    Ingest GitHub repositories

    Args:
        repo_names: List of repository names to sync (None = all repos)
    """
    logger.info(f"Starting GitHub repositories ingestion (repos: {repo_names or 'all'})...")
    ingestor = GitHubIngestor()
    try:
        ingestor.ingest_repositories(repo_names)
        logger.info("✅ Repositories ingestion completed")
        return True
    except Exception as e:
        logger.error(f"❌ Repositories ingestion failed: {e}")
        raise
    finally:
        ingestor.close_db()


@task(name="ingest-github-pull-requests", retries=2, retry_delay_seconds=60)
def ingest_pull_requests(repo_names=None, lookback_days=30):
    """
    Ingest GitHub pull requests with reviews and comments

    Args:
        repo_names: List of repository names to sync (None = all repos)
        lookback_days: Number of days to look back for PRs
    """
    logger.info(f"Starting GitHub pull requests ingestion (lookback: {lookback_days} days)...")
    ingestor = GitHubIngestor()
    try:
        ingestor.ingest_pull_requests(repo_names, lookback_days)
        logger.info("✅ Pull requests ingestion completed")
        return True
    except Exception as e:
        logger.error(f"❌ Pull requests ingestion failed: {e}")
        raise
    finally:
        ingestor.close_db()


@task(name="ingest-github-issues", retries=2, retry_delay_seconds=60)
def ingest_issues(repo_names=None, lookback_days=30):
    """
    Ingest GitHub issues with comments

    Args:
        repo_names: List of repository names to sync (None = all repos)
        lookback_days: Number of days to look back for issues
    """
    logger.info(f"Starting GitHub issues ingestion (lookback: {lookback_days} days)...")
    ingestor = GitHubIngestor()
    try:
        ingestor.ingest_issues(repo_names, lookback_days)
        logger.info("✅ Issues ingestion completed")
        return True
    except Exception as e:
        logger.error(f"❌ Issues ingestion failed: {e}")
        raise
    finally:
        ingestor.close_db()


@task(name="ingest-github-commits", retries=2, retry_delay_seconds=60)
def ingest_commits(repo_names=None, lookback_days=30):
    """
    Ingest GitHub commits

    Args:
        repo_names: List of repository names to sync (None = all repos)
        lookback_days: Number of days to look back for commits
    """
    logger.info(f"Starting GitHub commits ingestion (lookback: {lookback_days} days)...")
    ingestor = GitHubIngestor()
    try:
        ingestor.ingest_commits(repo_names, lookback_days)
        logger.info("✅ Commits ingestion completed")
        return True
    except Exception as e:
        logger.error(f"❌ Commits ingestion failed: {e}")
        raise
    finally:
        ingestor.close_db()


@flow(
    name="github-sync-flow",
    description="Full GitHub data sync with configurable lookback",
    task_runner=ConcurrentTaskRunner(),
    log_prints=True,
    flow_run_name="github-sync-{repo_names}-{lookback_days}d"
)
def github_sync_flow(repo_names=None, lookback_days=90):
    """
    Full GitHub data synchronization flow

    This flow syncs all GitHub data with a configurable lookback window.
    Designed to be run periodically (e.g., daily) to ensure complete data.

    Args:
        repo_names: List of repository names to sync (None = all repos)
        lookback_days: Number of days to look back (default: 90)

    Example:
        # Sync all repos with 90-day lookback
        github_sync_flow()

        # Sync specific repos with 30-day lookback
        github_sync_flow(repo_names=['repo1', 'repo2'], lookback_days=30)
    """
    logger.info("=" * 80)
    logger.info(f"GITHUB FULL SYNC - Repos: {repo_names or 'all'}, Lookback: {lookback_days} days")
    logger.info("=" * 80)

    # 1. Validate configuration
    validate_config()

    # 2. Sync organization metadata
    ingest_organization()

    # 3. Sync repositories
    ingest_repositories(repo_names)

    # 4. Sync all data in parallel
    ingest_pull_requests(repo_names, lookback_days)
    ingest_issues(repo_names, lookback_days)
    ingest_commits(repo_names, lookback_days)

    logger.info("=" * 80)
    logger.info("✅ GITHUB FULL SYNC COMPLETED")
    logger.info("=" * 80)


@flow(
    name="github-incremental-flow",
    description="Incremental GitHub data sync for recent changes",
    task_runner=ConcurrentTaskRunner(),
    log_prints=True,
    flow_run_name="github-incremental-{repo_names}"
)
def github_incremental_flow(repo_names=None):
    """
    Incremental GitHub data synchronization flow

    This flow syncs recent GitHub changes (last 7 days).
    Designed to be run frequently (e.g., every 2 hours) for near real-time updates.

    Args:
        repo_names: List of repository names to sync (None = all repos)

    Example:
        # Sync all repos incrementally
        github_incremental_flow()

        # Sync specific repos incrementally
        github_incremental_flow(repo_names=['repo1', 'repo2'])
    """
    logger.info("=" * 80)
    logger.info(f"GITHUB INCREMENTAL SYNC - Repos: {repo_names or 'all'}")
    logger.info("=" * 80)

    # 1. Validate configuration
    validate_config()

    # 2. Sync organization metadata (quick)
    ingest_organization()

    # 3. Sync repositories (quick)
    ingest_repositories(repo_names)

    # 4. Sync recent data (7-day lookback) in parallel
    lookback_days = 7
    ingest_pull_requests(repo_names, lookback_days)
    ingest_issues(repo_names, lookback_days)
    ingest_commits(repo_names, lookback_days)

    logger.info("=" * 80)
    logger.info("✅ GITHUB INCREMENTAL SYNC COMPLETED")
    logger.info("=" * 80)


if __name__ == '__main__':
    # For testing locally
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == 'incremental':
        github_incremental_flow()
    else:
        github_sync_flow(lookback_days=30)
