"""
Prefect flow for Windsurf data ingestion

This flow orchestrates the incremental ingestion of Windsurf analytics data,
with monitoring, error handling, and logging to Grafana via Loki.
"""

import os
import sys
from datetime import timedelta
from pathlib import Path

from prefect import flow, task
from prefect.tasks import task_input_hash
from dotenv import load_dotenv
import logging

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from ingestors.windsurf_ingestor import WindsurfIngestor

# Configure logging to file for Promtail
log_dir = Path(__file__).parent.parent / "logs"
log_dir.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_dir / 'windsurf_flow.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

load_dotenv()


@task(
    name="validate_windsurf_config",
    description="Validate Windsurf API configuration",
    cache_key_fn=task_input_hash,
    cache_expiration=timedelta(hours=1),
    retries=0
)
def validate_config():
    """Validate required environment variables"""
    logger.info("Validating configuration...")

    required_vars = [
        'WINDSURF_SERVICE_KEY',
        'DB_HOST',
        'DB_NAME',
        'DB_USER',
        'DB_PASSWORD'
    ]

    missing = [var for var in required_vars if not os.getenv(var)]

    if missing:
        raise ValueError(f"Missing required environment variables: {', '.join(missing)}")

    logger.info("Configuration validated successfully")
    return True


@task(
    name="ingest_windsurf_users",
    description="Ingest Windsurf user data",
    retries=3,
    retry_delay_seconds=60
)
def ingest_users(emails=None):
    """Ingest user profile and activity data"""
    logger.info("Starting user data ingestion...")

    ingestor = WindsurfIngestor(
        service_key=os.getenv('WINDSURF_SERVICE_KEY'),
        db_host=os.getenv('DB_HOST'),
        db_name=os.getenv('DB_NAME'),
        db_user=os.getenv('DB_USER'),
        db_password=os.getenv('DB_PASSWORD'),
        db_port=int(os.getenv('DB_PORT', 5432))
    )

    try:
        ingestor.connect_db()
        ingestor.ingest_user_data(emails)
        logger.info("User data ingestion completed")
        return {"status": "success", "task": "ingest_users"}
    except Exception as e:
        logger.error(f"User data ingestion failed: {e}", exc_info=True)
        raise
    finally:
        ingestor.close_db()


@task(
    name="ingest_windsurf_cascade",
    description="Ingest Windsurf cascade analytics",
    retries=3,
    retry_delay_seconds=60
)
def ingest_cascade(emails=None, lookback_days=7):
    """Ingest cascade lines, runs, and tool usage"""
    logger.info("Starting cascade data ingestion...")

    ingestor = WindsurfIngestor(
        service_key=os.getenv('WINDSURF_SERVICE_KEY'),
        db_host=os.getenv('DB_HOST'),
        db_name=os.getenv('DB_NAME'),
        db_user=os.getenv('DB_USER'),
        db_password=os.getenv('DB_PASSWORD'),
        db_port=int(os.getenv('DB_PORT', 5432))
    )

    try:
        ingestor.connect_db()
        ingestor.ingest_cascade_data(emails, lookback_days)
        logger.info("Cascade data ingestion completed")
        return {"status": "success", "task": "ingest_cascade"}
    except Exception as e:
        logger.error(f"Cascade data ingestion failed: {e}", exc_info=True)
        raise
    finally:
        ingestor.close_db()


@task(
    name="ingest_windsurf_custom_analytics",
    description="Ingest Windsurf custom analytics",
    retries=3,
    retry_delay_seconds=60
)
def ingest_custom_analytics(data_source: str, emails=None, lookback_days=7):
    """Ingest custom analytics (USER_DATA, CHAT_DATA, COMMAND_DATA, PCW_DATA)"""
    logger.info(f"Starting custom analytics ingestion for {data_source}...")

    ingestor = WindsurfIngestor(
        service_key=os.getenv('WINDSURF_SERVICE_KEY'),
        db_host=os.getenv('DB_HOST'),
        db_name=os.getenv('DB_NAME'),
        db_user=os.getenv('DB_USER'),
        db_password=os.getenv('DB_PASSWORD'),
        db_port=int(os.getenv('DB_PORT', 5432))
    )

    try:
        ingestor.connect_db()
        ingestor.ingest_custom_analytics(data_source, emails, lookback_days)
        logger.info(f"Custom analytics ingestion for {data_source} completed")
        return {"status": "success", "task": f"ingest_{data_source}"}
    except Exception as e:
        logger.error(f"Custom analytics ingestion for {data_source} failed: {e}", exc_info=True)
        raise
    finally:
        ingestor.close_db()


@flow(
    name="windsurf_full_sync",
    description="Complete Windsurf data synchronization",
    log_prints=True
)
def windsurf_sync_flow(emails: list[str] = None, lookback_days: int = 7):
    """
    Full Windsurf data synchronization flow

    Args:
        emails: Optional list of user emails to filter
        lookback_days: Number of days to look back for incremental sync
    """
    logger.info("="*60)
    logger.info("Starting Windsurf Full Sync Flow")
    logger.info("="*60)

    # Validate configuration
    validate_config()

    # Ingest user data first (required for API key mapping)
    user_result = ingest_users(emails)
    logger.info(f"User ingestion: {user_result}")

    # Ingest cascade analytics
    cascade_result = ingest_cascade(emails, lookback_days)
    logger.info(f"Cascade ingestion: {cascade_result}")

    # Ingest custom analytics (can run in parallel if needed)
    custom_results = []
    for data_source in ['USER_DATA', 'CHAT_DATA', 'COMMAND_DATA', 'PCW_DATA']:
        result = ingest_custom_analytics(data_source, emails, lookback_days)
        custom_results.append(result)
        logger.info(f"Custom analytics ingestion for {data_source}: {result}")

    logger.info("="*60)
    logger.info("Windsurf Full Sync Flow Completed Successfully")
    logger.info("="*60)

    return {
        "status": "success",
        "user_result": user_result,
        "cascade_result": cascade_result,
        "custom_results": custom_results
    }


@flow(
    name="windsurf_incremental_sync",
    description="Incremental Windsurf data synchronization (hourly)",
    log_prints=True
)
def windsurf_incremental_flow(emails: list[str] = None):
    """
    Incremental Windsurf sync (for scheduled runs)

    Uses smaller lookback window for frequent updates
    """
    logger.info("Starting Windsurf Incremental Sync")
    return windsurf_sync_flow(emails=emails, lookback_days=1)


if __name__ == '__main__':
    # Run the flow
    windsurf_sync_flow()
