"""
Freshdesk Data Ingestion Prefect Flow

This module defines Prefect flows for Freshdesk data ingestion:
- freshdesk_sync_flow: Full sync with configurable lookback
- freshdesk_incremental_flow: Incremental sync for recent changes
"""

from prefect import flow, task
from prefect.task_runners import ConcurrentTaskRunner
from datetime import timedelta
import logging
import os
import sys

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ingestors.freshdesk_ingestor import FreshdeskIngestor

# Configure logging to write to file for Loki ingestion
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/freshdesk_flow.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


@task(name="validate-freshdesk-config", retries=0, retry_delay_seconds=10)
def validate_config():
    """Validate Freshdesk configuration"""
    required_vars = ['FRESHDESK_DOMAIN', 'FRESHDESK_API_KEY']
    missing = [var for var in required_vars if not os.getenv(var)]

    if missing:
        raise ValueError(f"Missing required environment variables: {', '.join(missing)}")

    logger.info("✅ Freshdesk configuration validated")
    return True


@task(name="ingest-freshdesk-agents", retries=2, retry_delay_seconds=60)
def ingest_agents():
    """Ingest Freshdesk agents (support staff)"""
    logger.info("Starting Freshdesk agents ingestion...")
    ingestor = FreshdeskIngestor()
    try:
        ingestor.ingest_agents()
        logger.info("✅ Agents ingestion completed")
        return True
    except Exception as e:
        logger.error(f"❌ Agents ingestion failed: {e}")
        raise
    finally:
        ingestor.close_db()


@task(name="ingest-freshdesk-groups", retries=2, retry_delay_seconds=60)
def ingest_groups():
    """Ingest Freshdesk groups (support teams)"""
    logger.info("Starting Freshdesk groups ingestion...")
    ingestor = FreshdeskIngestor()
    try:
        ingestor.ingest_groups()
        logger.info("✅ Groups ingestion completed")
        return True
    except Exception as e:
        logger.error(f"❌ Groups ingestion failed: {e}")
        raise
    finally:
        ingestor.close_db()


@task(name="ingest-freshdesk-companies", retries=2, retry_delay_seconds=60)
def ingest_companies():
    """Ingest Freshdesk companies (customer organizations)"""
    logger.info("Starting Freshdesk companies ingestion...")
    ingestor = FreshdeskIngestor()
    try:
        ingestor.ingest_companies()
        logger.info("✅ Companies ingestion completed")
        return True
    except Exception as e:
        logger.error(f"❌ Companies ingestion failed: {e}")
        raise
    finally:
        ingestor.close_db()


@task(name="ingest-freshdesk-contacts", retries=2, retry_delay_seconds=60)
def ingest_contacts(lookback_days=30):
    """
    Ingest Freshdesk contacts (customers)

    Args:
        lookback_days: Number of days to look back for contacts
    """
    logger.info(f"Starting Freshdesk contacts ingestion (lookback: {lookback_days} days)...")
    ingestor = FreshdeskIngestor()
    try:
        ingestor.ingest_contacts(lookback_days)
        logger.info("✅ Contacts ingestion completed")
        return True
    except Exception as e:
        logger.error(f"❌ Contacts ingestion failed: {e}")
        raise
    finally:
        ingestor.close_db()


@task(name="ingest-freshdesk-tickets", retries=2, retry_delay_seconds=60)
def ingest_tickets(lookback_days=30):
    """
    Ingest Freshdesk tickets with custom fields

    Args:
        lookback_days: Number of days to look back for tickets
    """
    logger.info(f"Starting Freshdesk tickets ingestion (lookback: {lookback_days} days)...")
    ingestor = FreshdeskIngestor()
    try:
        ingestor.ingest_tickets(lookback_days)
        logger.info("✅ Tickets ingestion completed")
        return True
    except Exception as e:
        logger.error(f"❌ Tickets ingestion failed: {e}")
        raise
    finally:
        ingestor.close_db()


@task(name="ingest-freshdesk-conversations", retries=2, retry_delay_seconds=60)
def ingest_conversations():
    """Ingest Freshdesk conversations (ticket replies)"""
    logger.info("Starting Freshdesk conversations ingestion...")
    ingestor = FreshdeskIngestor()
    try:
        ingestor.ingest_conversations()
        logger.info("✅ Conversations ingestion completed")
        return True
    except Exception as e:
        logger.error(f"❌ Conversations ingestion failed: {e}")
        raise
    finally:
        ingestor.close_db()


@task(name="ingest-freshdesk-time-entries", retries=2, retry_delay_seconds=60)
def ingest_time_entries(lookback_days=30):
    """
    Ingest Freshdesk time entries (work logs)

    Args:
        lookback_days: Number of days to look back for time entries
    """
    logger.info(f"Starting Freshdesk time entries ingestion (lookback: {lookback_days} days)...")
    ingestor = FreshdeskIngestor()
    try:
        ingestor.ingest_time_entries(lookback_days)
        logger.info("✅ Time entries ingestion completed")
        return True
    except Exception as e:
        logger.error(f"❌ Time entries ingestion failed: {e}")
        raise
    finally:
        ingestor.close_db()


@flow(
    name="freshdesk-sync-flow",
    description="Full Freshdesk data sync with configurable lookback",
    task_runner=ConcurrentTaskRunner(),
    log_prints=True,
    flow_run_name="freshdesk-sync-{lookback_days}d"
)
def freshdesk_sync_flow(lookback_days=90):
    """
    Full Freshdesk data synchronization flow

    This flow syncs all Freshdesk data with a configurable lookback window.
    Designed to be run periodically (e.g., daily) to ensure complete data.

    Args:
        lookback_days: Number of days to look back (default: 90)

    Example:
        # Full sync with 90-day lookback
        freshdesk_sync_flow()

        # Full sync with 30-day lookback
        freshdesk_sync_flow(lookback_days=30)
    """
    logger.info("=" * 80)
    logger.info(f"FRESHDESK FULL SYNC - Lookback: {lookback_days} days")
    logger.info("=" * 80)

    # 1. Validate configuration
    validate_config()

    # 2. Sync metadata (agents, groups, companies) - full sync
    ingest_agents()
    ingest_groups()
    ingest_companies()

    # 3. Sync contacts (incremental)
    ingest_contacts(lookback_days)

    # 4. Sync tickets with custom fields (incremental)
    ingest_tickets(lookback_days)

    # 5. Sync conversations and time entries (incremental)
    ingest_conversations()
    ingest_time_entries(lookback_days)

    logger.info("=" * 80)
    logger.info("✅ FRESHDESK FULL SYNC COMPLETED")
    logger.info("=" * 80)


@flow(
    name="freshdesk-incremental-flow",
    description="Incremental Freshdesk data sync for recent changes",
    task_runner=ConcurrentTaskRunner(),
    log_prints=True,
    flow_run_name="freshdesk-incremental"
)
def freshdesk_incremental_flow():
    """
    Incremental Freshdesk data synchronization flow

    This flow syncs recent Freshdesk changes (last 7 days).
    Designed to be run frequently (e.g., every 2 hours) for near real-time updates.

    Example:
        # Incremental sync
        freshdesk_incremental_flow()
    """
    logger.info("=" * 80)
    logger.info("FRESHDESK INCREMENTAL SYNC")
    logger.info("=" * 80)

    # 1. Validate configuration
    validate_config()

    # 2. Sync metadata (quick)
    ingest_agents()
    ingest_groups()
    ingest_companies()

    # 3. Sync recent data (7-day lookback)
    lookback_days = 7
    ingest_contacts(lookback_days)
    ingest_tickets(lookback_days)
    ingest_conversations()
    ingest_time_entries(lookback_days)

    logger.info("=" * 80)
    logger.info("✅ FRESHDESK INCREMENTAL SYNC COMPLETED")
    logger.info("=" * 80)


if __name__ == '__main__':
    # For testing locally
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == 'incremental':
        freshdesk_incremental_flow()
    else:
        freshdesk_sync_flow(lookback_days=30)
