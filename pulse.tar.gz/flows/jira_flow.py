"""
Prefect flow for JIRA data ingestion

This flow orchestrates the incremental ingestion of JIRA data,
with monitoring, error handling, and logging to Grafana via Loki.
"""

import os
import sys
from datetime import timedelta
from pathlib import Path

from prefect import flow, task
from prefect.tasks import task_input_hash
from dotenv import load_dotenv
import logging

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from ingestors.jira_ingestor import JiraIngestor

# Configure logging to file for Promtail
log_dir = Path(__file__).parent.parent / "logs"
log_dir.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_dir / 'jira_flow.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

load_dotenv()


@task(
    name="validate_jira_config",
    description="Validate JIRA API configuration",
    cache_key_fn=task_input_hash,
    cache_expiration=timedelta(hours=1),
    retries=0
)
def validate_config():
    """Validate required environment variables"""
    logger.info("Validating configuration...")

    required_vars = [
        'JIRA_URL',
        'JIRA_EMAIL',
        'JIRA_API_TOKEN',
        'DB_HOST',
        'DB_NAME',
        'DB_USER',
        'DB_PASSWORD'
    ]

    missing = [var for var in required_vars if not os.getenv(var)]

    if missing:
        raise ValueError(f"Missing required environment variables: {', '.join(missing)}")

    logger.info("Configuration validated successfully")
    return True


@task(
    name="ingest_jira_projects",
    description="Ingest JIRA projects",
    retries=3,
    retry_delay_seconds=60
)
def ingest_projects():
    """Ingest JIRA projects"""
    logger.info("Starting projects ingestion...")

    ingestor = JiraIngestor(
        jira_url=os.getenv('JIRA_URL'),
        jira_email=os.getenv('JIRA_EMAIL'),
        jira_api_token=os.getenv('JIRA_API_TOKEN'),
        db_host=os.getenv('DB_HOST'),
        db_name=os.getenv('DB_NAME'),
        db_user=os.getenv('DB_USER'),
        db_password=os.getenv('DB_PASSWORD'),
        db_port=int(os.getenv('DB_PORT', 5432))
    )

    try:
        ingestor.connect_db()
        ingestor.ingest_projects()
        logger.info("Projects ingestion completed")
        return {"status": "success", "task": "ingest_projects"}
    except Exception as e:
        logger.error(f"Projects ingestion failed: {e}", exc_info=True)
        raise
    finally:
        ingestor.close_db()


@task(
    name="ingest_jira_issues",
    description="Ingest JIRA issues with all related data",
    retries=3,
    retry_delay_seconds=120
)
def ingest_issues(project_keys=None, lookback_days=30):
    """Ingest JIRA issues, comments, worklogs, changelog"""
    logger.info("Starting issues ingestion...")

    ingestor = JiraIngestor(
        jira_url=os.getenv('JIRA_URL'),
        jira_email=os.getenv('JIRA_EMAIL'),
        jira_api_token=os.getenv('JIRA_API_TOKEN'),
        db_host=os.getenv('DB_HOST'),
        db_name=os.getenv('DB_NAME'),
        db_user=os.getenv('DB_USER'),
        db_password=os.getenv('DB_PASSWORD'),
        db_port=int(os.getenv('DB_PORT', 5432))
    )

    try:
        ingestor.connect_db()
        ingestor.ingest_issues(project_keys, lookback_days)
        logger.info("Issues ingestion completed")
        return {"status": "success", "task": "ingest_issues"}
    except Exception as e:
        logger.error(f"Issues ingestion failed: {e}", exc_info=True)
        raise
    finally:
        ingestor.close_db()


@task(
    name="ingest_jira_boards_sprints",
    description="Ingest JIRA boards and sprints",
    retries=3,
    retry_delay_seconds=60
)
def ingest_boards_sprints(project_keys=None):
    """Ingest JIRA boards and sprints"""
    logger.info("Starting boards and sprints ingestion...")

    ingestor = JiraIngestor(
        jira_url=os.getenv('JIRA_URL'),
        jira_email=os.getenv('JIRA_EMAIL'),
        jira_api_token=os.getenv('JIRA_API_TOKEN'),
        db_host=os.getenv('DB_HOST'),
        db_name=os.getenv('DB_NAME'),
        db_user=os.getenv('DB_USER'),
        db_password=os.getenv('DB_PASSWORD'),
        db_port=int(os.getenv('DB_PORT', 5432))
    )

    try:
        ingestor.connect_db()
        ingestor.ingest_boards_and_sprints(project_keys)
        logger.info("Boards and sprints ingestion completed")
        return {"status": "success", "task": "ingest_boards_sprints"}
    except Exception as e:
        logger.error(f"Boards and sprints ingestion failed: {e}", exc_info=True)
        raise
    finally:
        ingestor.close_db()


@flow(
    name="jira_full_sync",
    description="Complete JIRA data synchronization",
    log_prints=True
)
def jira_sync_flow(project_keys: list[str] = None, lookback_days: int = 30):
    """
    Full JIRA data synchronization flow

    Args:
        project_keys: Optional list of project keys to filter
        lookback_days: Number of days to look back for incremental sync
    """
    logger.info("="*60)
    logger.info("Starting JIRA Full Sync Flow")
    logger.info("="*60)

    # Validate configuration
    validate_config()

    # Ingest projects first
    projects_result = ingest_projects()
    logger.info(f"Projects ingestion: {projects_result}")

    # Ingest issues (includes comments, worklogs, changelog, attachments, links)
    issues_result = ingest_issues(project_keys, lookback_days)
    logger.info(f"Issues ingestion: {issues_result}")

    # Ingest boards and sprints
    boards_result = ingest_boards_sprints(project_keys)
    logger.info(f"Boards ingestion: {boards_result}")

    logger.info("="*60)
    logger.info("JIRA Full Sync Flow Completed Successfully")
    logger.info("="*60)

    return {
        "status": "success",
        "projects_result": projects_result,
        "issues_result": issues_result,
        "boards_result": boards_result
    }


@flow(
    name="jira_incremental_sync",
    description="Incremental JIRA data synchronization (hourly)",
    log_prints=True
)
def jira_incremental_flow(project_keys: list[str] = None):
    """
    Incremental JIRA sync (for scheduled runs)

    Uses smaller lookback window for frequent updates
    """
    logger.info("Starting JIRA Incremental Sync")
    return jira_sync_flow(project_keys=project_keys, lookback_days=7)


if __name__ == '__main__':
    # Run the flow
    jira_sync_flow()
