"""
Pulse Setup Script

This script initializes the Pulse application:
1. Checks Docker services
2. Creates database schemas
3. Pulls Ollama embedding model
4. Trains Vanna on schemas
5. Creates Qdrant collections
6. Runs health checks

Usage:
    python setup_pulse.py
"""

import os
import sys
import logging
import psycopg2
import subprocess
from qdrant_client import QdrantClient
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def check_env_vars():
    """Check required environment variables"""
    logger.info("Checking environment variables...")

    required_vars = [
        'DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASSWORD',
        'ANTHROPIC_API_KEY',
        'WINDSURF_SERVICE_KEY',
        'JIRA_URL', 'JIRA_EMAIL', 'JIRA_API_TOKEN',
        'GITHUB_TOKEN', 'GITHUB_ORG',
        'FRESHDESK_DOMAIN', 'FRESHDESK_API_KEY'
    ]

    missing = []
    for var in required_vars:
        if not os.getenv(var):
            missing.append(var)

    if missing:
        logger.warning(f"Missing environment variables: {', '.join(missing)}")
        logger.warning("Some features may not work. Please set these in your .env file.")
    else:
        logger.info("✅ All environment variables set")


def check_docker_services():
    """Check if Docker services are running"""
    logger.info("Checking Docker services...")

    services = [
        'pulse_postgres',
        'pulse_qdrant',
        'pulse_ollama',
        'pulse_redis',
        'pulse_prefect',
        'pulse_loki',
        'pulse_promtail',
        'pulse_grafana'
    ]

    try:
        result = subprocess.run(
            ['docker', 'ps', '--format', '{{.Names}}'],
            capture_output=True,
            text=True,
            check=True
        )

        running_services = result.stdout.strip().split('\n')

        for service in services:
            if service in running_services:
                logger.info(f"✅ {service} is running")
            else:
                logger.warning(f"⚠️  {service} is not running")

    except Exception as e:
        logger.error(f"Failed to check Docker services: {e}")
        logger.info("Make sure Docker is running and services are started with: make start")
        sys.exit(1)


def create_database_schemas():
    """Create database schemas from SQL files"""
    logger.info("Creating database schemas...")

    schema_files = [
        'schema/windsurf_schema.sql',
        'schema/jira_schema.sql',
        'schema/github_schema.sql',
        'schema/freshdesk_schema.sql'
    ]

    try:
        # Connect to database
        conn = psycopg2.connect(
            host=os.getenv('DB_HOST', 'localhost'),
            port=os.getenv('DB_PORT', '5432'),
            database=os.getenv('DB_NAME', 'pulse'),
            user=os.getenv('DB_USER', 'pulse_user'),
            password=os.getenv('DB_PASSWORD', 'pulse_password')
        )
        conn.autocommit = True
        cursor = conn.cursor()

        for schema_file in schema_files:
            if not os.path.exists(schema_file):
                logger.warning(f"Schema file not found: {schema_file}")
                continue

            logger.info(f"Executing {schema_file}...")
            with open(schema_file, 'r') as f:
                sql = f.read()

            cursor.execute(sql)
            logger.info(f"✅ {schema_file} executed successfully")

        cursor.close()
        conn.close()

        logger.info("✅ All schemas created")

    except Exception as e:
        logger.error(f"Failed to create schemas: {e}")
        sys.exit(1)


def pull_ollama_model():
    """Pull Ollama embedding model"""
    logger.info("Pulling Ollama embedding model...")

    model = os.getenv('EMBEDDING_MODEL', 'nomic-embed-text')

    try:
        result = subprocess.run(
            ['docker', 'exec', 'pulse_ollama', 'ollama', 'pull', model],
            capture_output=True,
            text=True,
            timeout=300  # 5 minutes
        )

        if result.returncode == 0:
            logger.info(f"✅ Ollama model '{model}' pulled successfully")
        else:
            logger.error(f"Failed to pull Ollama model: {result.stderr}")

    except subprocess.TimeoutExpired:
        logger.warning("Ollama model pull timed out. It may still be downloading in the background.")
    except Exception as e:
        logger.error(f"Failed to pull Ollama model: {e}")


def setup_vanna():
    """Initialize and train Vanna on schemas"""
    logger.info("Setting up Vanna...")

    try:
        from query_engine.vanna_config import VannaSQL, train_from_schema_files, train_common_questions

        # Initialize Vanna
        vanna = VannaSQL()

        # Train on schemas
        train_from_schema_files(vanna, schema_dir='./schema')

        # Train on common questions
        train_common_questions(vanna)

        logger.info("✅ Vanna setup complete")

    except Exception as e:
        logger.error(f"Failed to setup Vanna: {e}")
        logger.warning("Vanna setup failed. You can retry later with: python query_engine/vanna_config.py")


def setup_qdrant():
    """Create Qdrant collections"""
    logger.info("Setting up Qdrant collections...")

    try:
        from query_engine.qdrant_config import QdrantSearch

        # Initialize Qdrant
        qdrant = QdrantSearch()

        # Create collections
        qdrant.create_all_collections()

        logger.info("✅ Qdrant collections created")
        logger.info("Note: You'll need to index data later with:")
        logger.info("  python query_engine/qdrant_config.py")

    except Exception as e:
        logger.error(f"Failed to setup Qdrant: {e}")
        logger.warning("Qdrant setup failed. You can retry later.")


def run_health_checks():
    """Run health checks on all services"""
    logger.info("Running health checks...")

    checks = {
        'PostgreSQL': check_postgres,
        'Qdrant': check_qdrant,
        'Ollama': check_ollama,
        'Redis': check_redis,
        'Prefect': check_prefect
    }

    results = {}
    for name, check_func in checks.items():
        try:
            check_func()
            results[name] = True
            logger.info(f"✅ {name} health check passed")
        except Exception as e:
            results[name] = False
            logger.error(f"❌ {name} health check failed: {e}")

    # Summary
    logger.info("\n" + "=" * 80)
    logger.info("HEALTH CHECK SUMMARY")
    logger.info("=" * 80)

    for service, healthy in results.items():
        status = "✅ HEALTHY" if healthy else "❌ UNHEALTHY"
        logger.info(f"{service}: {status}")


def check_postgres():
    """Check PostgreSQL connection"""
    conn = psycopg2.connect(
        host=os.getenv('DB_HOST', 'localhost'),
        port=os.getenv('DB_PORT', '5432'),
        database=os.getenv('DB_NAME', 'pulse'),
        user=os.getenv('DB_USER', 'pulse_user'),
        password=os.getenv('DB_PASSWORD', 'pulse_password')
    )
    conn.close()


def check_qdrant():
    """Check Qdrant connection"""
    client = QdrantClient(
        host=os.getenv('QDRANT_HOST', 'localhost'),
        port=int(os.getenv('QDRANT_PORT', '6333'))
    )
    client.get_collections()


def check_ollama():
    """Check Ollama connection"""
    import ollama
    client = ollama.Client(host=os.getenv('OLLAMA_HOST', 'http://localhost:11434'))
    # Try to list models
    client.list()


def check_redis():
    """Check Redis connection"""
    import redis
    r = redis.Redis(
        host=os.getenv('REDIS_HOST', 'localhost'),
        port=int(os.getenv('REDIS_PORT', '6379'))
    )
    r.ping()


def check_prefect():
    """Check Prefect connection"""
    import requests
    api_url = os.getenv('PREFECT_API_URL', 'http://localhost:4200/api')
    response = requests.get(f"{api_url}/health")
    response.raise_for_status()


def main():
    """Main setup function"""
    logger.info("=" * 80)
    logger.info("PULSE SETUP")
    logger.info("=" * 80)

    # 1. Check environment variables
    check_env_vars()
    time.sleep(1)

    # 2. Check Docker services
    check_docker_services()
    time.sleep(1)

    # 3. Create database schemas
    create_database_schemas()
    time.sleep(1)

    # 4. Pull Ollama model
    pull_ollama_model()
    time.sleep(1)

    # 5. Setup Vanna
    setup_vanna()
    time.sleep(1)

    # 6. Setup Qdrant
    setup_qdrant()
    time.sleep(1)

    # 7. Run health checks
    run_health_checks()

    logger.info("\n" + "=" * 80)
    logger.info("✅ PULSE SETUP COMPLETE!")
    logger.info("=" * 80)
    logger.info("\nNext steps:")
    logger.info("1. Start data ingestion: make run-sync")
    logger.info("2. Deploy Prefect flows: make deploy-flows")
    logger.info("3. Start the chat UI: chainlit run app.py -w")
    logger.info("4. Access Grafana: http://localhost:3000")
    logger.info("5. Access Prefect UI: http://localhost:4200")


if __name__ == '__main__':
    main()
