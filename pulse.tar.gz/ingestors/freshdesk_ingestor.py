"""
Freshdesk Data Ingestor

This module handles incremental ingestion of Freshdesk support data into PostgreSQL.
Supports the following entities:
- Agents (support team members)
- Groups (support teams)
- Companies (customer organizations)
- Contacts (customers)
- Tickets (support requests)
- Conversations (ticket replies)
- Time Entries (work logs)
- Custom Fields (flexible field values)
- Satisfaction Ratings (CSAT)

Usage:
    ingestor = FreshdeskIngestor(
        domain='yourcompany.freshdesk.com',
        api_key='your_api_key'
    )
    ingestor.ingest_all(lookback_days=30)
"""

import os
import logging
import requests
from datetime import datetime, timedelta, timezone
from typing import Optional, List, Dict, Any
import psycopg2
from psycopg2.extras import execute_values
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class FreshdeskIngestor:
    """Handles incremental ingestion of Freshdesk support data"""

    def __init__(self, domain: str = None, api_key: str = None):
        """
        Initialize Freshdesk ingestor

        Args:
            domain: Freshdesk domain (e.g., 'yourcompany.freshdesk.com')
            api_key: Freshdesk API key
        """
        self.domain = domain or os.getenv('FRESHDESK_DOMAIN')
        self.api_key = api_key or os.getenv('FRESHDESK_API_KEY')

        if not self.domain or not self.api_key:
            raise ValueError("FRESHDESK_DOMAIN and FRESHDESK_API_KEY must be set")

        self.base_url = f"https://{self.domain}/api/v2"
        self.session = requests.Session()
        self.session.auth = (self.api_key, 'X')
        self.session.headers.update({'Content-Type': 'application/json'})

        self.conn = None
        self.connect_db()

    def connect_db(self):
        """Connect to PostgreSQL database"""
        try:
            self.conn = psycopg2.connect(
                host=os.getenv('DB_HOST', 'localhost'),
                port=os.getenv('DB_PORT', '5432'),
                database=os.getenv('DB_NAME', 'pulse'),
                user=os.getenv('DB_USER', 'pulse_user'),
                password=os.getenv('DB_PASSWORD', 'pulse_password')
            )
            logger.info("Connected to PostgreSQL")
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            raise

    def close_db(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()
            logger.info("Database connection closed")

    def _make_request(self, endpoint: str, params: Dict = None) -> List[Dict]:
        """
        Make paginated request to Freshdesk API

        Args:
            endpoint: API endpoint (e.g., '/agents')
            params: Query parameters

        Returns:
            List of records from all pages
        """
        all_records = []
        page = 1

        while True:
            url = f"{self.base_url}{endpoint}"
            request_params = params.copy() if params else {}
            request_params['page'] = page
            request_params['per_page'] = 100

            try:
                response = self.session.get(url, params=request_params)

                # Handle rate limiting
                if response.status_code == 429:
                    retry_after = int(response.headers.get('Retry-After', 60))
                    logger.warning(f"Rate limited. Waiting {retry_after} seconds...")
                    time.sleep(retry_after)
                    continue

                response.raise_for_status()
                records = response.json()

                if not records:
                    break

                all_records.extend(records)
                logger.info(f"Fetched page {page} from {endpoint} ({len(records)} records)")
                page += 1

                # Rate limiting - 100 requests per minute
                time.sleep(0.6)

            except requests.exceptions.RequestException as e:
                logger.error(f"API request failed: {e}")
                break

        return all_records

    def get_last_sync_timestamp(self, api_endpoint: str) -> Optional[datetime]:
        """Get the last successful sync timestamp for an API endpoint"""
        with self.conn.cursor() as cursor:
            cursor.execute(
                """
                SELECT last_sync_timestamp FROM freshdesk_sync_metadata
                WHERE api_endpoint = %s AND last_sync_status = 'success'
                """,
                (api_endpoint,)
            )
            result = cursor.fetchone()
            return result[0] if result else None

    def update_sync_metadata(self, api_endpoint: str, timestamp: datetime,
                           records_synced: int = 0, status: str = 'success',
                           error_message: str = None):
        """Update sync metadata after ingestion"""
        with self.conn.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO freshdesk_sync_metadata
                (api_endpoint, last_sync_timestamp, last_sync_status, records_synced, error_message, updated_at)
                VALUES (%s, %s, %s, %s, %s, NOW())
                ON CONFLICT (api_endpoint)
                DO UPDATE SET
                    last_sync_timestamp = EXCLUDED.last_sync_timestamp,
                    last_sync_status = EXCLUDED.last_sync_status,
                    records_synced = EXCLUDED.records_synced,
                    error_message = EXCLUDED.error_message,
                    updated_at = NOW()
                """,
                (api_endpoint, timestamp, status, records_synced, error_message)
            )
        self.conn.commit()
        logger.info(f"Updated sync metadata for {api_endpoint}")

    def _parse_freshdesk_datetime(self, dt_str: str) -> Optional[datetime]:
        """Parse Freshdesk datetime string to datetime object"""
        if not dt_str:
            return None
        try:
            # Freshdesk uses ISO 8601 format
            return datetime.fromisoformat(dt_str.replace('Z', '+00:00'))
        except:
            return None

    # ========== AGENTS ==========

    def ingest_agents(self):
        """Ingest Freshdesk agents (support staff)"""
        logger.info("Starting agents ingestion...")

        try:
            agents = self._make_request('/agents')

            if not agents:
                logger.info("No agents found")
                return

            # Prepare data for bulk upsert
            agent_data = []
            for agent in agents:
                agent_data.append((
                    agent.get('id'),
                    agent.get('email'),
                    agent.get('name'),
                    agent.get('contact', {}).get('phone'),
                    agent.get('contact', {}).get('mobile'),
                    agent.get('available'),
                    agent.get('occasional'),
                    agent.get('signature'),
                    agent.get('ticket_scope'),  # 1=global, 2=group, 3=restricted
                    ','.join(map(str, agent.get('group_ids', []))),
                    ','.join(map(str, agent.get('role_ids', []))),
                    self._parse_freshdesk_datetime(agent.get('created_at')),
                    self._parse_freshdesk_datetime(agent.get('updated_at'))
                ))

            # Bulk upsert
            with self.conn.cursor() as cursor:
                execute_values(
                    cursor,
                    """
                    INSERT INTO freshdesk_agents
                    (agent_id, email, name, phone, mobile, available, occasional,
                     signature, ticket_scope, group_ids, role_ids, created_at, updated_at, synced_at)
                    VALUES %s
                    ON CONFLICT (agent_id) DO UPDATE SET
                        email = EXCLUDED.email,
                        name = EXCLUDED.name,
                        phone = EXCLUDED.phone,
                        mobile = EXCLUDED.mobile,
                        available = EXCLUDED.available,
                        occasional = EXCLUDED.occasional,
                        signature = EXCLUDED.signature,
                        ticket_scope = EXCLUDED.ticket_scope,
                        group_ids = EXCLUDED.group_ids,
                        role_ids = EXCLUDED.role_ids,
                        updated_at = EXCLUDED.updated_at,
                        synced_at = NOW()
                    """,
                    agent_data
                )

            self.conn.commit()
            logger.info(f"✅ Synced {len(agents)} agents")

            # Update sync metadata
            self.update_sync_metadata('/agents', datetime.now(timezone.utc), len(agents))

        except Exception as e:
            logger.error(f"Failed to ingest agents: {e}")
            self.update_sync_metadata('/agents', datetime.now(timezone.utc),
                                    status='error', error_message=str(e))
            raise

    # ========== GROUPS ==========

    def ingest_groups(self):
        """Ingest Freshdesk groups (support teams)"""
        logger.info("Starting groups ingestion...")

        try:
            groups = self._make_request('/groups')

            if not groups:
                logger.info("No groups found")
                return

            group_data = []
            for group in groups:
                group_data.append((
                    group.get('id'),
                    group.get('name'),
                    group.get('description'),
                    group.get('escalate_to'),
                    group.get('unassigned_for'),
                    group.get('business_calendar_id'),
                    ','.join(map(str, group.get('agent_ids', []))),
                    self._parse_freshdesk_datetime(group.get('created_at')),
                    self._parse_freshdesk_datetime(group.get('updated_at'))
                ))

            with self.conn.cursor() as cursor:
                execute_values(
                    cursor,
                    """
                    INSERT INTO freshdesk_groups
                    (group_id, name, description, escalate_to, unassigned_for,
                     business_calendar_id, agent_ids, created_at, updated_at, synced_at)
                    VALUES %s
                    ON CONFLICT (group_id) DO UPDATE SET
                        name = EXCLUDED.name,
                        description = EXCLUDED.description,
                        escalate_to = EXCLUDED.escalate_to,
                        unassigned_for = EXCLUDED.unassigned_for,
                        business_calendar_id = EXCLUDED.business_calendar_id,
                        agent_ids = EXCLUDED.agent_ids,
                        updated_at = EXCLUDED.updated_at,
                        synced_at = NOW()
                    """,
                    group_data
                )

            self.conn.commit()
            logger.info(f"✅ Synced {len(groups)} groups")
            self.update_sync_metadata('/groups', datetime.now(timezone.utc), len(groups))

        except Exception as e:
            logger.error(f"Failed to ingest groups: {e}")
            self.update_sync_metadata('/groups', datetime.now(timezone.utc),
                                    status='error', error_message=str(e))
            raise

    # ========== COMPANIES ==========

    def ingest_companies(self):
        """Ingest Freshdesk companies (customer organizations)"""
        logger.info("Starting companies ingestion...")

        try:
            companies = self._make_request('/companies')

            if not companies:
                logger.info("No companies found")
                return

            company_data = []
            for company in companies:
                company_data.append((
                    company.get('id'),
                    company.get('name'),
                    company.get('description'),
                    company.get('note'),
                    company.get('domains', []),  # Array
                    self._parse_freshdesk_datetime(company.get('created_at')),
                    self._parse_freshdesk_datetime(company.get('updated_at'))
                ))

            with self.conn.cursor() as cursor:
                execute_values(
                    cursor,
                    """
                    INSERT INTO freshdesk_companies
                    (company_id, name, description, note, domains, created_at, updated_at, synced_at)
                    VALUES %s
                    ON CONFLICT (company_id) DO UPDATE SET
                        name = EXCLUDED.name,
                        description = EXCLUDED.description,
                        note = EXCLUDED.note,
                        domains = EXCLUDED.domains,
                        updated_at = EXCLUDED.updated_at,
                        synced_at = NOW()
                    """,
                    company_data
                )

            self.conn.commit()
            logger.info(f"✅ Synced {len(companies)} companies")
            self.update_sync_metadata('/companies', datetime.now(timezone.utc), len(companies))

        except Exception as e:
            logger.error(f"Failed to ingest companies: {e}")
            self.update_sync_metadata('/companies', datetime.now(timezone.utc),
                                    status='error', error_message=str(e))
            raise

    # ========== CONTACTS ==========

    def ingest_contacts(self, lookback_days: int = 30):
        """Ingest Freshdesk contacts (customers)"""
        logger.info(f"Starting contacts ingestion (lookback: {lookback_days} days)...")

        try:
            last_sync = self.get_last_sync_timestamp('/contacts')
            start_time = last_sync if last_sync else datetime.now(timezone.utc) - timedelta(days=lookback_days)

            # Freshdesk filter: updated_at > timestamp
            params = {
                'updated_since': start_time.strftime('%Y-%m-%dT%H:%M:%SZ')
            }

            contacts = self._make_request('/contacts', params)

            if not contacts:
                logger.info("No contacts found")
                return

            contact_data = []
            for contact in contacts:
                contact_data.append((
                    contact.get('id'),
                    contact.get('email'),
                    contact.get('name'),
                    contact.get('phone'),
                    contact.get('mobile'),
                    contact.get('company_id'),
                    contact.get('job_title'),
                    contact.get('language'),
                    contact.get('time_zone'),
                    contact.get('active'),
                    contact.get('deleted'),
                    contact.get('address'),
                    contact.get('description'),
                    contact.get('tags', []),  # Array
                    self._parse_freshdesk_datetime(contact.get('created_at')),
                    self._parse_freshdesk_datetime(contact.get('updated_at'))
                ))

            with self.conn.cursor() as cursor:
                execute_values(
                    cursor,
                    """
                    INSERT INTO freshdesk_contacts
                    (contact_id, email, name, phone, mobile, company_id, job_title,
                     language, time_zone, active, deleted, address, description, tags,
                     created_at, updated_at, synced_at)
                    VALUES %s
                    ON CONFLICT (contact_id) DO UPDATE SET
                        email = EXCLUDED.email,
                        name = EXCLUDED.name,
                        phone = EXCLUDED.phone,
                        mobile = EXCLUDED.mobile,
                        company_id = EXCLUDED.company_id,
                        job_title = EXCLUDED.job_title,
                        language = EXCLUDED.language,
                        time_zone = EXCLUDED.time_zone,
                        active = EXCLUDED.active,
                        deleted = EXCLUDED.deleted,
                        address = EXCLUDED.address,
                        description = EXCLUDED.description,
                        tags = EXCLUDED.tags,
                        updated_at = EXCLUDED.updated_at,
                        synced_at = NOW()
                    """,
                    contact_data
                )

            self.conn.commit()
            logger.info(f"✅ Synced {len(contacts)} contacts")
            self.update_sync_metadata('/contacts', datetime.now(timezone.utc), len(contacts))

        except Exception as e:
            logger.error(f"Failed to ingest contacts: {e}")
            self.update_sync_metadata('/contacts', datetime.now(timezone.utc),
                                    status='error', error_message=str(e))
            raise

    # ========== TICKETS ==========

    def ingest_tickets(self, lookback_days: int = 30):
        """Ingest Freshdesk tickets (support requests)"""
        logger.info(f"Starting tickets ingestion (lookback: {lookback_days} days)...")

        try:
            last_sync = self.get_last_sync_timestamp('/tickets')
            start_time = last_sync if last_sync else datetime.now(timezone.utc) - timedelta(days=lookback_days)

            params = {
                'updated_since': start_time.strftime('%Y-%m-%dT%H:%M:%SZ'),
                'include': 'stats'  # Include ticket stats
            }

            tickets = self._make_request('/tickets', params)

            if not tickets:
                logger.info("No tickets found")
                return

            ticket_data = []
            for ticket in tickets:
                stats = ticket.get('stats', {})

                ticket_data.append((
                    ticket.get('id'),
                    ticket.get('subject'),
                    ticket.get('description_text'),
                    ticket.get('status'),  # 2=Open, 3=Pending, 4=Resolved, 5=Closed
                    ticket.get('priority'),  # 1=Low, 2=Medium, 3=High, 4=Urgent
                    ticket.get('source'),  # 1=Email, 2=Portal, 3=Phone, 7=Chat
                    ticket.get('type'),
                    ticket.get('requester_id'),
                    ticket.get('responder_id'),
                    ticket.get('company_id'),
                    ticket.get('group_id'),
                    ticket.get('product_id'),
                    ticket.get('is_escalated'),
                    ticket.get('spam'),
                    ticket.get('deleted'),
                    ticket.get('tags', []),
                    ticket.get('cc_emails', []),
                    self._parse_freshdesk_datetime(ticket.get('due_by')),
                    self._parse_freshdesk_datetime(ticket.get('fr_due_by')),  # First response due
                    self._parse_freshdesk_datetime(stats.get('first_responded_at')),
                    self._parse_freshdesk_datetime(stats.get('resolved_at')),
                    self._parse_freshdesk_datetime(stats.get('closed_at')),
                    self._parse_freshdesk_datetime(ticket.get('created_at')),
                    self._parse_freshdesk_datetime(ticket.get('updated_at'))
                ))

            with self.conn.cursor() as cursor:
                execute_values(
                    cursor,
                    """
                    INSERT INTO freshdesk_tickets
                    (ticket_id, subject, description, status, priority, source, type,
                     requester_id, responder_id, company_id, group_id, product_id,
                     is_escalated, spam, deleted, tags, cc_emails,
                     due_by, fr_due_by, first_responded_at, resolved_at, closed_at,
                     created_at, updated_at, synced_at)
                    VALUES %s
                    ON CONFLICT (ticket_id) DO UPDATE SET
                        subject = EXCLUDED.subject,
                        description = EXCLUDED.description,
                        status = EXCLUDED.status,
                        priority = EXCLUDED.priority,
                        source = EXCLUDED.source,
                        type = EXCLUDED.type,
                        responder_id = EXCLUDED.responder_id,
                        group_id = EXCLUDED.group_id,
                        is_escalated = EXCLUDED.is_escalated,
                        spam = EXCLUDED.spam,
                        deleted = EXCLUDED.deleted,
                        tags = EXCLUDED.tags,
                        cc_emails = EXCLUDED.cc_emails,
                        due_by = EXCLUDED.due_by,
                        fr_due_by = EXCLUDED.fr_due_by,
                        first_responded_at = EXCLUDED.first_responded_at,
                        resolved_at = EXCLUDED.resolved_at,
                        closed_at = EXCLUDED.closed_at,
                        updated_at = EXCLUDED.updated_at,
                        synced_at = NOW()
                    """,
                    ticket_data
                )

            self.conn.commit()
            logger.info(f"✅ Synced {len(tickets)} tickets")

            # Now ingest custom fields for these tickets
            for ticket in tickets:
                self._upsert_custom_fields(ticket)

            self.update_sync_metadata('/tickets', datetime.now(timezone.utc), len(tickets))

        except Exception as e:
            logger.error(f"Failed to ingest tickets: {e}")
            self.update_sync_metadata('/tickets', datetime.now(timezone.utc),
                                    status='error', error_message=str(e))
            raise

    def _upsert_custom_fields(self, ticket: Dict[str, Any]):
        """Upsert custom fields for a ticket"""
        import json

        custom_fields = ticket.get('custom_fields', {})
        if not custom_fields:
            return

        with self.conn.cursor() as cursor:
            for field_name, field_value in custom_fields.items():
                if field_value is None:
                    continue

                # Detect field type and prepare values
                field_type = None
                string_val = None
                number_val = None
                date_val = None
                json_val = None

                if isinstance(field_value, bool):
                    field_type = 'boolean'
                    string_val = str(field_value)
                elif isinstance(field_value, (int, float)):
                    field_type = 'number'
                    number_val = field_value
                elif isinstance(field_value, str):
                    # Try to parse as date
                    date_val = self._parse_freshdesk_datetime(field_value)
                    if date_val:
                        field_type = 'date'
                    else:
                        field_type = 'text'
                        string_val = field_value
                elif isinstance(field_value, (list, dict)):
                    field_type = 'object' if isinstance(field_value, dict) else 'array'
                    json_val = json.dumps(field_value)
                else:
                    field_type = 'text'
                    string_val = str(field_value)

                cursor.execute(
                    """
                    INSERT INTO freshdesk_custom_fields
                    (ticket_id, field_name, field_type, string_value, number_value,
                     date_value, json_value, synced_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, NOW())
                    ON CONFLICT (ticket_id, field_name) DO UPDATE SET
                        field_type = EXCLUDED.field_type,
                        string_value = EXCLUDED.string_value,
                        number_value = EXCLUDED.number_value,
                        date_value = EXCLUDED.date_value,
                        json_value = EXCLUDED.json_value,
                        synced_at = NOW()
                    """,
                    (ticket['id'], field_name, field_type, string_val,
                     number_val, date_val, json_val)
                )

        self.conn.commit()

    # ========== CONVERSATIONS ==========

    def ingest_conversations(self, ticket_ids: List[int] = None):
        """Ingest conversations (ticket replies) for specific tickets or all recent tickets"""
        logger.info("Starting conversations ingestion...")

        try:
            if not ticket_ids:
                # Get recent ticket IDs from database
                with self.conn.cursor() as cursor:
                    cursor.execute(
                        """
                        SELECT ticket_id FROM freshdesk_tickets
                        WHERE updated_at >= NOW() - INTERVAL '30 days'
                        ORDER BY updated_at DESC
                        LIMIT 1000
                        """
                    )
                    ticket_ids = [row[0] for row in cursor.fetchall()]

            if not ticket_ids:
                logger.info("No tickets found for conversation ingestion")
                return

            total_conversations = 0

            for ticket_id in ticket_ids:
                try:
                    conversations = self._make_request(f'/tickets/{ticket_id}/conversations')

                    if not conversations:
                        continue

                    conv_data = []
                    for conv in conversations:
                        conv_data.append((
                            conv.get('id'),
                            ticket_id,
                            conv.get('user_id'),
                            conv.get('body_text'),
                            conv.get('incoming'),
                            conv.get('private'),
                            conv.get('source'),  # 0=Reply, 2=Note, 5=Forward
                            conv.get('to_emails', []),
                            conv.get('from_email'),
                            self._parse_freshdesk_datetime(conv.get('created_at')),
                            self._parse_freshdesk_datetime(conv.get('updated_at'))
                        ))

                    if conv_data:
                        with self.conn.cursor() as cursor:
                            execute_values(
                                cursor,
                                """
                                INSERT INTO freshdesk_conversations
                                (conversation_id, ticket_id, user_id, body, incoming, private,
                                 source, to_emails, from_email, created_at, updated_at, synced_at)
                                VALUES %s
                                ON CONFLICT (conversation_id) DO UPDATE SET
                                    body = EXCLUDED.body,
                                    updated_at = EXCLUDED.updated_at,
                                    synced_at = NOW()
                                """,
                                conv_data
                            )

                        self.conn.commit()
                        total_conversations += len(conv_data)

                except Exception as e:
                    logger.warning(f"Failed to fetch conversations for ticket {ticket_id}: {e}")
                    continue

            logger.info(f"✅ Synced {total_conversations} conversations")
            self.update_sync_metadata('/conversations', datetime.now(timezone.utc), total_conversations)

        except Exception as e:
            logger.error(f"Failed to ingest conversations: {e}")
            self.update_sync_metadata('/conversations', datetime.now(timezone.utc),
                                    status='error', error_message=str(e))
            raise

    # ========== TIME ENTRIES ==========

    def ingest_time_entries(self, lookback_days: int = 30):
        """Ingest time entries (work logs)"""
        logger.info(f"Starting time entries ingestion (lookback: {lookback_days} days)...")

        try:
            # Get recent tickets
            last_sync = self.get_last_sync_timestamp('/time_entries')
            start_time = last_sync if last_sync else datetime.now(timezone.utc) - timedelta(days=lookback_days)

            with self.conn.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT ticket_id FROM freshdesk_tickets
                    WHERE updated_at >= %s
                    ORDER BY updated_at DESC
                    """,
                    (start_time,)
                )
                ticket_ids = [row[0] for row in cursor.fetchall()]

            if not ticket_ids:
                logger.info("No tickets found for time entries ingestion")
                return

            total_time_entries = 0

            for ticket_id in ticket_ids:
                try:
                    time_entries = self._make_request(f'/tickets/{ticket_id}/time_entries')

                    if not time_entries:
                        continue

                    te_data = []
                    for te in time_entries:
                        te_data.append((
                            te.get('id'),
                            ticket_id,
                            te.get('agent_id'),
                            te.get('billable'),
                            te.get('time_spent'),  # In seconds
                            te.get('note'),
                            self._parse_freshdesk_datetime(te.get('executed_at')),
                            self._parse_freshdesk_datetime(te.get('created_at')),
                            self._parse_freshdesk_datetime(te.get('updated_at'))
                        ))

                    if te_data:
                        with self.conn.cursor() as cursor:
                            execute_values(
                                cursor,
                                """
                                INSERT INTO freshdesk_time_entries
                                (time_entry_id, ticket_id, agent_id, billable, time_spent_seconds,
                                 note, executed_at, created_at, updated_at, synced_at)
                                VALUES %s
                                ON CONFLICT (time_entry_id) DO UPDATE SET
                                    billable = EXCLUDED.billable,
                                    time_spent_seconds = EXCLUDED.time_spent_seconds,
                                    note = EXCLUDED.note,
                                    updated_at = EXCLUDED.updated_at,
                                    synced_at = NOW()
                                """,
                                te_data
                            )

                        self.conn.commit()
                        total_time_entries += len(te_data)

                except Exception as e:
                    logger.warning(f"Failed to fetch time entries for ticket {ticket_id}: {e}")
                    continue

            logger.info(f"✅ Synced {total_time_entries} time entries")
            self.update_sync_metadata('/time_entries', datetime.now(timezone.utc), total_time_entries)

        except Exception as e:
            logger.error(f"Failed to ingest time entries: {e}")
            self.update_sync_metadata('/time_entries', datetime.now(timezone.utc),
                                    status='error', error_message=str(e))
            raise

    # ========== MAIN INGESTION ==========

    def ingest_all(self, lookback_days: int = 30):
        """
        Run full ingestion pipeline for all entities

        Args:
            lookback_days: Number of days to look back for incremental sync
        """
        logger.info("=" * 80)
        logger.info("STARTING FRESHDESK FULL INGESTION")
        logger.info("=" * 80)

        try:
            # 1. Agents and Groups (full sync)
            self.ingest_agents()
            self.ingest_groups()

            # 2. Companies and Contacts (incremental)
            self.ingest_companies()
            self.ingest_contacts(lookback_days)

            # 3. Tickets (incremental, includes custom fields)
            self.ingest_tickets(lookback_days)

            # 4. Conversations and Time Entries (incremental)
            self.ingest_conversations()
            self.ingest_time_entries(lookback_days)

            logger.info("=" * 80)
            logger.info("✅ FRESHDESK FULL INGESTION COMPLETED")
            logger.info("=" * 80)

        except Exception as e:
            logger.error(f"❌ Full ingestion failed: {e}")
            raise
        finally:
            self.close_db()


if __name__ == '__main__':
    # Example usage
    ingestor = FreshdeskIngestor()
    ingestor.ingest_all(lookback_days=30)
