"""
GitHub Incremental Ingestor

This script pulls data from GitHub REST API incrementally:
- Organizations and repositories
- Pull requests with reviews and comments
- Commits
- Issues with comments
- Releases
- Workflows and runs
- Custom fields from GitHub Projects

The script tracks the last sync timestamp and only fetches updated data.
"""

import os
import sys
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Any
import logging

from github import Github, GithubException
from github.Repository import Repository
import psycopg2
from psycopg2.extras import execute_values
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class GitHubIngestor:
    """Incremental data ingestor for GitHub APIs"""

    def __init__(
        self,
        github_token: str,
        github_org: str,
        db_host: str,
        db_name: str,
        db_user: str,
        db_password: str,
        db_port: int = 5432
    ):
        self.github_org = github_org
        self.db_config = {
            'host': db_host,
            'database': db_name,
            'user': db_user,
            'password': db_password,
            'port': db_port
        }
        self.conn = None

        # Initialize GitHub client
        try:
            self.github = Github(github_token)
            # Test connection
            rate_limit = self.github.get_rate_limit()
            logger.info(f"Connected to GitHub. Rate limit: {rate_limit.core.remaining}/{rate_limit.core.limit}")
        except GithubException as e:
            logger.error(f"Failed to connect to GitHub: {e}")
            raise

    def connect_db(self):
        """Establish database connection"""
        try:
            self.conn = psycopg2.connect(**self.db_config)
            logger.info("Database connection established")
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            raise

    def close_db(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()
            logger.info("Database connection closed")

    def get_last_sync_timestamp(self, api_endpoint: str) -> Optional[datetime]:
        """Retrieve the last successful sync timestamp"""
        with self.conn.cursor() as cursor:
            cursor.execute(
                """
                SELECT last_sync_timestamp
                FROM github_sync_metadata
                WHERE api_endpoint = %s AND last_sync_status = 'success'
                """,
                (api_endpoint,)
            )
            result = cursor.fetchone()
            return result[0] if result else None

    def update_sync_metadata(
        self,
        api_endpoint: str,
        timestamp: datetime,
        status: str = 'success',
        records_synced: int = 0,
        error_message: Optional[str] = None
    ):
        """Update sync metadata after API call"""
        with self.conn.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO github_sync_metadata
                (api_endpoint, last_sync_timestamp, last_sync_status, records_synced, error_message, updated_at)
                VALUES (%s, %s, %s, %s, %s, NOW())
                ON CONFLICT (api_endpoint)
                DO UPDATE SET
                    last_sync_timestamp = EXCLUDED.last_sync_timestamp,
                    last_sync_status = EXCLUDED.last_sync_status,
                    records_synced = EXCLUDED.records_synced,
                    error_message = EXCLUDED.error_message,
                    updated_at = NOW()
                """,
                (api_endpoint, timestamp, status, records_synced, error_message)
            )
            self.conn.commit()

    def ingest_organization(self):
        """Ingest organization data"""
        logger.info("Starting organization ingestion...")

        try:
            org = self.github.get_organization(self.github_org)

            with self.conn.cursor() as cursor:
                cursor.execute(
                    """
                    INSERT INTO github_organizations
                    (org_id, login, name, description, url, avatar_url, created_at, updated_at, synced_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (org_id)
                    DO UPDATE SET
                        name = EXCLUDED.name,
                        description = EXCLUDED.description,
                        avatar_url = EXCLUDED.avatar_url,
                        updated_at = EXCLUDED.updated_at,
                        synced_at = EXCLUDED.synced_at
                    """,
                    (
                        org.id,
                        org.login,
                        org.name,
                        org.description,
                        org.html_url,
                        org.avatar_url,
                        org.created_at,
                        org.updated_at,
                        datetime.now(timezone.utc)
                    )
                )
                self.conn.commit()

            logger.info(f"Synced organization: {org.login}")
            self.update_sync_metadata('organization', datetime.now(timezone.utc), records_synced=1)

        except Exception as e:
            logger.error(f"Failed to ingest organization: {e}")
            self.update_sync_metadata('organization', datetime.now(timezone.utc), status='failed', error_message=str(e))
            raise

    def ingest_repositories(self, repo_names: Optional[List[str]] = None):
        """Ingest repositories"""
        logger.info("Starting repositories ingestion...")

        try:
            org = self.github.get_organization(self.github_org)
            repos = org.get_repos()

            repo_count = 0
            for repo in repos:
                if repo_names and repo.name not in repo_names:
                    continue

                self._upsert_repository(repo)
                repo_count += 1

            logger.info(f"Synced {repo_count} repositories")
            self.update_sync_metadata('repositories', datetime.now(timezone.utc), records_synced=repo_count)

        except Exception as e:
            logger.error(f"Failed to ingest repositories: {e}")
            self.update_sync_metadata('repositories', datetime.now(timezone.utc), status='failed', error_message=str(e))
            raise

    def _upsert_repository(self, repo: Repository):
        """Upsert a single repository"""
        with self.conn.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO github_repositories
                (repo_id, org_login, repo_name, full_name, description, private, fork,
                 default_branch, language, size_kb, stargazers_count, watchers_count,
                 forks_count, open_issues_count, created_at, updated_at, pushed_at, synced_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (repo_id)
                DO UPDATE SET
                    description = EXCLUDED.description,
                    default_branch = EXCLUDED.default_branch,
                    language = EXCLUDED.language,
                    size_kb = EXCLUDED.size_kb,
                    stargazers_count = EXCLUDED.stargazers_count,
                    watchers_count = EXCLUDED.watchers_count,
                    forks_count = EXCLUDED.forks_count,
                    open_issues_count = EXCLUDED.open_issues_count,
                    updated_at = EXCLUDED.updated_at,
                    pushed_at = EXCLUDED.pushed_at,
                    synced_at = EXCLUDED.synced_at
                """,
                (
                    repo.id,
                    repo.organization.login if repo.organization else None,
                    repo.name,
                    repo.full_name,
                    repo.description,
                    repo.private,
                    repo.fork,
                    repo.default_branch,
                    repo.language,
                    repo.size,
                    repo.stargazers_count,
                    repo.watchers_count,
                    repo.forks_count,
                    repo.open_issues_count,
                    repo.created_at,
                    repo.updated_at,
                    repo.pushed_at,
                    datetime.now(timezone.utc)
                )
            )
            self.conn.commit()

    def ingest_pull_requests(self, repo_names: Optional[List[str]] = None, lookback_days: int = 30):
        """Ingest pull requests with reviews and comments"""
        logger.info("Starting pull requests ingestion...")

        try:
            org = self.github.get_organization(self.github_org)
            last_sync = self.get_last_sync_timestamp('pull_requests')
            since_date = last_sync - timedelta(days=lookback_days) if last_sync else None

            total_prs = 0

            for repo in org.get_repos():
                if repo_names and repo.name not in repo_names:
                    continue

                # Get PRs updated since last sync
                pulls = repo.get_pulls(state='all', sort='updated', direction='desc')

                for pr in pulls:
                    # Skip if too old
                    if since_date and pr.updated_at < since_date:
                        break

                    self._upsert_pull_request(pr)
                    self._upsert_pr_reviews(pr)
                    self._upsert_pr_review_comments(pr)
                    total_prs += 1

            logger.info(f"Synced {total_prs} pull requests")
            self.update_sync_metadata('pull_requests', datetime.now(timezone.utc), records_synced=total_prs)

        except Exception as e:
            logger.error(f"Failed to ingest pull requests: {e}")
            self.update_sync_metadata('pull_requests', datetime.now(timezone.utc), status='failed', error_message=str(e))
            raise

    def _upsert_pull_request(self, pr):
        """Upsert a pull request"""
        # First upsert users
        if pr.user:
            self._upsert_user(pr.user)
        if pr.merged_by:
            self._upsert_user(pr.merged_by)

        with self.conn.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO github_pull_requests
                (pr_id, repo_full_name, pr_number, title, body, state, draft, author_login,
                 assignees, requested_reviewers, labels, created_at, updated_at, closed_at,
                 merged_at, merged_by_login, base_branch, head_branch, additions, deletions,
                 changed_files, commits_count, comments_count, review_comments_count, synced_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (repo_full_name, pr_number)
                DO UPDATE SET
                    title = EXCLUDED.title,
                    body = EXCLUDED.body,
                    state = EXCLUDED.state,
                    updated_at = EXCLUDED.updated_at,
                    closed_at = EXCLUDED.closed_at,
                    merged_at = EXCLUDED.merged_at,
                    merged_by_login = EXCLUDED.merged_by_login,
                    additions = EXCLUDED.additions,
                    deletions = EXCLUDED.deletions,
                    changed_files = EXCLUDED.changed_files,
                    commits_count = EXCLUDED.commits_count,
                    comments_count = EXCLUDED.comments_count,
                    review_comments_count = EXCLUDED.review_comments_count,
                    synced_at = EXCLUDED.synced_at
                """,
                (
                    pr.id,
                    pr.base.repo.full_name,
                    pr.number,
                    pr.title,
                    pr.body,
                    pr.state,
                    pr.draft,
                    pr.user.login if pr.user else None,
                    [a.login for a in pr.assignees] if pr.assignees else [],
                    [r.login for r in pr.requested_reviewers] if pr.requested_reviewers else [],
                    [l.name for l in pr.labels] if pr.labels else [],
                    pr.created_at,
                    pr.updated_at,
                    pr.closed_at,
                    pr.merged_at,
                    pr.merged_by.login if pr.merged_by else None,
                    pr.base.ref,
                    pr.head.ref,
                    pr.additions,
                    pr.deletions,
                    pr.changed_files,
                    pr.commits,
                    pr.comments,
                    pr.review_comments,
                    datetime.now(timezone.utc)
                )
            )
            self.conn.commit()

    def _upsert_pr_reviews(self, pr):
        """Upsert PR reviews"""
        try:
            reviews = pr.get_reviews()

            with self.conn.cursor() as cursor:
                for review in reviews:
                    if review.user:
                        self._upsert_user(review.user)

                    cursor.execute(
                        """
                        INSERT INTO github_pr_reviews
                        (review_id, pr_id, reviewer_login, state, body, submitted_at, synced_at)
                        VALUES (%s, %s, %s, %s, %s, %s, %s)
                        ON CONFLICT (review_id)
                        DO UPDATE SET
                            state = EXCLUDED.state,
                            body = EXCLUDED.body,
                            synced_at = EXCLUDED.synced_at
                        """,
                        (
                            review.id,
                            pr.id,
                            review.user.login if review.user else None,
                            review.state,
                            review.body,
                            review.submitted_at,
                            datetime.now(timezone.utc)
                        )
                    )
                self.conn.commit()
        except GithubException as e:
            logger.warning(f"Could not fetch reviews for PR {pr.number}: {e}")

    def _upsert_pr_review_comments(self, pr):
        """Upsert PR review comments"""
        try:
            comments = pr.get_review_comments()

            with self.conn.cursor() as cursor:
                for comment in comments:
                    if comment.user:
                        self._upsert_user(comment.user)

                    cursor.execute(
                        """
                        INSERT INTO github_pr_review_comments
                        (comment_id, pr_id, review_id, author_login, body, path, position,
                         created_at, updated_at, synced_at)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        ON CONFLICT (comment_id)
                        DO UPDATE SET
                            body = EXCLUDED.body,
                            updated_at = EXCLUDED.updated_at,
                            synced_at = EXCLUDED.synced_at
                        """,
                        (
                            comment.id,
                            pr.id,
                            comment.pull_request_review_id if hasattr(comment, 'pull_request_review_id') else None,
                            comment.user.login if comment.user else None,
                            comment.body,
                            comment.path,
                            comment.position,
                            comment.created_at,
                            comment.updated_at,
                            datetime.now(timezone.utc)
                        )
                    )
                self.conn.commit()
        except GithubException as e:
            logger.warning(f"Could not fetch review comments for PR {pr.number}: {e}")

    def _upsert_user(self, user):
        """Upsert a GitHub user"""
        with self.conn.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO github_users
                (user_id, login, name, email, avatar_url, user_type, site_admin,
                 company, location, created_at, updated_at, synced_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (user_id)
                DO UPDATE SET
                    name = EXCLUDED.name,
                    email = EXCLUDED.email,
                    avatar_url = EXCLUDED.avatar_url,
                    company = EXCLUDED.company,
                    location = EXCLUDED.location,
                    updated_at = EXCLUDED.updated_at,
                    synced_at = EXCLUDED.synced_at
                """,
                (
                    user.id,
                    user.login,
                    user.name,
                    user.email,
                    user.avatar_url,
                    user.type,
                    user.site_admin,
                    getattr(user, 'company', None),
                    getattr(user, 'location', None),
                    user.created_at,
                    user.updated_at if hasattr(user, 'updated_at') else None,
                    datetime.now(timezone.utc)
                )
            )
            self.conn.commit()

    def run_full_sync(self, repo_names: Optional[List[str]] = None):
        """
        Run complete sync of all GitHub data

        Args:
            repo_names: Optional list of repository names to filter
        """
        logger.info("="*50)
        logger.info("Starting full GitHub data sync")
        logger.info("="*50)

        try:
            self.connect_db()

            # Sync organization
            self.ingest_organization()

            # Sync repositories
            self.ingest_repositories(repo_names)

            # Sync pull requests
            self.ingest_pull_requests(repo_names)

            logger.info("="*50)
            logger.info("Full sync completed successfully")
            logger.info("="*50)

        except Exception as e:
            logger.error(f"Full sync failed: {e}")
            raise
        finally:
            self.close_db()


def main():
    """Main entry point for the ingestor"""

    # Load configuration from environment
    GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
    GITHUB_ORG = os.getenv('GITHUB_ORG')
    DB_HOST = os.getenv('DB_HOST', 'localhost')
    DB_NAME = os.getenv('DB_NAME', 'pulse')
    DB_USER = os.getenv('DB_USER', 'pulse_user')
    DB_PASSWORD = os.getenv('DB_PASSWORD')
    DB_PORT = int(os.getenv('DB_PORT', 5432))

    # Optional: Filter by specific repos
    REPO_NAMES = os.getenv('GITHUB_REPOS', '').split(',') if os.getenv('GITHUB_REPOS') else None

    if not GITHUB_TOKEN or not GITHUB_ORG:
        logger.error("GITHUB_TOKEN and GITHUB_ORG not found in environment")
        sys.exit(1)

    if not DB_PASSWORD:
        logger.error("DB_PASSWORD not found in environment")
        sys.exit(1)

    # Create ingestor and run
    ingestor = GitHubIngestor(
        github_token=GITHUB_TOKEN,
        github_org=GITHUB_ORG,
        db_host=DB_HOST,
        db_name=DB_NAME,
        db_user=DB_USER,
        db_password=DB_PASSWORD,
        db_port=DB_PORT
    )

    ingestor.run_full_sync(repo_names=REPO_NAMES)


if __name__ == '__main__':
    main()
