"""
JIRA Incremental Ingestor

This script pulls data from JIRA Cloud APIs incrementally:
- Projects and users
- Issues with all fields
- Comments, worklogs, attachments
- Issue changelog (transitions, assignments)
- Boards and sprints
- Issue links

The script tracks the last sync timestamp and only fetches updated data.
"""

import os
import sys
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Any
import logging

from jira import JIRA
from jira.exceptions import JIRAError
import psycopg2
from psycopg2.extras import execute_values
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class JiraIngestor:
    """Incremental data ingestor for JIRA Cloud APIs"""

    def __init__(
        self,
        jira_url: str,
        jira_email: str,
        jira_api_token: str,
        db_host: str,
        db_name: str,
        db_user: str,
        db_password: str,
        db_port: int = 5432
    ):
        self.jira_url = jira_url
        self.db_config = {
            'host': db_host,
            'database': db_name,
            'user': db_user,
            'password': db_password,
            'port': db_port
        }
        self.conn = None

        # Initialize JIRA client
        try:
            self.jira = JIRA(
                server=jira_url,
                basic_auth=(jira_email, jira_api_token),
                max_retries=3
            )
            logger.info(f"Connected to JIRA: {jira_url}")
        except JIRAError as e:
            logger.error(f"Failed to connect to JIRA: {e}")
            raise

    def connect_db(self):
        """Establish database connection"""
        try:
            self.conn = psycopg2.connect(**self.db_config)
            logger.info("Database connection established")
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            raise

    def close_db(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()
            logger.info("Database connection closed")

    def get_last_sync_timestamp(self, api_endpoint: str) -> Optional[datetime]:
        """Retrieve the last successful sync timestamp for an API endpoint"""
        with self.conn.cursor() as cursor:
            cursor.execute(
                """
                SELECT last_sync_timestamp
                FROM jira_sync_metadata
                WHERE api_endpoint = %s AND last_sync_status = 'success'
                """,
                (api_endpoint,)
            )
            result = cursor.fetchone()
            return result[0] if result else None

    def update_sync_metadata(
        self,
        api_endpoint: str,
        timestamp: datetime,
        status: str = 'success',
        records_synced: int = 0,
        error_message: Optional[str] = None
    ):
        """Update sync metadata after API call"""
        with self.conn.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO jira_sync_metadata
                (api_endpoint, last_sync_timestamp, last_sync_status, records_synced, error_message, updated_at)
                VALUES (%s, %s, %s, %s, %s, NOW())
                ON CONFLICT (api_endpoint)
                DO UPDATE SET
                    last_sync_timestamp = EXCLUDED.last_sync_timestamp,
                    last_sync_status = EXCLUDED.last_sync_status,
                    records_synced = EXCLUDED.records_synced,
                    error_message = EXCLUDED.error_message,
                    updated_at = NOW()
                """,
                (api_endpoint, timestamp, status, records_synced, error_message)
            )
            self.conn.commit()

    def ingest_projects(self):
        """Ingest all JIRA projects"""
        logger.info("Starting projects ingestion...")

        try:
            projects = self.jira.projects()

            if not projects:
                logger.info("No projects found")
                return

            with self.conn.cursor() as cursor:
                upsert_query = """
                    INSERT INTO jira_projects
                    (project_key, project_id, project_name, project_type, lead_account_id,
                     description, url, synced_at)
                    VALUES %s
                    ON CONFLICT (project_key)
                    DO UPDATE SET
                        project_name = EXCLUDED.project_name,
                        project_type = EXCLUDED.project_type,
                        lead_account_id = EXCLUDED.lead_account_id,
                        description = EXCLUDED.description,
                        url = EXCLUDED.url,
                        synced_at = EXCLUDED.synced_at
                """

                values = [
                    (
                        proj.key,
                        proj.id,
                        proj.name,
                        getattr(proj, 'projectTypeKey', None),
                        getattr(proj.lead, 'accountId', None) if hasattr(proj, 'lead') else None,
                        getattr(proj, 'description', None),
                        getattr(proj, 'self', None),
                        datetime.now(timezone.utc)
                    )
                    for proj in projects
                ]

                execute_values(cursor, upsert_query, values)
                self.conn.commit()

            logger.info(f"Synced {len(projects)} projects")
            self.update_sync_metadata('projects', datetime.now(timezone.utc), records_synced=len(projects))

        except Exception as e:
            logger.error(f"Failed to ingest projects: {e}")
            self.update_sync_metadata('projects', datetime.now(timezone.utc), status='failed', error_message=str(e))
            raise

    def ingest_users(self, user_account_ids: set):
        """Ingest JIRA users by account IDs"""
        if not user_account_ids:
            return

        logger.info(f"Starting users ingestion for {len(user_account_ids)} users...")

        try:
            users_data = []
            for account_id in user_account_ids:
                try:
                    user = self.jira.user(account_id)
                    users_data.append((
                        user.accountId,
                        getattr(user, 'emailAddress', None),
                        user.displayName,
                        user.active,
                        getattr(user, 'timeZone', None),
                        user.accountType,
                        datetime.now(timezone.utc)
                    ))
                except JIRAError as e:
                    logger.warning(f"Could not fetch user {account_id}: {e}")
                    continue

            if users_data:
                with self.conn.cursor() as cursor:
                    upsert_query = """
                        INSERT INTO jira_users
                        (account_id, email, display_name, active, time_zone, account_type, synced_at)
                        VALUES %s
                        ON CONFLICT (account_id)
                        DO UPDATE SET
                            email = EXCLUDED.email,
                            display_name = EXCLUDED.display_name,
                            active = EXCLUDED.active,
                            time_zone = EXCLUDED.time_zone,
                            account_type = EXCLUDED.account_type,
                            synced_at = EXCLUDED.synced_at
                    """
                    execute_values(cursor, upsert_query, users_data)
                    self.conn.commit()

                logger.info(f"Synced {len(users_data)} users")

        except Exception as e:
            logger.error(f"Failed to ingest users: {e}")
            raise

    def ingest_issues(self, project_keys: Optional[List[str]] = None, lookback_days: int = 30):
        """
        Ingest issues with all fields, changelog, comments, worklogs

        Args:
            project_keys: Optional list of project keys to filter
            lookback_days: Number of days to look back for incremental sync
        """
        logger.info("Starting issues ingestion...")

        # Get last sync time
        last_sync = self.get_last_sync_timestamp('issues')

        # Build JQL query for incremental sync
        if last_sync:
            # Look back a bit to catch late updates
            start_date = (last_sync - timedelta(days=lookback_days)).strftime('%Y-%m-%d')
            jql = f"updated >= '{start_date}'"
        else:
            # First run - get all issues (or last 365 days to be safe)
            start_date = (datetime.now(timezone.utc) - timedelta(days=365)).strftime('%Y-%m-%d')
            jql = f"updated >= '{start_date}'"

        if project_keys:
            projects_str = ','.join(project_keys)
            jql += f" AND project IN ({projects_str})"

        jql += " ORDER BY updated ASC"

        logger.info(f"JQL Query: {jql}")

        try:
            # Search issues with pagination
            start_at = 0
            max_results = 100
            total_issues = 0
            user_account_ids = set()

            while True:
                issues = self.jira.search_issues(
                    jql,
                    startAt=start_at,
                    maxResults=max_results,
                    expand='changelog',
                    fields='*all'
                )

                if not issues:
                    break

                logger.info(f"Processing issues {start_at} to {start_at + len(issues)}")

                # Process each issue
                for issue in issues:
                    self._process_issue(issue, user_account_ids)

                total_issues += len(issues)

                if len(issues) < max_results:
                    break

                start_at += max_results

            # Ingest users we encountered
            self.ingest_users(user_account_ids)

            logger.info(f"Synced {total_issues} issues")
            self.update_sync_metadata('issues', datetime.now(timezone.utc), records_synced=total_issues)

        except Exception as e:
            logger.error(f"Failed to ingest issues: {e}")
            self.update_sync_metadata('issues', datetime.now(timezone.utc), status='failed', error_message=str(e))
            raise

    def _process_issue(self, issue, user_account_ids: set):
        """Process a single issue and all related data"""

        # Collect user IDs
        if hasattr(issue.fields, 'assignee') and issue.fields.assignee:
            user_account_ids.add(issue.fields.assignee.accountId)
        if hasattr(issue.fields, 'reporter') and issue.fields.reporter:
            user_account_ids.add(issue.fields.reporter.accountId)
        if hasattr(issue.fields, 'creator') and issue.fields.creator:
            user_account_ids.add(issue.fields.creator.accountId)

        # Upsert issue
        self._upsert_issue(issue)

        # Process custom fields
        self._upsert_custom_fields(issue)

        # Process changelog
        if hasattr(issue, 'changelog'):
            self._upsert_changelog(issue)

        # Process comments
        self._upsert_comments(issue, user_account_ids)

        # Process worklogs
        self._upsert_worklogs(issue, user_account_ids)

        # Process attachments
        self._upsert_attachments(issue, user_account_ids)

        # Process issue links
        self._upsert_issue_links(issue)

    def _upsert_issue(self, issue):
        """Upsert a single issue"""
        with self.conn.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO jira_issues
                (issue_id, issue_key, project_key, summary, description, issue_type, status, priority,
                 resolution, assignee_account_id, reporter_account_id, creator_account_id,
                 created_at, updated_at, resolved_at, due_date, parent_issue_key, epic_key,
                 story_points, original_estimate_seconds, remaining_estimate_seconds, time_spent_seconds,
                 labels, components, fix_versions, synced_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (issue_id)
                DO UPDATE SET
                    summary = EXCLUDED.summary,
                    description = EXCLUDED.description,
                    issue_type = EXCLUDED.issue_type,
                    status = EXCLUDED.status,
                    priority = EXCLUDED.priority,
                    resolution = EXCLUDED.resolution,
                    assignee_account_id = EXCLUDED.assignee_account_id,
                    updated_at = EXCLUDED.updated_at,
                    resolved_at = EXCLUDED.resolved_at,
                    due_date = EXCLUDED.due_date,
                    story_points = EXCLUDED.story_points,
                    remaining_estimate_seconds = EXCLUDED.remaining_estimate_seconds,
                    time_spent_seconds = EXCLUDED.time_spent_seconds,
                    labels = EXCLUDED.labels,
                    components = EXCLUDED.components,
                    fix_versions = EXCLUDED.fix_versions,
                    synced_at = EXCLUDED.synced_at
                """,
                (
                    issue.id,
                    issue.key,
                    issue.fields.project.key,
                    issue.fields.summary,
                    getattr(issue.fields, 'description', None),
                    issue.fields.issuetype.name,
                    issue.fields.status.name,
                    issue.fields.priority.name if hasattr(issue.fields, 'priority') and issue.fields.priority else None,
                    issue.fields.resolution.name if hasattr(issue.fields, 'resolution') and issue.fields.resolution else None,
                    issue.fields.assignee.accountId if hasattr(issue.fields, 'assignee') and issue.fields.assignee else None,
                    issue.fields.reporter.accountId if hasattr(issue.fields, 'reporter') and issue.fields.reporter else None,
                    issue.fields.creator.accountId if hasattr(issue.fields, 'creator') and issue.fields.creator else None,
                    self._parse_jira_datetime(issue.fields.created),
                    self._parse_jira_datetime(issue.fields.updated),
                    self._parse_jira_datetime(getattr(issue.fields, 'resolutiondate', None)),
                    self._parse_jira_date(getattr(issue.fields, 'duedate', None)),
                    issue.fields.parent.key if hasattr(issue.fields, 'parent') and issue.fields.parent else None,
                    getattr(issue.fields, 'customfield_10014', None),  # Epic Link (common field)
                    getattr(issue.fields, 'customfield_10016', None),  # Story Points (common field)
                    getattr(issue.fields, 'timeoriginalestimate', None),
                    getattr(issue.fields, 'timeestimate', None),
                    getattr(issue.fields, 'timespent', None),
                    issue.fields.labels if hasattr(issue.fields, 'labels') else [],
                    [c.name for c in issue.fields.components] if hasattr(issue.fields, 'components') else [],
                    [v.name for v in issue.fields.fixVersions] if hasattr(issue.fields, 'fixVersions') else [],
                    datetime.now(timezone.utc)
                )
            )
            self.conn.commit()

    def _upsert_custom_fields(self, issue):
        """Upsert custom fields for an issue"""
        import json

        # Get all fields from the issue
        raw_fields = issue.raw['fields']

        with self.conn.cursor() as cursor:
            for field_id, field_value in raw_fields.items():
                # Skip standard fields and null values
                if not field_id.startswith('customfield_') or field_value is None:
                    continue

                # Try to get field name from schema
                try:
                    field_schema = self.jira.field(field_id)
                    field_name = field_schema.get('name', field_id) if isinstance(field_schema, dict) else field_id
                except:
                    field_name = field_id

                # Determine field type and extract values
                string_val = None
                number_val = None
                date_val = None
                json_val = None
                field_type = 'string'

                if isinstance(field_value, (int, float)):
                    field_type = 'number'
                    number_val = field_value
                elif isinstance(field_value, str):
                    # Check if it's a date
                    try:
                        date_val = self._parse_jira_datetime(field_value)
                        if date_val:
                            field_type = 'date'
                        else:
                            string_val = field_value
                    except:
                        string_val = field_value
                elif isinstance(field_value, (list, dict)):
                    field_type = 'object' if isinstance(field_value, dict) else 'array'
                    json_val = json.dumps(field_value)
                else:
                    # Try to convert to string
                    try:
                        string_val = str(field_value)
                    except:
                        continue

                cursor.execute(
                    """
                    INSERT INTO jira_custom_fields
                    (issue_key, field_id, field_name, field_type, string_value, number_value, date_value, json_value, synced_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (issue_key, field_id)
                    DO UPDATE SET
                        field_name = EXCLUDED.field_name,
                        field_type = EXCLUDED.field_type,
                        string_value = EXCLUDED.string_value,
                        number_value = EXCLUDED.number_value,
                        date_value = EXCLUDED.date_value,
                        json_value = EXCLUDED.json_value,
                        synced_at = EXCLUDED.synced_at
                    """,
                    (
                        issue.key,
                        field_id,
                        field_name,
                        field_type,
                        string_val,
                        number_val,
                        date_val,
                        json_val,
                        datetime.now(timezone.utc)
                    )
                )
            self.conn.commit()

    def _upsert_changelog(self, issue):
        """Upsert issue changelog"""
        if not hasattr(issue, 'changelog') or not issue.changelog:
            return

        with self.conn.cursor() as cursor:
            for history in issue.changelog.histories:
                for item in history.items:
                    cursor.execute(
                        """
                        INSERT INTO jira_issue_changelog
                        (issue_key, change_id, created_at, author_account_id, field_name,
                         from_string, to_string, from_value, to_value, synced_at)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        ON CONFLICT (issue_key, change_id, field_name) DO NOTHING
                        """,
                        (
                            issue.key,
                            history.id,
                            self._parse_jira_datetime(history.created),
                            history.author.accountId if hasattr(history, 'author') and history.author else None,
                            item.field,
                            item.fromString,
                            item.toString,
                            item.from_,
                            item.to,
                            datetime.now(timezone.utc)
                        )
                    )
            self.conn.commit()

    def _upsert_comments(self, issue, user_account_ids: set):
        """Upsert issue comments"""
        try:
            comments = self.jira.comments(issue.key)
            if not comments:
                return

            with self.conn.cursor() as cursor:
                for comment in comments:
                    if hasattr(comment, 'author') and comment.author:
                        user_account_ids.add(comment.author.accountId)

                    cursor.execute(
                        """
                        INSERT INTO jira_comments
                        (comment_id, issue_key, author_account_id, body, created_at, updated_at, synced_at)
                        VALUES (%s, %s, %s, %s, %s, %s, %s)
                        ON CONFLICT (comment_id)
                        DO UPDATE SET
                            body = EXCLUDED.body,
                            updated_at = EXCLUDED.updated_at,
                            synced_at = EXCLUDED.synced_at
                        """,
                        (
                            comment.id,
                            issue.key,
                            comment.author.accountId if hasattr(comment, 'author') and comment.author else None,
                            comment.body,
                            self._parse_jira_datetime(comment.created),
                            self._parse_jira_datetime(comment.updated),
                            datetime.now(timezone.utc)
                        )
                    )
                self.conn.commit()
        except JIRAError as e:
            logger.warning(f"Could not fetch comments for {issue.key}: {e}")

    def _upsert_worklogs(self, issue, user_account_ids: set):
        """Upsert issue worklogs"""
        try:
            worklogs = self.jira.worklogs(issue.key)
            if not worklogs:
                return

            with self.conn.cursor() as cursor:
                for worklog in worklogs:
                    if hasattr(worklog, 'author') and worklog.author:
                        user_account_ids.add(worklog.author.accountId)

                    cursor.execute(
                        """
                        INSERT INTO jira_worklogs
                        (worklog_id, issue_key, author_account_id, time_spent_seconds, comment,
                         started_at, created_at, updated_at, synced_at)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                        ON CONFLICT (worklog_id)
                        DO UPDATE SET
                            time_spent_seconds = EXCLUDED.time_spent_seconds,
                            comment = EXCLUDED.comment,
                            updated_at = EXCLUDED.updated_at,
                            synced_at = EXCLUDED.synced_at
                        """,
                        (
                            worklog.id,
                            issue.key,
                            worklog.author.accountId if hasattr(worklog, 'author') and worklog.author else None,
                            worklog.timeSpentSeconds,
                            getattr(worklog, 'comment', None),
                            self._parse_jira_datetime(worklog.started),
                            self._parse_jira_datetime(worklog.created),
                            self._parse_jira_datetime(worklog.updated),
                            datetime.now(timezone.utc)
                        )
                    )
                self.conn.commit()
        except JIRAError as e:
            logger.warning(f"Could not fetch worklogs for {issue.key}: {e}")

    def _upsert_attachments(self, issue, user_account_ids: set):
        """Upsert issue attachments metadata"""
        if not hasattr(issue.fields, 'attachment') or not issue.fields.attachment:
            return

        with self.conn.cursor() as cursor:
            for attachment in issue.fields.attachment:
                if hasattr(attachment, 'author') and attachment.author:
                    user_account_ids.add(attachment.author.accountId)

                cursor.execute(
                    """
                    INSERT INTO jira_attachments
                    (attachment_id, issue_key, filename, author_account_id, created_at,
                     size_bytes, mime_type, content_url, synced_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (attachment_id) DO NOTHING
                    """,
                    (
                        attachment.id,
                        issue.key,
                        attachment.filename,
                        attachment.author.accountId if hasattr(attachment, 'author') and attachment.author else None,
                        self._parse_jira_datetime(attachment.created),
                        attachment.size,
                        attachment.mimeType,
                        attachment.content,
                        datetime.now(timezone.utc)
                    )
                )
            self.conn.commit()

    def _upsert_issue_links(self, issue):
        """Upsert issue links"""
        if not hasattr(issue.fields, 'issuelinks') or not issue.fields.issuelinks:
            return

        with self.conn.cursor() as cursor:
            for link in issue.fields.issuelinks:
                link_type = link.type.name

                # Determine inward/outward
                if hasattr(link, 'inwardIssue'):
                    inward_key = link.inwardIssue.key
                    outward_key = issue.key
                elif hasattr(link, 'outwardIssue'):
                    inward_key = issue.key
                    outward_key = link.outwardIssue.key
                else:
                    continue

                cursor.execute(
                    """
                    INSERT INTO jira_issue_links
                    (link_id, link_type, inward_issue_key, outward_issue_key, synced_at)
                    VALUES (%s, %s, %s, %s, %s)
                    ON CONFLICT (link_id) DO NOTHING
                    """,
                    (
                        link.id,
                        link_type,
                        inward_key,
                        outward_key,
                        datetime.now(timezone.utc)
                    )
                )
            self.conn.commit()

    def ingest_boards_and_sprints(self, project_keys: Optional[List[str]] = None):
        """Ingest boards and sprints"""
        logger.info("Starting boards and sprints ingestion...")

        try:
            # Get all boards
            start_at = 0
            max_results = 50
            total_boards = 0

            while True:
                boards = self.jira.boards(startAt=start_at, maxResults=max_results, projectKeyOrID=project_keys[0] if project_keys else None)

                if not boards:
                    break

                for board in boards:
                    self._upsert_board(board)
                    self._upsert_sprints_for_board(board.id)

                total_boards += len(boards)

                if len(boards) < max_results:
                    break

                start_at += max_results

            logger.info(f"Synced {total_boards} boards")
            self.update_sync_metadata('boards', datetime.now(timezone.utc), records_synced=total_boards)

        except Exception as e:
            logger.error(f"Failed to ingest boards: {e}")
            self.update_sync_metadata('boards', datetime.now(timezone.utc), status='failed', error_message=str(e))
            raise

    def _upsert_board(self, board):
        """Upsert a board"""
        with self.conn.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO jira_boards
                (board_id, board_name, board_type, project_key, location_type, location_key, synced_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (board_id)
                DO UPDATE SET
                    board_name = EXCLUDED.board_name,
                    board_type = EXCLUDED.board_type,
                    synced_at = EXCLUDED.synced_at
                """,
                (
                    board.id,
                    board.name,
                    board.type,
                    getattr(board.location, 'projectKey', None) if hasattr(board, 'location') else None,
                    getattr(board.location, 'displayName', None) if hasattr(board, 'location') else None,
                    getattr(board.location, 'projectKey', None) if hasattr(board, 'location') else None,
                    datetime.now(timezone.utc)
                )
            )
            self.conn.commit()

    def _upsert_sprints_for_board(self, board_id: int):
        """Upsert sprints for a board"""
        try:
            sprints = self.jira.sprints(board_id)

            if not sprints:
                return

            with self.conn.cursor() as cursor:
                for sprint in sprints:
                    cursor.execute(
                        """
                        INSERT INTO jira_sprints
                        (sprint_id, sprint_name, board_id, state, start_date, end_date, complete_date, goal, synced_at)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                        ON CONFLICT (sprint_id)
                        DO UPDATE SET
                            sprint_name = EXCLUDED.sprint_name,
                            state = EXCLUDED.state,
                            start_date = EXCLUDED.start_date,
                            end_date = EXCLUDED.end_date,
                            complete_date = EXCLUDED.complete_date,
                            goal = EXCLUDED.goal,
                            synced_at = EXCLUDED.synced_at
                        """,
                        (
                            sprint.id,
                            sprint.name,
                            board_id,
                            sprint.state,
                            self._parse_jira_datetime(getattr(sprint, 'startDate', None)),
                            self._parse_jira_datetime(getattr(sprint, 'endDate', None)),
                            self._parse_jira_datetime(getattr(sprint, 'completeDate', None)),
                            getattr(sprint, 'goal', None),
                            datetime.now(timezone.utc)
                        )
                    )

                    # Get issues in sprint
                    self._upsert_sprint_issues(sprint.id)

                self.conn.commit()
        except JIRAError as e:
            logger.warning(f"Could not fetch sprints for board {board_id}: {e}")

    def _upsert_sprint_issues(self, sprint_id: int):
        """Upsert issues in a sprint"""
        try:
            # Get issues in sprint
            issues = self.jira.sprint(sprint_id)

            if not hasattr(issues, 'issues'):
                return

            with self.conn.cursor() as cursor:
                for issue in issues.issues:
                    cursor.execute(
                        """
                        INSERT INTO jira_sprint_issues
                        (sprint_id, issue_key, synced_at)
                        VALUES (%s, %s, %s)
                        ON CONFLICT (sprint_id, issue_key) DO NOTHING
                        """,
                        (
                            sprint_id,
                            issue.key,
                            datetime.now(timezone.utc)
                        )
                    )
                self.conn.commit()
        except JIRAError as e:
            logger.warning(f"Could not fetch issues for sprint {sprint_id}: {e}")

    @staticmethod
    def _parse_jira_datetime(dt_str: Optional[str]) -> Optional[datetime]:
        """Parse JIRA datetime string"""
        if not dt_str:
            return None
        try:
            # JIRA format: 2023-01-01T00:00:00.000+0000
            return datetime.fromisoformat(dt_str.replace('+0000', '+00:00'))
        except (ValueError, AttributeError):
            return None

    @staticmethod
    def _parse_jira_date(date_str: Optional[str]) -> Optional[str]:
        """Parse JIRA date string"""
        if not date_str:
            return None
        try:
            # Return date string as-is (YYYY-MM-DD format)
            return date_str
        except (ValueError, AttributeError):
            return None

    def run_full_sync(self, project_keys: Optional[List[str]] = None):
        """
        Run complete sync of all JIRA data

        Args:
            project_keys: Optional list of project keys to filter
        """
        logger.info("="*50)
        logger.info("Starting full JIRA data sync")
        logger.info("="*50)

        try:
            self.connect_db()

            # Sync projects
            self.ingest_projects()

            # Sync issues (includes comments, worklogs, changelog, etc.)
            self.ingest_issues(project_keys)

            # Sync boards and sprints
            self.ingest_boards_and_sprints(project_keys)

            logger.info("="*50)
            logger.info("Full sync completed successfully")
            logger.info("="*50)

        except Exception as e:
            logger.error(f"Full sync failed: {e}")
            raise
        finally:
            self.close_db()


def main():
    """Main entry point for the ingestor"""

    # Load configuration from environment
    JIRA_URL = os.getenv('JIRA_URL')
    JIRA_EMAIL = os.getenv('JIRA_EMAIL')
    JIRA_API_TOKEN = os.getenv('JIRA_API_TOKEN')
    DB_HOST = os.getenv('DB_HOST', 'localhost')
    DB_NAME = os.getenv('DB_NAME', 'pulse')
    DB_USER = os.getenv('DB_USER', 'pulse_user')
    DB_PASSWORD = os.getenv('DB_PASSWORD')
    DB_PORT = int(os.getenv('DB_PORT', 5432))

    # Optional: Filter by specific projects
    PROJECT_KEYS = os.getenv('JIRA_PROJECT_KEYS', '').split(',') if os.getenv('JIRA_PROJECT_KEYS') else None

    if not JIRA_URL or not JIRA_EMAIL or not JIRA_API_TOKEN:
        logger.error("JIRA credentials not found in environment")
        sys.exit(1)

    if not DB_PASSWORD:
        logger.error("DB_PASSWORD not found in environment")
        sys.exit(1)

    # Create ingestor and run
    ingestor = JiraIngestor(
        jira_url=JIRA_URL,
        jira_email=JIRA_EMAIL,
        jira_api_token=JIRA_API_TOKEN,
        db_host=DB_HOST,
        db_name=DB_NAME,
        db_user=DB_USER,
        db_password=DB_PASSWORD,
        db_port=DB_PORT
    )

    ingestor.run_full_sync(project_keys=PROJECT_KEYS)


if __name__ == '__main__':
    main()
