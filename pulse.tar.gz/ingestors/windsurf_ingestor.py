"""
Windsurf Analytics Incremental Ingestor

This script pulls data from Windsurf Analytics APIs incrementally:
- UserPageAnalytics: User activity and profile data
- CascadeAnalytics: Cascade lines, runs, and tool usage
- CustomAnalytics: Autocomplete, chat, command, and code written metrics

The script tracks the last sync timestamp and only fetches new data.
"""

import os
import sys
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Any
import logging

import requests
import psycopg2
from psycopg2.extras import execute_values
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class WindsurfIngestor:
    """Incremental data ingestor for Windsurf Analytics APIs"""

    BASE_URL = "https://server.codeium.com/api/v1"

    def __init__(
        self,
        service_key: str,
        db_host: str,
        db_name: str,
        db_user: str,
        db_password: str,
        db_port: int = 5432
    ):
        self.service_key = service_key
        self.db_config = {
            'host': db_host,
            'database': db_name,
            'user': db_user,
            'password': db_password,
            'port': db_port
        }
        self.conn = None

    def connect_db(self):
        """Establish database connection"""
        try:
            self.conn = psycopg2.connect(**self.db_config)
            logger.info("Database connection established")
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            raise

    def close_db(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()
            logger.info("Database connection closed")

    def get_last_sync_timestamp(self, api_endpoint: str) -> Optional[datetime]:
        """Retrieve the last successful sync timestamp for an API endpoint"""
        with self.conn.cursor() as cursor:
            cursor.execute(
                """
                SELECT last_sync_timestamp
                FROM windsurf_sync_metadata
                WHERE api_endpoint = %s AND last_sync_status = 'success'
                """,
                (api_endpoint,)
            )
            result = cursor.fetchone()
            return result[0] if result else None

    def update_sync_metadata(
        self,
        api_endpoint: str,
        timestamp: datetime,
        status: str = 'success',
        records_synced: int = 0,
        error_message: Optional[str] = None
    ):
        """Update sync metadata after API call"""
        with self.conn.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO windsurf_sync_metadata
                (api_endpoint, last_sync_timestamp, last_sync_status, records_synced, error_message, updated_at)
                VALUES (%s, %s, %s, %s, %s, NOW())
                ON CONFLICT (api_endpoint)
                DO UPDATE SET
                    last_sync_timestamp = EXCLUDED.last_sync_timestamp,
                    last_sync_status = EXCLUDED.last_sync_status,
                    records_synced = EXCLUDED.records_synced,
                    error_message = EXCLUDED.error_message,
                    updated_at = NOW()
                """,
                (api_endpoint, timestamp, status, records_synced, error_message)
            )
            self.conn.commit()

    def _make_api_request(self, endpoint: str, payload: Dict) -> Dict:
        """Make POST request to Windsurf API"""
        url = f"{self.BASE_URL}/{endpoint}"
        payload['service_key'] = self.service_key

        try:
            response = requests.post(url, json=payload, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed for {endpoint}: {e}")
            raise

    def ingest_user_data(self, emails: Optional[List[str]] = None):
        """
        Ingest user profile and activity data from UserPageAnalytics API

        Args:
            emails: Optional list of specific user emails to fetch
        """
        logger.info("Starting UserPageAnalytics ingestion...")

        # Get last sync time (look back 7 days for updates)
        last_sync = self.get_last_sync_timestamp('UserPageAnalytics')
        start_time = last_sync if last_sync else datetime.now(timezone.utc) - timedelta(days=365)
        end_time = datetime.now(timezone.utc)

        payload = {
            'start_timestamp': start_time.isoformat(),
            'end_timestamp': end_time.isoformat()
        }

        if emails:
            payload['emails'] = emails

        try:
            response = self._make_api_request('UserPageAnalytics', payload)
            user_stats = response.get('userTableStats', [])

            if not user_stats:
                logger.info("No user data to sync")
                return

            # Upsert users
            with self.conn.cursor() as cursor:
                upsert_query = """
                    INSERT INTO windsurf_users
                    (email, name, api_key_hash, active_days, disable_codeium,
                     last_update_time, last_autocomplete_usage_time,
                     last_chat_usage_time, last_command_usage_time, synced_at)
                    VALUES %s
                    ON CONFLICT (email)
                    DO UPDATE SET
                        name = EXCLUDED.name,
                        api_key_hash = EXCLUDED.api_key_hash,
                        active_days = EXCLUDED.active_days,
                        disable_codeium = EXCLUDED.disable_codeium,
                        last_update_time = EXCLUDED.last_update_time,
                        last_autocomplete_usage_time = EXCLUDED.last_autocomplete_usage_time,
                        last_chat_usage_time = EXCLUDED.last_chat_usage_time,
                        last_command_usage_time = EXCLUDED.last_command_usage_time,
                        synced_at = EXCLUDED.synced_at
                """

                values = [
                    (
                        user.get('email'),
                        user.get('name'),
                        user.get('apiKey'),
                        user.get('activeDays', 0),
                        user.get('disableCodeium', False),
                        self._parse_timestamp(user.get('lastUpdateTime')),
                        self._parse_timestamp(user.get('lastAutocompleteUsageTime')),
                        self._parse_timestamp(user.get('lastChatUsageTime')),
                        self._parse_timestamp(user.get('lastCommandUsageTime')),
                        datetime.now(timezone.utc)
                    )
                    for user in user_stats
                ]

                execute_values(cursor, upsert_query, values)
                self.conn.commit()

            logger.info(f"Synced {len(user_stats)} users")
            self.update_sync_metadata('UserPageAnalytics', end_time, records_synced=len(user_stats))

        except Exception as e:
            logger.error(f"Failed to ingest user data: {e}")
            self.update_sync_metadata('UserPageAnalytics', end_time, status='failed', error_message=str(e))
            raise

    def ingest_cascade_data(self, emails: Optional[List[str]] = None, lookback_days: int = 7):
        """
        Ingest cascade analytics data (lines, runs, tools)

        Args:
            emails: Optional list of specific user emails to fetch
            lookback_days: Number of days to look back for incremental sync
        """
        logger.info("Starting CascadeAnalytics ingestion...")

        # Get time range for incremental sync
        last_sync = self.get_last_sync_timestamp('CascadeAnalytics')
        start_time = last_sync if last_sync else datetime.now(timezone.utc) - timedelta(days=365)
        # Overlap by lookback_days to catch late-arriving data
        start_time = start_time - timedelta(days=lookback_days)
        end_time = datetime.now(timezone.utc)

        payload = {
            'start_timestamp': start_time.isoformat(),
            'end_timestamp': end_time.isoformat(),
            'query_requests': [
                {'data_source': 'cascade_lines'},
                {'data_source': 'cascade_runs'},
                {'data_source': 'cascade_tool_usage'}
            ]
        }

        if emails:
            payload['emails'] = emails

        try:
            response = self._make_api_request('CascadeAnalytics', payload)
            query_results = response.get('queryResults', [])

            total_records = 0

            # Process cascade_lines
            if len(query_results) > 0:
                lines_data = query_results[0].get('cascadeLines', [])
                self._upsert_cascade_lines(lines_data, emails)
                total_records += len(lines_data)
                logger.info(f"Synced {len(lines_data)} cascade lines records")

            # Process cascade_runs
            if len(query_results) > 1:
                runs_data = query_results[1].get('cascadeRuns', [])
                self._upsert_cascade_runs(runs_data, emails)
                total_records += len(runs_data)
                logger.info(f"Synced {len(runs_data)} cascade runs records")

            # Process cascade_tool_usage
            if len(query_results) > 2:
                tools_data = query_results[2].get('cascadeToolUsage', [])
                self._upsert_cascade_tools(tools_data, emails)
                total_records += len(tools_data)
                logger.info(f"Synced {len(tools_data)} cascade tools records")

            self.update_sync_metadata('CascadeAnalytics', end_time, records_synced=total_records)

        except Exception as e:
            logger.error(f"Failed to ingest cascade data: {e}")
            self.update_sync_metadata('CascadeAnalytics', end_time, status='failed', error_message=str(e))
            raise

    def _upsert_cascade_lines(self, data: List[Dict], emails: Optional[List[str]]):
        """Upsert cascade lines data"""
        if not data:
            return

        with self.conn.cursor() as cursor:
            upsert_query = """
                INSERT INTO windsurf_cascade_lines
                (day, email, lines_suggested, lines_accepted, synced_at)
                VALUES %s
                ON CONFLICT (day, email)
                DO UPDATE SET
                    lines_suggested = EXCLUDED.lines_suggested,
                    lines_accepted = EXCLUDED.lines_accepted,
                    synced_at = EXCLUDED.synced_at
            """

            values = [
                (
                    self._parse_date(item.get('day')),
                    emails[0] if emails and len(emails) == 1 else None,  # Single user context
                    item.get('linesSuggested', 0),
                    item.get('linesAccepted', 0),
                    datetime.now(timezone.utc)
                )
                for item in data
            ]

            execute_values(cursor, upsert_query, values)
            self.conn.commit()

    def _upsert_cascade_runs(self, data: List[Dict], emails: Optional[List[str]]):
        """Upsert cascade runs data"""
        if not data:
            return

        with self.conn.cursor() as cursor:
            upsert_query = """
                INSERT INTO windsurf_cascade_runs
                (cascade_id, day, email, model, mode, messages_sent, prompts_used, synced_at)
                VALUES %s
                ON CONFLICT (cascade_id)
                DO UPDATE SET
                    day = EXCLUDED.day,
                    email = EXCLUDED.email,
                    model = EXCLUDED.model,
                    mode = EXCLUDED.mode,
                    messages_sent = EXCLUDED.messages_sent,
                    prompts_used = EXCLUDED.prompts_used,
                    synced_at = EXCLUDED.synced_at
            """

            values = [
                (
                    item.get('cascadeId'),
                    self._parse_date(item.get('day')),
                    emails[0] if emails and len(emails) == 1 else None,
                    item.get('model'),
                    item.get('mode'),
                    item.get('messagesSent', 0),
                    item.get('promptsUsed', 0),
                    datetime.now(timezone.utc)
                )
                for item in data
            ]

            execute_values(cursor, upsert_query, values)
            self.conn.commit()

    def _upsert_cascade_tools(self, data: List[Dict], emails: Optional[List[str]]):
        """Upsert cascade tool usage data"""
        if not data:
            return

        with self.conn.cursor() as cursor:
            # For tool usage, we need to derive day from context
            # Assuming current date for aggregated tool counts
            current_day = datetime.now(timezone.utc).date()

            upsert_query = """
                INSERT INTO windsurf_cascade_tools
                (day, email, tool, count, synced_at)
                VALUES %s
                ON CONFLICT (day, email, tool)
                DO UPDATE SET
                    count = windsurf_cascade_tools.count + EXCLUDED.count,
                    synced_at = EXCLUDED.synced_at
            """

            values = [
                (
                    current_day,
                    emails[0] if emails and len(emails) == 1 else None,
                    item.get('tool'),
                    item.get('count', 0),
                    datetime.now(timezone.utc)
                )
                for item in data
            ]

            execute_values(cursor, upsert_query, values)
            self.conn.commit()

    def ingest_custom_analytics(
        self,
        data_source: str,
        emails: Optional[List[str]] = None,
        lookback_days: int = 7
    ):
        """
        Ingest custom analytics data (USER_DATA, CHAT_DATA, COMMAND_DATA, PCW_DATA)

        Args:
            data_source: One of USER_DATA, CHAT_DATA, COMMAND_DATA, PCW_DATA
            emails: Optional list of specific user emails to fetch
            lookback_days: Number of days to look back for incremental sync
        """
        logger.info(f"Starting CustomAnalytics ingestion for {data_source}...")

        # Get time range
        endpoint_key = f'CustomAnalytics_{data_source}'
        last_sync = self.get_last_sync_timestamp(endpoint_key)
        start_time = last_sync if last_sync else datetime.now(timezone.utc) - timedelta(days=365)
        start_time = start_time - timedelta(days=lookback_days)
        end_time = datetime.now(timezone.utc)

        # Build query based on data source
        query = self._build_custom_analytics_query(data_source)

        payload = {
            'start_timestamp': start_time.isoformat(),
            'end_timestamp': end_time.isoformat(),
            'data_source': data_source,
            'query': query
        }

        if emails:
            payload['emails'] = emails

        try:
            response = self._make_api_request('Analytics', payload)
            results = response.get('queryResults', [])

            if not results or not results[0].get('responseItems'):
                logger.info(f"No {data_source} data to sync")
                return

            items = results[0].get('responseItems', [])

            # Route to appropriate upsert method
            if data_source == 'USER_DATA':
                self._upsert_autocomplete_data(items)
            elif data_source == 'CHAT_DATA':
                self._upsert_chat_data(items)
            elif data_source == 'COMMAND_DATA':
                self._upsert_command_data(items)
            elif data_source == 'PCW_DATA':
                self._upsert_code_written_data(items)

            logger.info(f"Synced {len(items)} {data_source} records")
            self.update_sync_metadata(endpoint_key, end_time, records_synced=len(items))

        except Exception as e:
            logger.error(f"Failed to ingest {data_source}: {e}")
            self.update_sync_metadata(endpoint_key, end_time, status='failed', error_message=str(e))
            raise

    def _build_custom_analytics_query(self, data_source: str) -> Dict:
        """Build query structure for CustomAnalytics API"""
        queries = {
            'USER_DATA': {
                'selections': [
                    {'field': 'api_key'},
                    {'field': 'date'},
                    {'field': 'language'},
                    {'field': 'ide'},
                    {'field': 'num_acceptances', 'aggregation': 'SUM'},
                    {'field': 'num_lines_accepted', 'aggregation': 'SUM'}
                ],
                'group_by': ['api_key', 'date', 'language', 'ide']
            },
            'CHAT_DATA': {
                'selections': [
                    {'field': 'api_key'},
                    {'field': 'date'},
                    {'field': 'model_id'},
                    {'field': 'latest_intent_type'},
                    {'field': 'num_chats_received', 'aggregation': 'SUM'},
                    {'field': 'chat_accepted', 'aggregation': 'SUM'},
                    {'field': 'chat_inserted_at_cursor', 'aggregation': 'SUM'}
                ],
                'group_by': ['api_key', 'date', 'model_id', 'latest_intent_type']
            },
            'COMMAND_DATA': {
                'selections': [
                    {'field': 'api_key'},
                    {'field': 'date'},
                    {'field': 'language'},
                    {'field': 'ide'},
                    {'field': 'command_source'},
                    {'field': 'provider_source'},
                    {'field': 'lines_added', 'aggregation': 'SUM'},
                    {'field': 'lines_removed', 'aggregation': 'SUM'},
                    {'field': 'accepted'}
                ],
                'group_by': ['api_key', 'date', 'language', 'ide', 'command_source', 'provider_source', 'accepted']
            },
            'PCW_DATA': {
                'selections': [
                    {'field': 'api_key'},
                    {'field': 'date'},
                    {'field': 'percent_code_written', 'aggregation': 'AVG'},
                    {'field': 'codeium_bytes', 'aggregation': 'SUM'},
                    {'field': 'user_bytes', 'aggregation': 'SUM'},
                    {'field': 'codeium_bytes_by_autocomplete', 'aggregation': 'SUM'},
                    {'field': 'codeium_bytes_by_command', 'aggregation': 'SUM'}
                ],
                'group_by': ['api_key', 'date']
            }
        }

        return queries.get(data_source, {})

    def _upsert_autocomplete_data(self, items: List[Dict]):
        """Upsert autocomplete (USER_DATA) records"""
        if not items:
            return

        with self.conn.cursor() as cursor:
            upsert_query = """
                INSERT INTO windsurf_autocomplete
                (date, email, language, ide, num_acceptances, num_lines_accepted, synced_at)
                VALUES %s
                ON CONFLICT (date, email, language, ide)
                DO UPDATE SET
                    num_acceptances = EXCLUDED.num_acceptances,
                    num_lines_accepted = EXCLUDED.num_lines_accepted,
                    synced_at = EXCLUDED.synced_at
            """

            values = [
                (
                    self._parse_date(item['item'].get('date')),
                    self._api_key_to_email(item['item'].get('api_key')),
                    item['item'].get('language'),
                    item['item'].get('ide'),
                    item['item'].get('num_acceptances', 0),
                    item['item'].get('num_lines_accepted', 0),
                    datetime.now(timezone.utc)
                )
                for item in items
            ]

            execute_values(cursor, upsert_query, values)
            self.conn.commit()

    def _upsert_chat_data(self, items: List[Dict]):
        """Upsert chat data records"""
        if not items:
            return

        with self.conn.cursor() as cursor:
            upsert_query = """
                INSERT INTO windsurf_chat
                (date, email, model_id, latest_intent_type, num_chats_received,
                 chat_accepted, chat_inserted_at_cursor, synced_at)
                VALUES %s
                ON CONFLICT (date, email, model_id, latest_intent_type)
                DO UPDATE SET
                    num_chats_received = EXCLUDED.num_chats_received,
                    chat_accepted = EXCLUDED.chat_accepted,
                    chat_inserted_at_cursor = EXCLUDED.chat_inserted_at_cursor,
                    synced_at = EXCLUDED.synced_at
            """

            values = [
                (
                    self._parse_date(item['item'].get('date')),
                    self._api_key_to_email(item['item'].get('api_key')),
                    item['item'].get('model_id'),
                    item['item'].get('latest_intent_type'),
                    item['item'].get('num_chats_received', 0),
                    item['item'].get('chat_accepted', 0),
                    item['item'].get('chat_inserted_at_cursor', 0),
                    datetime.now(timezone.utc)
                )
                for item in items
            ]

            execute_values(cursor, upsert_query, values)
            self.conn.commit()

    def _upsert_command_data(self, items: List[Dict]):
        """Upsert command data records"""
        if not items:
            return

        with self.conn.cursor() as cursor:
            upsert_query = """
                INSERT INTO windsurf_commands
                (date, email, language, ide, command_source, provider_source,
                 lines_added, lines_removed, accepted, synced_at)
                VALUES %s
                ON CONFLICT (date, email, language, ide, command_source, provider_source, accepted)
                DO UPDATE SET
                    lines_added = EXCLUDED.lines_added,
                    lines_removed = EXCLUDED.lines_removed,
                    synced_at = EXCLUDED.synced_at
            """

            values = [
                (
                    self._parse_date(item['item'].get('date')),
                    self._api_key_to_email(item['item'].get('api_key')),
                    item['item'].get('language'),
                    item['item'].get('ide'),
                    item['item'].get('command_source'),
                    item['item'].get('provider_source'),
                    item['item'].get('lines_added', 0),
                    item['item'].get('lines_removed', 0),
                    item['item'].get('accepted'),
                    datetime.now(timezone.utc)
                )
                for item in items
            ]

            execute_values(cursor, upsert_query, values)
            self.conn.commit()

    def _upsert_code_written_data(self, items: List[Dict]):
        """Upsert percent code written records"""
        if not items:
            return

        with self.conn.cursor() as cursor:
            upsert_query = """
                INSERT INTO windsurf_code_written
                (date, email, percent_code_written, codeium_bytes, user_bytes,
                 codeium_bytes_by_autocomplete, codeium_bytes_by_command, synced_at)
                VALUES %s
                ON CONFLICT (date, email)
                DO UPDATE SET
                    percent_code_written = EXCLUDED.percent_code_written,
                    codeium_bytes = EXCLUDED.codeium_bytes,
                    user_bytes = EXCLUDED.user_bytes,
                    codeium_bytes_by_autocomplete = EXCLUDED.codeium_bytes_by_autocomplete,
                    codeium_bytes_by_command = EXCLUDED.codeium_bytes_by_command,
                    synced_at = EXCLUDED.synced_at
            """

            values = [
                (
                    self._parse_date(item['item'].get('date')),
                    self._api_key_to_email(item['item'].get('api_key')),
                    item['item'].get('percent_code_written'),
                    item['item'].get('codeium_bytes', 0),
                    item['item'].get('user_bytes', 0),
                    item['item'].get('codeium_bytes_by_autocomplete', 0),
                    item['item'].get('codeium_bytes_by_command', 0),
                    datetime.now(timezone.utc)
                )
                for item in items
            ]

            execute_values(cursor, upsert_query, values)
            self.conn.commit()

    def _api_key_to_email(self, api_key: str) -> Optional[str]:
        """Map API key hash to email from users table"""
        if not api_key:
            return None

        with self.conn.cursor() as cursor:
            cursor.execute(
                "SELECT email FROM windsurf_users WHERE api_key_hash = %s",
                (api_key,)
            )
            result = cursor.fetchone()
            return result[0] if result else None

    @staticmethod
    def _parse_timestamp(ts_str: Optional[str]) -> Optional[datetime]:
        """Parse RFC 3339 timestamp string to datetime"""
        if not ts_str:
            return None
        try:
            # Handle various timestamp formats
            if 'Z' in ts_str:
                return datetime.fromisoformat(ts_str.replace('Z', '+00:00'))
            return datetime.fromisoformat(ts_str)
        except (ValueError, AttributeError):
            return None

    @staticmethod
    def _parse_date(date_str: Optional[str]) -> Optional[str]:
        """Parse date string to date"""
        if not date_str:
            return None
        try:
            # Extract date portion from timestamp or return as-is
            return date_str.split('T')[0] if 'T' in date_str else date_str
        except (ValueError, AttributeError):
            return None

    def run_full_sync(self, emails: Optional[List[str]] = None):
        """
        Run complete sync of all Windsurf data sources

        Args:
            emails: Optional list of specific user emails to fetch
        """
        logger.info("="*50)
        logger.info("Starting full Windsurf data sync")
        logger.info("="*50)

        try:
            self.connect_db()

            # Sync user data first (needed for API key mapping)
            self.ingest_user_data(emails)

            # Sync cascade analytics
            self.ingest_cascade_data(emails)

            # Sync custom analytics
            for data_source in ['USER_DATA', 'CHAT_DATA', 'COMMAND_DATA', 'PCW_DATA']:
                self.ingest_custom_analytics(data_source, emails)

            logger.info("="*50)
            logger.info("Full sync completed successfully")
            logger.info("="*50)

        except Exception as e:
            logger.error(f"Full sync failed: {e}")
            raise
        finally:
            self.close_db()


def main():
    """Main entry point for the ingestor"""

    # Load configuration from environment
    SERVICE_KEY = os.getenv('WINDSURF_SERVICE_KEY')
    DB_HOST = os.getenv('DB_HOST', 'localhost')
    DB_NAME = os.getenv('DB_NAME', 'pulse')
    DB_USER = os.getenv('DB_USER', 'postgres')
    DB_PASSWORD = os.getenv('DB_PASSWORD')
    DB_PORT = int(os.getenv('DB_PORT', 5432))

    # Optional: Filter by specific emails
    EMAILS = os.getenv('WINDSURF_EMAILS', '').split(',') if os.getenv('WINDSURF_EMAILS') else None

    if not SERVICE_KEY:
        logger.error("WINDSURF_SERVICE_KEY not found in environment")
        sys.exit(1)

    if not DB_PASSWORD:
        logger.error("DB_PASSWORD not found in environment")
        sys.exit(1)

    # Create ingestor and run
    ingestor = WindsurfIngestor(
        service_key=SERVICE_KEY,
        db_host=DB_HOST,
        db_name=DB_NAME,
        db_user=DB_USER,
        db_password=DB_PASSWORD,
        db_port=DB_PORT
    )

    ingestor.run_full_sync(emails=EMAILS)


if __name__ == '__main__':
    main()
