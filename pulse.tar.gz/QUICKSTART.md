# Windsurf Ingestor - Quick Start Guide

Get your Windsurf analytics data flowing into PostgreSQL in 5 steps.

## Prerequisites

- Python 3.8+
- PostgreSQL 12+
- Windsurf admin account with "Teams Read-only" permissions

## Step 1: Install Dependencies

```bash
cd /Users/rahulnatarajan/Documents/pulse_final
pip install -r requirements.txt
```

## Step 2: Setup PostgreSQL

Create the database and schema:

```bash
# Create database
createdb pulse

# Or if using psql:
psql -U postgres -c "CREATE DATABASE pulse;"

# Load schema
psql -d pulse -f schema/windsurf_schema.sql
```

## Step 3: Get Windsurf Service Key

1. Go to [Windsurf Team Settings](https://windsurf.com/team/team_settings)
2. Click "Create Service Key" (must be admin user)
3. Ensure you have "Teams Read-only" permissions
4. Copy the service key
5. Enable individual-level analytics at [Manage Team](https://windsurf.com/team/manage)

## Step 4: Configure Environment

```bash
# Copy example config
cp .env.example .env

# Edit .env
nano .env
```

Add your credentials:

```bash
WINDSURF_SERVICE_KEY=your_actual_service_key_here
DB_PASSWORD=your_postgres_password
```

Optional - filter specific users:
```bash
WINDSURF_EMAILS=user1@company.com,user2@company.com
```

## Step 5: Validate Setup

Run the test script to catch issues before ingesting:

```bash
python tests/test_windsurf_setup.py
```

You should see:
```
✅ All tests passed! You're ready to run the ingestor.
```

## Step 6: Run First Sync

```bash
python ingestors/windsurf_ingestor.py
```

**First run** will fetch all historical data (up to 1 year).

**Subsequent runs** will only fetch new data since last sync.

## Verify Data

```bash
psql -d pulse
```

```sql
-- Check users synced
SELECT COUNT(*) FROM windsurf_users;

-- Check recent cascade activity
SELECT * FROM windsurf_cascade_lines ORDER BY day DESC LIMIT 10;

-- Check sync status
SELECT * FROM windsurf_sync_metadata;
```

## Scheduling (Optional)

### Option A: Cron

```bash
# Run every hour
crontab -e

# Add:
0 * * * * cd /Users/rahulnatarajan/Documents/pulse_final && /usr/local/bin/python3 ingestors/windsurf_ingestor.py >> logs/windsurf.log 2>&1
```

### Option B: APScheduler (Future)

Coming soon - automated scheduler in Python.

## Troubleshooting

### "WINDSURF_SERVICE_KEY not found"
- Check `.env` file exists in project root
- Verify variable name matches exactly

### "Failed to connect to database"
- Check PostgreSQL is running: `pg_isready`
- Verify credentials in `.env`
- Try: `psql -U postgres -d pulse` manually

### "No data returned from API"
- Verify service key permissions
- Enable individual-level analytics at https://windsurf.com/team/manage
- Check API key hasn't expired

### "Table does not exist"
- Run schema: `psql -d pulse -f schema/windsurf_schema.sql`

## What Data Gets Synced?

| API Endpoint | Data | Table |
|--------------|------|-------|
| UserPageAnalytics | User profiles, activity | `windsurf_users` |
| CascadeAnalytics | Cascade lines | `windsurf_cascade_lines` |
| CascadeAnalytics | Cascade runs | `windsurf_cascade_runs` |
| CascadeAnalytics | Tool usage | `windsurf_cascade_tools` |
| CustomAnalytics | Autocomplete | `windsurf_autocomplete` |
| CustomAnalytics | Chat | `windsurf_chat` |
| CustomAnalytics | Commands | `windsurf_commands` |
| CustomAnalytics | Code written | `windsurf_code_written` |

## Next Steps

1. ✅ You now have Windsurf data in PostgreSQL
2. Build similar ingestors for JIRA, GitHub, Freshdesk
3. Implement Vanna for text-to-SQL queries
4. Add Qdrant for similarity search
5. Build Chainlit UI

See [README_WINDSURF.md](README_WINDSURF.md) for detailed documentation.

## Support

- Check logs for detailed error messages
- Run test script: `python tests/test_windsurf_setup.py`
- Review [README_WINDSURF.md](README_WINDSURF.md)
