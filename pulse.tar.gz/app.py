"""
Pulse - Operational Metrics Chatbot

Chainlit-based chat interface for querying operational metrics across:
- Windsurf (AI coding analytics)
- JIRA (project management)
- GitHub (code repositories)
- Freshdesk (customer support)

Features:
- Natural language queries
- Automatic routing to SQL or similarity search
- Interactive visualizations with Plotly
- Query history and examples
"""

import os
import chainlit as cl
from chainlit.input_widget import Select
import pandas as pd
import plotly.graph_objects as go
from query_engine.query_router import QueryRouter

# Initialize query router (will be done once at startup)
router = None


@cl.on_chat_start
async def start():
    """Initialize chat session"""

    # Initialize router on first use
    global router
    if router is None:
        await cl.Message(content="🚀 Initializing Pulse... Please wait...").send()
        try:
            router = QueryRouter()
            await cl.Message(
                content="✅ Pulse is ready! Ask me anything about your operational metrics."
            ).send()
        except Exception as e:
            await cl.Message(
                content=f"❌ Failed to initialize: {e}\n\nPlease check your configuration."
            ).send()
            return

    # Welcome message
    welcome_msg = """
# Welcome to Pulse! 🎯

I can help you analyze operational metrics across your organization.

## What I can do:

### 📊 **Metrics & Analytics** (SQL Queries)
- "How many JIRA tickets are open?"
- "What is the average PR review time?"
- "Who resolved the most issues last week?"
- "Show me code lines written by each developer"

### 🔍 **Similarity Search**
- "Find JIRA tickets similar to JIRA-123"
- "Show me GitHub issues related to authentication"
- "What are similar support tickets?"

## Data Sources:
- **Windsurf**: AI coding analytics
- **JIRA**: Project management tickets
- **GitHub**: Pull requests, issues, commits
- **Freshdesk**: Support tickets

## Tips:
- Use natural language - I'll figure out what you need
- Add `/sql` before your question to force SQL query
- Add `/similar` before your question to force similarity search

---

**What would you like to know?**
    """

    await cl.Message(content=welcome_msg).send()

    # Set up settings
    settings = await cl.ChatSettings(
        [
            Select(
                id="query_type",
                label="Query Type",
                values=["auto", "sql", "similarity"],
                initial_value="auto",
            )
        ]
    ).send()


@cl.on_settings_update
async def setup_settings(settings):
    """Handle settings update"""
    await cl.Message(
        content=f"Settings updated: Query type set to **{settings['query_type']}**"
    ).send()


@cl.on_message
async def main(message: cl.Message):
    """Handle user messages"""

    global router
    if router is None:
        await cl.Message(
            content="❌ Router not initialized. Please restart the chat."
        ).send()
        return

    user_query = message.content.strip()

    # Check for force commands
    force_type = None
    if user_query.startswith('/sql '):
        force_type = 'sql'
        user_query = user_query[5:].strip()
    elif user_query.startswith('/similar '):
        force_type = 'similarity'
        user_query = user_query[9:].strip()

    # Get settings
    settings = cl.user_session.get("chat_settings")
    if settings and settings.get("query_type") != "auto":
        force_type = settings["query_type"]

    # Show processing message
    processing_msg = await cl.Message(content=f"🤔 Processing your question...").send()

    try:
        # Route query
        result = router.ask(user_query, force_type=force_type)

        # Remove processing message
        await processing_msg.remove()

        # Handle error
        if result.get('error'):
            await cl.Message(
                content=f"❌ **Error**: {result['error']}"
            ).send()
            return

        query_type = result['query_type']

        # Build response based on query type
        if query_type == 'sql':
            # SQL query result
            sql = result.get('sql')
            df = result.get('results')
            plotly_fig = result.get('plotly_fig')

            # Show SQL query
            await cl.Message(
                content=f"""
## 🔎 SQL Query

```sql
{sql}
```

**Routing**: {result.get('routing_reasoning', 'N/A')}
                """
            ).send()

            # Show results
            if df is not None and not df.empty:
                # Format DataFrame as markdown table
                table_md = df.to_markdown(index=False)

                await cl.Message(
                    content=f"""
## 📊 Results ({len(df)} rows)

{table_md}
                    """
                ).send()

                # Show visualization if available
                if plotly_fig is not None:
                    await cl.Plotly(
                        name="visualization",
                        figure=plotly_fig
                    ).send()

            else:
                await cl.Message(
                    content="ℹ️ Query executed successfully but returned no results."
                ).send()

        elif query_type == 'similarity':
            # Similarity search result
            similar_items = result.get('results', [])
            collection = result.get('collection')

            await cl.Message(
                content=f"""
## 🔍 Similarity Search

**Collection**: `{collection}`
**Routing**: {result.get('routing_reasoning', 'N/A')}
                """
            ).send()

            if similar_items:
                # Format similar items
                items_text = f"## 📋 Found {len(similar_items)} similar items\n\n"

                for idx, item in enumerate(similar_items, 1):
                    score = item['score']
                    payload = item['payload']

                    # Format based on source
                    source = payload.get('source', 'unknown')

                    if source == 'jira':
                        items_text += f"""
### {idx}. {payload.get('issue_key')} (Score: {score:.3f})
**Type**: {payload.get('issue_type')}
**Status**: {payload.get('status')}
**Priority**: {payload.get('priority')}
**Summary**: {payload.get('summary')}
**Description**: {payload.get('description', 'N/A')[:200]}...

---
                        """
                    elif source in ['github', 'github_pr']:
                        items_text += f"""
### {idx}. {payload.get('title')} (Score: {score:.3f})
**Repo**: {payload.get('repo_name')}
**State**: {payload.get('state')}
**Author**: {payload.get('author')}
**Description**: {payload.get('body', 'N/A')[:200]}...

---
                        """
                    elif source == 'freshdesk':
                        items_text += f"""
### {idx}. Ticket #{payload.get('ticket_id')} (Score: {score:.3f})
**Status**: {payload.get('status')}
**Priority**: {payload.get('priority')}
**Agent**: {payload.get('agent_name', 'Unassigned')}
**Subject**: {payload.get('subject')}
**Description**: {payload.get('description', 'N/A')[:200]}...

---
                        """

                await cl.Message(content=items_text).send()

            else:
                await cl.Message(
                    content="ℹ️ No similar items found."
                ).send()

    except Exception as e:
        await processing_msg.remove()
        await cl.Message(
            content=f"❌ **Error**: {str(e)}"
        ).send()


@cl.on_chat_end
async def end():
    """Handle chat end"""
    await cl.Message(
        content="👋 Thanks for using Pulse! See you next time."
    ).send()


if __name__ == '__main__':
    # Run with: chainlit run app.py -w
    pass
