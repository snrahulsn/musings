"""
Query Router

This module routes user queries to either:
1. Text-to-SQL (Vanna) for metrics/analytics queries (60-70% use cases)
2. Vector similarity search (Qdrant) for finding similar items (30-40% use cases)

Uses Claude to classify query intent and route accordingly.
"""

import os
import logging
from typing import Dict, Any, Optional
from anthropic import Anthropic
from query_engine.vanna_config import VannaSQL
from query_engine.qdrant_config import QdrantSearch

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class QueryRouter:
    """Routes queries to appropriate engine (SQL or similarity search)"""

    def __init__(self):
        """Initialize router with Claude, Vanna, and Qdrant"""

        self.anthropic_api_key = os.getenv('ANTHROPIC_API_KEY')
        if not self.anthropic_api_key:
            raise ValueError("ANTHROPIC_API_KEY must be set")

        # Initialize Claude client
        self.claude = Anthropic(api_key=self.anthropic_api_key)

        # Initialize query engines
        self.vanna = VannaSQL()
        self.qdrant = QdrantSearch()

        logger.info("✅ Query router initialized")

    def classify_query(self, question: str) -> Dict[str, Any]:
        """
        Classify query intent using Claude

        Returns dict with:
        - query_type: 'sql' or 'similarity'
        - reasoning: Why this classification was chosen
        - collection: For similarity queries, which collection to search
        """

        prompt = f"""
You are a query classifier for an operational metrics system with data from JIRA, GitHub, Freshdesk, and Windsurf.

Classify this user question into one of two types:

1. **SQL Query** - For metrics, analytics, aggregations, counts, trends
   Examples:
   - "How many tickets are open?"
   - "What is the average PR review time?"
   - "Who resolved the most issues last week?"
   - "Show me code lines written by each developer"

2. **Similarity Search** - For finding similar items, related content, duplicates
   Examples:
   - "Find tickets similar to JIRA-123"
   - "Show me PRs related to authentication"
   - "What are similar support tickets?"
   - "Find issues like this one: [description]"

For similarity searches, also identify which collection to search:
- jira_issues_vectors: JIRA tickets
- github_issues_vectors: GitHub issues
- github_prs_vectors: GitHub pull requests
- freshdesk_tickets_vectors: Freshdesk support tickets

User question: "{question}"

Respond in this format:
Query Type: [sql or similarity]
Collection: [collection name if similarity, otherwise N/A]
Reasoning: [brief explanation]
"""

        try:
            response = self.claude.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=500,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )

            content = response.content[0].text

            # Parse response
            lines = content.strip().split('\n')
            result = {
                'query_type': None,
                'collection': None,
                'reasoning': None
            }

            for line in lines:
                if line.startswith('Query Type:'):
                    query_type = line.split(':', 1)[1].strip().lower()
                    result['query_type'] = query_type
                elif line.startswith('Collection:'):
                    collection = line.split(':', 1)[1].strip()
                    if collection != 'N/A':
                        result['collection'] = collection
                elif line.startswith('Reasoning:'):
                    result['reasoning'] = line.split(':', 1)[1].strip()

            logger.info(f"Query classified as: {result['query_type']}")
            logger.info(f"Reasoning: {result['reasoning']}")

            return result

        except Exception as e:
            logger.error(f"Query classification failed: {e}")
            # Default to SQL if classification fails
            return {
                'query_type': 'sql',
                'collection': None,
                'reasoning': 'Classification failed, defaulting to SQL'
            }

    def route_query(self, question: str) -> Dict[str, Any]:
        """
        Route query to appropriate engine and return results

        Returns:
        {
            'question': original question,
            'query_type': 'sql' or 'similarity',
            'routing_reasoning': why routed this way,
            'sql': generated SQL (if sql query),
            'results': results (DataFrame or list of similar items),
            'plotly_fig': visualization (if available),
            'error': error message (if any)
        }
        """

        logger.info(f"Routing query: '{question}'")

        try:
            # 1. Classify query
            classification = self.classify_query(question)
            query_type = classification['query_type']

            # 2. Route to appropriate engine
            if query_type == 'sql':
                # Use Vanna for SQL generation and execution
                logger.info("Routing to Vanna (text-to-SQL)...")
                vanna_result = self.vanna.ask(question)

                return {
                    'question': question,
                    'query_type': 'sql',
                    'routing_reasoning': classification['reasoning'],
                    'sql': vanna_result.get('sql'),
                    'results': vanna_result.get('df'),
                    'plotly_fig': vanna_result.get('plotly_fig'),
                    'error': vanna_result.get('error')
                }

            elif query_type == 'similarity':
                # Use Qdrant for similarity search
                logger.info("Routing to Qdrant (similarity search)...")
                collection = classification['collection']

                if not collection:
                    # Try to infer from question
                    if 'jira' in question.lower() or 'ticket' in question.lower():
                        collection = 'jira_issues_vectors'
                    elif 'pr' in question.lower() or 'pull request' in question.lower():
                        collection = 'github_prs_vectors'
                    elif 'github' in question.lower() or 'issue' in question.lower():
                        collection = 'github_issues_vectors'
                    elif 'freshdesk' in question.lower() or 'support' in question.lower():
                        collection = 'freshdesk_tickets_vectors'
                    else:
                        collection = 'jira_issues_vectors'  # Default

                # Search
                similar_items = self.qdrant.search(
                    query=question,
                    collection_name=collection,
                    limit=10
                )

                return {
                    'question': question,
                    'query_type': 'similarity',
                    'routing_reasoning': classification['reasoning'],
                    'collection': collection,
                    'results': similar_items,
                    'sql': None,
                    'plotly_fig': None,
                    'error': None
                }

            else:
                # Unknown query type
                logger.warning(f"Unknown query type: {query_type}, defaulting to SQL")
                vanna_result = self.vanna.ask(question)

                return {
                    'question': question,
                    'query_type': 'sql',
                    'routing_reasoning': 'Unknown query type, defaulted to SQL',
                    'sql': vanna_result.get('sql'),
                    'results': vanna_result.get('df'),
                    'plotly_fig': vanna_result.get('plotly_fig'),
                    'error': vanna_result.get('error')
                }

        except Exception as e:
            logger.error(f"Query routing failed: {e}")
            return {
                'question': question,
                'query_type': 'error',
                'routing_reasoning': None,
                'sql': None,
                'results': None,
                'plotly_fig': None,
                'error': str(e)
            }

    def ask(self, question: str, force_type: Optional[str] = None) -> Dict[str, Any]:
        """
        Ask a question with optional forced query type

        Args:
            question: Natural language question
            force_type: Optional override ('sql' or 'similarity')

        Returns:
            Results dictionary
        """

        if force_type:
            logger.info(f"Forcing query type: {force_type}")

            if force_type == 'sql':
                vanna_result = self.vanna.ask(question)
                return {
                    'question': question,
                    'query_type': 'sql',
                    'routing_reasoning': 'User forced SQL query',
                    'sql': vanna_result.get('sql'),
                    'results': vanna_result.get('df'),
                    'plotly_fig': vanna_result.get('plotly_fig'),
                    'error': vanna_result.get('error')
                }

            elif force_type == 'similarity':
                # Infer collection from question
                collection = 'jira_issues_vectors'
                if 'github' in question.lower():
                    collection = 'github_issues_vectors'
                elif 'pr' in question.lower():
                    collection = 'github_prs_vectors'
                elif 'freshdesk' in question.lower():
                    collection = 'freshdesk_tickets_vectors'

                similar_items = self.qdrant.search(question, collection, limit=10)

                return {
                    'question': question,
                    'query_type': 'similarity',
                    'routing_reasoning': 'User forced similarity search',
                    'collection': collection,
                    'results': similar_items,
                    'sql': None,
                    'plotly_fig': None,
                    'error': None
                }

        # Normal routing
        return self.route_query(question)


if __name__ == '__main__':
    # Test query router
    router = QueryRouter()

    # Test SQL query
    print("\n" + "=" * 80)
    print("TEST 1: SQL Query")
    print("=" * 80)
    result1 = router.ask("How many JIRA tickets are open?")
    print(f"Query Type: {result1['query_type']}")
    print(f"SQL: {result1.get('sql')}")
    print(f"Results:\n{result1.get('results')}")

    # Test similarity search
    print("\n" + "=" * 80)
    print("TEST 2: Similarity Search")
    print("=" * 80)
    result2 = router.ask("Find JIRA tickets similar to authentication issues")
    print(f"Query Type: {result2['query_type']}")
    print(f"Collection: {result2.get('collection')}")
    print(f"Results: {len(result2.get('results', []))} similar items found")
    if result2.get('results'):
        for item in result2['results'][:3]:
            print(f"  - Score: {item['score']:.3f} - {item['payload'].get('summary', item['payload'].get('title'))}")

    # Test with forced type
    print("\n" + "=" * 80)
    print("TEST 3: Forced SQL Query")
    print("=" * 80)
    result3 = router.ask("authentication", force_type='sql')
    print(f"Query Type: {result3['query_type']}")
    print(f"Forced: Yes")
