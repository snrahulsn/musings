"""
Qdrant Vector Database Configuration

This module sets up Qdrant for similarity search over operational data.
Uses Ollama embeddings (nomic-embed-text) and stores vectors in Qdrant.

Use cases:
- Find similar JIRA tickets
- Find similar GitHub issues
- Find similar support tickets
- Find similar code changes
- Semantic search over comments and descriptions
"""

import os
import logging
from typing import List, Dict, Any, Optional
import psycopg2
from qdrant_client import QdrantClient
from qdrant_client.models import (
    Distance,
    VectorParams,
    PointStruct,
    Filter,
    FieldCondition,
    MatchValue
)
import ollama

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class QdrantSearch:
    """Qdrant vector search engine with Ollama embeddings"""

    def __init__(self):
        """Initialize Qdrant client and Ollama embeddings"""

        # Qdrant configuration
        self.qdrant_host = os.getenv('QDRANT_HOST', 'localhost')
        self.qdrant_port = int(os.getenv('QDRANT_PORT', '6333'))

        # Ollama configuration
        self.ollama_host = os.getenv('OLLAMA_HOST', 'http://localhost:11434')
        self.embedding_model = os.getenv('EMBEDDING_MODEL', 'nomic-embed-text')

        # Database configuration (for fetching data to embed)
        self.db_config = {
            'host': os.getenv('DB_HOST', 'localhost'),
            'port': os.getenv('DB_PORT', '5432'),
            'database': os.getenv('DB_NAME', 'pulse'),
            'user': os.getenv('DB_USER', 'pulse_user'),
            'password': os.getenv('DB_PASSWORD', 'pulse_password')
        }

        # Initialize Qdrant client
        self.client = QdrantClient(host=self.qdrant_host, port=self.qdrant_port)

        # Initialize Ollama client
        self.ollama_client = ollama.Client(host=self.ollama_host)

        # Collection names
        self.collections = {
            'jira_issues': 'jira_issues_vectors',
            'github_issues': 'github_issues_vectors',
            'github_prs': 'github_prs_vectors',
            'freshdesk_tickets': 'freshdesk_tickets_vectors'
        }

        logger.info(f"✅ Qdrant initialized at {self.qdrant_host}:{self.qdrant_port}")
        logger.info(f"✅ Using Ollama embeddings: {self.embedding_model}")

    def get_embedding(self, text: str) -> List[float]:
        """
        Generate embedding for text using Ollama

        Args:
            text: Text to embed

        Returns:
            Embedding vector
        """
        try:
            response = self.ollama_client.embeddings(
                model=self.embedding_model,
                prompt=text
            )
            return response['embedding']
        except Exception as e:
            logger.error(f"Failed to generate embedding: {e}")
            raise

    def create_collection(self, collection_name: str, vector_size: int = 768):
        """
        Create a Qdrant collection if it doesn't exist

        Args:
            collection_name: Name of the collection
            vector_size: Size of embedding vectors (nomic-embed-text = 768)
        """
        try:
            # Check if collection exists
            collections = self.client.get_collections().collections
            if collection_name in [c.name for c in collections]:
                logger.info(f"Collection '{collection_name}' already exists")
                return

            # Create collection
            self.client.create_collection(
                collection_name=collection_name,
                vectors_config=VectorParams(
                    size=vector_size,
                    distance=Distance.COSINE
                )
            )
            logger.info(f"✅ Created collection: {collection_name}")

        except Exception as e:
            logger.error(f"Failed to create collection: {e}")
            raise

    def create_all_collections(self):
        """Create all collections for different data sources"""
        for collection in self.collections.values():
            self.create_collection(collection)

    def index_jira_issues(self, limit: Optional[int] = None):
        """
        Index JIRA issues into Qdrant

        Args:
            limit: Optional limit on number of issues to index
        """
        logger.info("Indexing JIRA issues...")

        conn = psycopg2.connect(**self.db_config)
        cursor = conn.cursor()

        # Fetch JIRA issues
        query = """
            SELECT
                i.issue_key,
                i.summary,
                i.description,
                i.issue_type,
                i.status,
                i.priority,
                u.display_name as assignee,
                ARRAY_TO_STRING(i.labels, ', ') as labels
            FROM jira_issues i
            LEFT JOIN jira_users u ON i.assignee_account_id = u.account_id
            WHERE i.description IS NOT NULL
        """
        if limit:
            query += f" LIMIT {limit}"

        cursor.execute(query)
        issues = cursor.fetchall()

        logger.info(f"Found {len(issues)} JIRA issues to index")

        # Generate embeddings and upload to Qdrant
        points = []
        for idx, issue in enumerate(issues):
            issue_key, summary, description, issue_type, status, priority, assignee, labels = issue

            # Combine fields for embedding
            text_to_embed = f"""
            Type: {issue_type}
            Priority: {priority}
            Status: {status}
            Assignee: {assignee or 'Unassigned'}
            Labels: {labels or 'None'}
            Summary: {summary}
            Description: {description}
            """.strip()

            # Generate embedding
            embedding = self.get_embedding(text_to_embed)

            # Create point
            point = PointStruct(
                id=idx,
                vector=embedding,
                payload={
                    'issue_key': issue_key,
                    'summary': summary,
                    'description': description[:500],  # Truncate for storage
                    'issue_type': issue_type,
                    'status': status,
                    'priority': priority,
                    'assignee': assignee,
                    'labels': labels,
                    'source': 'jira'
                }
            )
            points.append(point)

            if (idx + 1) % 100 == 0:
                logger.info(f"Processed {idx + 1} issues...")

        # Upload to Qdrant
        self.client.upsert(
            collection_name=self.collections['jira_issues'],
            points=points
        )

        logger.info(f"✅ Indexed {len(points)} JIRA issues")

        cursor.close()
        conn.close()

    def index_github_issues(self, limit: Optional[int] = None):
        """Index GitHub issues into Qdrant"""
        logger.info("Indexing GitHub issues...")

        conn = psycopg2.connect(**self.db_config)
        cursor = conn.cursor()

        query = """
            SELECT
                i.issue_id,
                i.title,
                i.body,
                i.state,
                r.name as repo_name,
                u.login as author,
                ARRAY_TO_STRING(i.labels, ', ') as labels
            FROM github_issues i
            JOIN github_repositories r ON i.repo_id = r.repo_id
            LEFT JOIN github_users u ON i.user_id = u.user_id
            WHERE i.body IS NOT NULL
        """
        if limit:
            query += f" LIMIT {limit}"

        cursor.execute(query)
        issues = cursor.fetchall()

        logger.info(f"Found {len(issues)} GitHub issues to index")

        points = []
        for idx, issue in enumerate(issues):
            issue_id, title, body, state, repo_name, author, labels = issue

            text_to_embed = f"""
            Repository: {repo_name}
            State: {state}
            Author: {author or 'Unknown'}
            Labels: {labels or 'None'}
            Title: {title}
            Body: {body}
            """.strip()

            embedding = self.get_embedding(text_to_embed)

            point = PointStruct(
                id=idx,
                vector=embedding,
                payload={
                    'issue_id': issue_id,
                    'title': title,
                    'body': body[:500],
                    'state': state,
                    'repo_name': repo_name,
                    'author': author,
                    'labels': labels,
                    'source': 'github'
                }
            )
            points.append(point)

            if (idx + 1) % 100 == 0:
                logger.info(f"Processed {idx + 1} issues...")

        self.client.upsert(
            collection_name=self.collections['github_issues'],
            points=points
        )

        logger.info(f"✅ Indexed {len(points)} GitHub issues")

        cursor.close()
        conn.close()

    def index_github_prs(self, limit: Optional[int] = None):
        """Index GitHub pull requests into Qdrant"""
        logger.info("Indexing GitHub pull requests...")

        conn = psycopg2.connect(**self.db_config)
        cursor = conn.cursor()

        query = """
            SELECT
                pr.pr_id,
                pr.title,
                pr.body,
                pr.state,
                r.name as repo_name,
                u.login as author
            FROM github_pull_requests pr
            JOIN github_repositories r ON pr.repo_id = r.repo_id
            LEFT JOIN github_users u ON pr.user_id = u.user_id
            WHERE pr.body IS NOT NULL
        """
        if limit:
            query += f" LIMIT {limit}"

        cursor.execute(query)
        prs = cursor.fetchall()

        logger.info(f"Found {len(prs)} GitHub PRs to index")

        points = []
        for idx, pr in enumerate(prs):
            pr_id, title, body, state, repo_name, author = pr

            text_to_embed = f"""
            Repository: {repo_name}
            State: {state}
            Author: {author or 'Unknown'}
            Title: {title}
            Body: {body}
            """.strip()

            embedding = self.get_embedding(text_to_embed)

            point = PointStruct(
                id=idx,
                vector=embedding,
                payload={
                    'pr_id': pr_id,
                    'title': title,
                    'body': body[:500],
                    'state': state,
                    'repo_name': repo_name,
                    'author': author,
                    'source': 'github_pr'
                }
            )
            points.append(point)

            if (idx + 1) % 100 == 0:
                logger.info(f"Processed {idx + 1} PRs...")

        self.client.upsert(
            collection_name=self.collections['github_prs'],
            points=points
        )

        logger.info(f"✅ Indexed {len(points)} GitHub PRs")

        cursor.close()
        conn.close()

    def index_freshdesk_tickets(self, limit: Optional[int] = None):
        """Index Freshdesk tickets into Qdrant"""
        logger.info("Indexing Freshdesk tickets...")

        conn = psycopg2.connect(**self.db_config)
        cursor = conn.cursor()

        query = """
            SELECT
                t.ticket_id,
                t.subject,
                t.description,
                t.status,
                t.priority,
                a.name as agent_name
            FROM freshdesk_tickets t
            LEFT JOIN freshdesk_agents a ON t.responder_id = a.agent_id
            WHERE t.description IS NOT NULL
        """
        if limit:
            query += f" LIMIT {limit}"

        cursor.execute(query)
        tickets = cursor.fetchall()

        logger.info(f"Found {len(tickets)} Freshdesk tickets to index")

        points = []
        for idx, ticket in enumerate(tickets):
            ticket_id, subject, description, status, priority, agent_name = ticket

            text_to_embed = f"""
            Status: {status}
            Priority: {priority}
            Agent: {agent_name or 'Unassigned'}
            Subject: {subject}
            Description: {description}
            """.strip()

            embedding = self.get_embedding(text_to_embed)

            point = PointStruct(
                id=idx,
                vector=embedding,
                payload={
                    'ticket_id': ticket_id,
                    'subject': subject,
                    'description': description[:500],
                    'status': status,
                    'priority': priority,
                    'agent_name': agent_name,
                    'source': 'freshdesk'
                }
            )
            points.append(point)

            if (idx + 1) % 100 == 0:
                logger.info(f"Processed {idx + 1} tickets...")

        self.client.upsert(
            collection_name=self.collections['freshdesk_tickets'],
            points=points
        )

        logger.info(f"✅ Indexed {len(points)} Freshdesk tickets")

        cursor.close()
        conn.close()

    def search(self, query: str, collection_name: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Search for similar items

        Args:
            query: Natural language query
            collection_name: Collection to search in
            limit: Number of results to return

        Returns:
            List of similar items with scores
        """
        logger.info(f"Searching '{collection_name}' for: {query}")

        # Generate query embedding
        query_embedding = self.get_embedding(query)

        # Search Qdrant
        results = self.client.search(
            collection_name=collection_name,
            query_vector=query_embedding,
            limit=limit
        )

        # Format results
        formatted_results = []
        for result in results:
            formatted_results.append({
                'score': result.score,
                'payload': result.payload
            })

        logger.info(f"Found {len(formatted_results)} results")
        return formatted_results

    def search_similar_jira_issue(self, issue_key: str, limit: int = 5) -> List[Dict[str, Any]]:
        """Find similar JIRA issues to a given issue"""
        logger.info(f"Finding similar issues to {issue_key}...")

        # Get the issue text
        conn = psycopg2.connect(**self.db_config)
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT summary, description
            FROM jira_issues
            WHERE issue_key = %s
            """,
            (issue_key,)
        )
        result = cursor.fetchone()
        cursor.close()
        conn.close()

        if not result:
            logger.error(f"Issue {issue_key} not found")
            return []

        summary, description = result
        query_text = f"{summary} {description}"

        return self.search(query_text, self.collections['jira_issues'], limit)


if __name__ == '__main__':
    # Initialize Qdrant
    qdrant = QdrantSearch()

    # Create collections
    qdrant.create_all_collections()

    # Index data (with limits for testing)
    qdrant.index_jira_issues(limit=100)
    qdrant.index_github_issues(limit=100)
    qdrant.index_github_prs(limit=100)
    qdrant.index_freshdesk_tickets(limit=100)

    # Test search
    results = qdrant.search("authentication bug", qdrant.collections['jira_issues'], limit=5)
    print(f"\nTop 5 similar JIRA issues:")
    for result in results:
        print(f"Score: {result['score']:.3f} - {result['payload']['issue_key']}: {result['payload']['summary']}")
