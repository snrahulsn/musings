"""
Vanna Text-to-SQL Configuration

This module sets up Vanna.AI for natural language to SQL translation.
Uses Anthropic Claude for SQL generation and PostgreSQL for data access.

Features:
- Train on schema DDL
- Store training data in PostgreSQL
- Generate SQL from natural language
- Execute queries safely
- Return results with visualizations
"""

import os
import logging
from typing import Optional, List, Dict, Any
import psycopg2
from vanna.anthropic import Anthropic_Chat
from vanna.postgres import Postgres_VectorStore

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class VannaSQL:
    """Vanna text-to-SQL engine with Claude and PostgreSQL"""

    def __init__(self):
        """Initialize Vanna with Anthropic Claude and PostgreSQL vector store"""

        # Get configuration from environment
        self.anthropic_api_key = os.getenv('ANTHROPIC_API_KEY')
        self.model_name = os.getenv('VANNA_MODEL', 'claude-3-5-sonnet-20241022')

        if not self.anthropic_api_key:
            raise ValueError("ANTHROPIC_API_KEY environment variable must be set")

        # Database connection parameters
        self.db_config = {
            'host': os.getenv('DB_HOST', 'localhost'),
            'port': os.getenv('DB_PORT', '5432'),
            'database': os.getenv('DB_NAME', 'pulse'),
            'user': os.getenv('DB_USER', 'pulse_user'),
            'password': os.getenv('DB_PASSWORD', 'pulse_password')
        }

        # Initialize Vanna with custom class combining Anthropic and Postgres
        class MyVanna(Anthropic_Chat, Postgres_VectorStore):
            def __init__(self, config=None):
                Anthropic_Chat.__init__(self, config=config)
                Postgres_VectorStore.__init__(self, config=config)

        # Vanna configuration
        vanna_config = {
            'api_key': self.anthropic_api_key,
            'model': self.model_name,
            'postgres_config': self.db_config
        }

        self.vn = MyVanna(config=vanna_config)

        # Connect to PostgreSQL
        self.vn.connect_to_postgres(
            host=self.db_config['host'],
            dbname=self.db_config['database'],
            user=self.db_config['user'],
            password=self.db_config['password'],
            port=self.db_config['port']
        )

        logger.info(f"✅ Vanna initialized with {self.model_name}")

    def train_on_ddl(self, ddl: str) -> str:
        """
        Train Vanna on DDL (schema definition)

        Args:
            ddl: SQL DDL string (CREATE TABLE statements)

        Returns:
            Training ID
        """
        logger.info("Training Vanna on DDL...")
        training_id = self.vn.train(ddl=ddl)
        logger.info(f"✅ DDL trained with ID: {training_id}")
        return training_id

    def train_on_documentation(self, documentation: str) -> str:
        """
        Train Vanna on documentation

        Args:
            documentation: Documentation string

        Returns:
            Training ID
        """
        logger.info("Training Vanna on documentation...")
        training_id = self.vn.train(documentation=documentation)
        logger.info(f"✅ Documentation trained with ID: {training_id}")
        return training_id

    def train_on_sql(self, question: str, sql: str) -> str:
        """
        Train Vanna on question-SQL pairs

        Args:
            question: Natural language question
            sql: Corresponding SQL query

        Returns:
            Training ID
        """
        logger.info(f"Training Vanna on Q&A: '{question}'")
        training_id = self.vn.train(question=question, sql=sql)
        logger.info(f"✅ Q&A trained with ID: {training_id}")
        return training_id

    def generate_sql(self, question: str) -> Optional[str]:
        """
        Generate SQL from natural language question

        Args:
            question: Natural language question

        Returns:
            Generated SQL query string or None if generation fails
        """
        try:
            logger.info(f"Generating SQL for: '{question}'")
            sql = self.vn.generate_sql(question=question)
            logger.info(f"✅ Generated SQL:\n{sql}")
            return sql
        except Exception as e:
            logger.error(f"❌ SQL generation failed: {e}")
            return None

    def ask(self, question: str, print_results: bool = False) -> Dict[str, Any]:
        """
        Ask a question and get SQL + results + visualization

        Args:
            question: Natural language question
            print_results: Whether to print results to console

        Returns:
            Dictionary with keys: question, sql, df (pandas DataFrame), plotly_fig
        """
        try:
            logger.info(f"Processing question: '{question}'")

            # Generate SQL
            sql = self.generate_sql(question)
            if not sql:
                return {
                    'question': question,
                    'sql': None,
                    'df': None,
                    'error': 'Failed to generate SQL'
                }

            # Execute query and get results
            df = self.vn.run_sql(sql)

            if print_results:
                print(f"\nQuestion: {question}")
                print(f"\nSQL:\n{sql}")
                print(f"\nResults:\n{df}")

            # Generate plotly visualization
            try:
                plotly_fig = self.vn.get_plotly_figure(
                    plotly_code=self.vn.generate_plotly_code(
                        question=question,
                        sql=sql,
                        df=df
                    ),
                    df=df
                )
            except:
                plotly_fig = None

            return {
                'question': question,
                'sql': sql,
                'df': df,
                'plotly_fig': plotly_fig
            }

        except Exception as e:
            logger.error(f"❌ Query execution failed: {e}")
            return {
                'question': question,
                'sql': sql if sql else None,
                'df': None,
                'error': str(e)
            }

    def get_training_data(self) -> List[Dict]:
        """Get all training data stored in Vanna"""
        try:
            training_data = self.vn.get_training_data()
            logger.info(f"Retrieved {len(training_data)} training items")
            return training_data
        except Exception as e:
            logger.error(f"Failed to get training data: {e}")
            return []

    def remove_training_data(self, id: str) -> bool:
        """Remove training data by ID"""
        try:
            self.vn.remove_training_data(id=id)
            logger.info(f"✅ Removed training data: {id}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to remove training data: {e}")
            return False


def train_from_schema_files(vanna: VannaSQL, schema_dir: str = './schema'):
    """
    Train Vanna on all schema files in a directory

    Args:
        vanna: VannaSQL instance
        schema_dir: Directory containing SQL schema files
    """
    import glob

    logger.info(f"Training Vanna from schema files in {schema_dir}...")

    schema_files = glob.glob(f"{schema_dir}/*.sql")

    if not schema_files:
        logger.warning(f"No schema files found in {schema_dir}")
        return

    for schema_file in schema_files:
        logger.info(f"Reading {schema_file}...")
        with open(schema_file, 'r') as f:
            ddl = f.read()

        # Train on DDL
        vanna.train_on_ddl(ddl)

    logger.info(f"✅ Trained on {len(schema_files)} schema files")


def train_common_questions(vanna: VannaSQL):
    """Train Vanna on common operational metrics questions"""

    logger.info("Training Vanna on common questions...")

    common_qa = [
        # Windsurf questions
        (
            "How many lines of code were written by each user in the last 7 days?",
            """
            SELECT
                u.email,
                u.display_name,
                SUM(cw.lines_added) as total_lines
            FROM windsurf_users u
            JOIN windsurf_code_written cw ON u.user_id = cw.user_id
            WHERE cw.date >= CURRENT_DATE - INTERVAL '7 days'
            GROUP BY u.email, u.display_name
            ORDER BY total_lines DESC;
            """
        ),
        (
            "What is the autocomplete acceptance rate by user?",
            """
            SELECT
                u.email,
                u.display_name,
                COUNT(*) as total_suggestions,
                SUM(CASE WHEN a.accepted THEN 1 ELSE 0 END) as accepted,
                ROUND(100.0 * SUM(CASE WHEN a.accepted THEN 1 ELSE 0 END) / COUNT(*), 2) as acceptance_rate
            FROM windsurf_users u
            JOIN windsurf_autocomplete a ON u.user_id = a.user_id
            GROUP BY u.email, u.display_name
            ORDER BY acceptance_rate DESC;
            """
        ),

        # JIRA questions
        (
            "How many tickets are in each status?",
            """
            SELECT
                status,
                COUNT(*) as ticket_count
            FROM jira_issues
            WHERE deleted = false
            GROUP BY status
            ORDER BY ticket_count DESC;
            """
        ),
        (
            "What is the average resolution time by priority?",
            """
            SELECT
                priority,
                COUNT(*) as total_resolved,
                ROUND(AVG(EXTRACT(EPOCH FROM (resolved_at - created_at)) / 3600), 2) as avg_hours_to_resolve
            FROM jira_issues
            WHERE resolved_at IS NOT NULL
            GROUP BY priority
            ORDER BY avg_hours_to_resolve;
            """
        ),
        (
            "Who are the top 10 issue resolvers in the last 30 days?",
            """
            SELECT
                u.display_name,
                u.email,
                COUNT(*) as issues_resolved
            FROM jira_issues i
            JOIN jira_users u ON i.assignee_account_id = u.account_id
            WHERE i.resolved_at >= CURRENT_DATE - INTERVAL '30 days'
            GROUP BY u.display_name, u.email
            ORDER BY issues_resolved DESC
            LIMIT 10;
            """
        ),

        # GitHub questions
        (
            "How many pull requests were merged by each user in the last 30 days?",
            """
            SELECT
                u.login,
                COUNT(*) as merged_prs
            FROM github_pull_requests pr
            JOIN github_users u ON pr.user_id = u.user_id
            WHERE pr.state = 'closed'
              AND pr.merged = true
              AND pr.merged_at >= CURRENT_DATE - INTERVAL '30 days'
            GROUP BY u.login
            ORDER BY merged_prs DESC;
            """
        ),
        (
            "What is the average PR review time by repository?",
            """
            SELECT
                r.name as repository,
                COUNT(DISTINCT pr.pr_id) as total_prs,
                ROUND(AVG(EXTRACT(EPOCH FROM (pr.merged_at - pr.created_at)) / 3600), 2) as avg_hours_to_merge
            FROM github_pull_requests pr
            JOIN github_repositories r ON pr.repo_id = r.repo_id
            WHERE pr.merged = true
              AND pr.merged_at IS NOT NULL
            GROUP BY r.name
            ORDER BY avg_hours_to_merge;
            """
        ),

        # Freshdesk questions
        (
            "How many tickets are in each status?",
            """
            SELECT
                CASE status
                    WHEN 2 THEN 'Open'
                    WHEN 3 THEN 'Pending'
                    WHEN 4 THEN 'Resolved'
                    WHEN 5 THEN 'Closed'
                    ELSE 'Unknown'
                END as status_name,
                COUNT(*) as ticket_count
            FROM freshdesk_tickets
            WHERE deleted = false
            GROUP BY status
            ORDER BY status;
            """
        ),
        (
            "What is the first response time by agent?",
            """
            SELECT
                a.name as agent_name,
                COUNT(*) as tickets_responded,
                ROUND(AVG(EXTRACT(EPOCH FROM (t.first_responded_at - t.created_at)) / 3600), 2) as avg_hours_to_first_response
            FROM freshdesk_tickets t
            JOIN freshdesk_agents a ON t.responder_id = a.agent_id
            WHERE t.first_responded_at IS NOT NULL
            GROUP BY a.name
            ORDER BY avg_hours_to_first_response;
            """
        ),

        # Cross-source questions
        (
            "Show me developers who resolved JIRA issues and merged GitHub PRs in the last week",
            """
            SELECT DISTINCT
                COALESCE(ju.display_name, gu.login) as developer_name,
                COUNT(DISTINCT ji.issue_key) as jira_issues_resolved,
                COUNT(DISTINCT gpr.pr_id) as github_prs_merged
            FROM jira_users ju
            FULL OUTER JOIN github_users gu ON ju.email = gu.email
            LEFT JOIN jira_issues ji ON ju.account_id = ji.assignee_account_id
                AND ji.resolved_at >= CURRENT_DATE - INTERVAL '7 days'
            LEFT JOIN github_pull_requests gpr ON gu.user_id = gpr.user_id
                AND gpr.merged = true
                AND gpr.merged_at >= CURRENT_DATE - INTERVAL '7 days'
            WHERE (ji.issue_key IS NOT NULL OR gpr.pr_id IS NOT NULL)
            GROUP BY COALESCE(ju.display_name, gu.login)
            ORDER BY jira_issues_resolved + github_prs_merged DESC;
            """
        )
    ]

    for question, sql in common_qa:
        vanna.train_on_sql(question, sql)

    logger.info(f"✅ Trained on {len(common_qa)} common questions")


if __name__ == '__main__':
    # Initialize and train Vanna
    vanna = VannaSQL()

    # Train on schema files
    train_from_schema_files(vanna, schema_dir='./schema')

    # Train on common questions
    train_common_questions(vanna)

    # Test with a sample question
    result = vanna.ask("How many JIRA tickets are open?", print_results=True)
