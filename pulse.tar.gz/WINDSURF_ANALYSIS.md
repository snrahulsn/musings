# Windsurf Analytics - Complete Data Analysis

## Executive Summary

Windsurf provides **3 primary APIs** with **user-level analytics** data across **8 data dimensions**:

1. **UserPageAnalytics** - User profiles and activity timestamps
2. **CascadeAnalytics** - AI-assisted coding metrics (lines, runs, tools)
3. **CustomAnalytics** - Detailed autocomplete, chat, command, and code written metrics

## Available Data Sources

### 1. User Profile & Activity (`windsurf_users`)

**API:** UserPageAnalytics
**Endpoint:** `https://server.codeium.com/api/v1/UserPageAnalytics`
**Granularity:** Per user
**Update frequency:** Real-time

**Fields:**
- `email` - User email (primary identifier)
- `name` - Display name
- `api_key_hash` - Hashed API key for linking to other datasets
- `active_days` - Total days user has been active
- `disable_codeium` - Access status (boolean)
- `last_update_time` - Last profile update
- `last_autocomplete_usage_time` - Last autocomplete interaction
- `last_chat_usage_time` - Last chat interaction
- `last_command_usage_time` - Last command execution

**Use cases:**
- User adoption tracking
- Activity recency analysis
- User churn prediction
- Feature usage patterns

---

### 2. Cascade Lines Suggested & Accepted (`windsurf_cascade_lines`)

**API:** CascadeAnalytics (cascade_lines)
**Endpoint:** `https://server.codeium.com/api/v1/CascadeAnalytics`
**Granularity:** Per user, per day
**Update frequency:** Daily aggregation

**Fields:**
- `day` - Date of activity
- `email` - User email
- `lines_suggested` - Number of AI-suggested lines
- `lines_accepted` - Number of lines user accepted
- **Derived:** Acceptance rate = `lines_accepted / lines_suggested`

**Use cases:**
- AI suggestion quality (acceptance rates)
- User productivity (lines accepted per day)
- Team performance comparison
- Time-series trending

**Example queries:**
```sql
-- Average acceptance rate per user
SELECT
    email,
    SUM(lines_accepted) * 100.0 / NULLIF(SUM(lines_suggested), 0) as acceptance_rate_pct
FROM windsurf_cascade_lines
GROUP BY email
ORDER BY acceptance_rate_pct DESC;

-- Daily productivity trend
SELECT
    day,
    SUM(lines_accepted) as total_lines
FROM windsurf_cascade_lines
WHERE day >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY day
ORDER BY day;
```

---

### 3. Cascade Runs (`windsurf_cascade_runs`)

**API:** CascadeAnalytics (cascade_runs)
**Endpoint:** `https://server.codeium.com/api/v1/CascadeAnalytics`
**Granularity:** Per cascade execution
**Update frequency:** Per run

**Fields:**
- `cascade_id` - Unique cascade execution ID
- `day` - Date of execution
- `email` - User email
- `model` - AI model used (e.g., "gpt-4", "claude-3")
- `mode` - Execution mode:
  - `DEFAULT` - Full AI assistance
  - `READ_ONLY` - Analysis only
  - `NO_TOOL` - No tool execution
  - `UNKNOWN` - Unspecified
- `messages_sent` - Number of messages in conversation
- `prompts_used` - Number of prompts invoked

**Use cases:**
- Model usage distribution
- Mode preference analysis
- Conversation depth (messages per cascade)
- Cost estimation (model usage)
- User engagement patterns

**Example queries:**
```sql
-- Model usage distribution
SELECT
    model,
    COUNT(*) as runs,
    AVG(messages_sent) as avg_messages
FROM windsurf_cascade_runs
GROUP BY model
ORDER BY runs DESC;

-- User engagement by mode
SELECT
    email,
    mode,
    COUNT(*) as sessions,
    SUM(messages_sent) as total_messages
FROM windsurf_cascade_runs
GROUP BY email, mode
ORDER BY total_messages DESC;
```

---

### 4. Cascade Tool Usage (`windsurf_cascade_tools`)

**API:** CascadeAnalytics (cascade_tool_usage)
**Endpoint:** `https://server.codeium.com/api/v1/CascadeAnalytics`
**Granularity:** Per tool, per user, per day
**Update frequency:** Daily aggregation

**Fields:**
- `day` - Date
- `email` - User email
- `tool` - Tool identifier (14+ available tools)
- `count` - Number of times tool was invoked

**Available tools (examples):**
- `CODE_ACTION` - Code modifications
- `VIEW_FILE` - File viewing
- `SEARCH` - Code search
- `TERMINAL` - Terminal commands
- `DEBUG` - Debugging tools
- And more...

**Use cases:**
- Tool adoption tracking
- Workflow analysis (which tools used together)
- Feature utilization
- User skill profiling

**Example queries:**
```sql
-- Most used tools
SELECT
    tool,
    SUM(count) as total_uses,
    COUNT(DISTINCT email) as users
FROM windsurf_cascade_tools
GROUP BY tool
ORDER BY total_uses DESC;

-- User tool diversity
SELECT
    email,
    COUNT(DISTINCT tool) as tools_used,
    SUM(count) as total_actions
FROM windsurf_cascade_tools
GROUP BY email
ORDER BY tools_used DESC;
```

---

### 5. Autocomplete Metrics (`windsurf_autocomplete`)

**API:** CustomAnalytics (USER_DATA)
**Endpoint:** `https://server.codeium.com/api/v1/Analytics`
**Granularity:** Per user, per language, per IDE, per hour (aggregated to day)
**Update frequency:** Hourly

**Fields:**
- `date` - Date
- `email` - User email
- `language` - Programming language (e.g., "python", "javascript")
- `ide` - IDE type ("editor" for Windsurf, "jetbrains" for plugins)
- `num_acceptances` - Number of autocomplete acceptances
- `num_lines_accepted` - Total lines accepted via autocomplete

**Use cases:**
- Language usage distribution
- IDE preference tracking
- Autocomplete effectiveness by language
- User productivity by stack

**Example queries:**
```sql
-- Top languages by acceptance
SELECT
    language,
    SUM(num_acceptances) as acceptances,
    SUM(num_lines_accepted) as lines
FROM windsurf_autocomplete
GROUP BY language
ORDER BY acceptances DESC;

-- User language diversity
SELECT
    email,
    COUNT(DISTINCT language) as languages,
    SUM(num_acceptances) as total_acceptances
FROM windsurf_autocomplete
GROUP BY email
ORDER BY languages DESC;
```

---

### 6. Chat Interactions (`windsurf_chat`)

**API:** CustomAnalytics (CHAT_DATA)
**Endpoint:** `https://server.codeium.com/api/v1/Analytics`
**Granularity:** Per user, per model, per intent type, per day
**Update frequency:** Daily

**Fields:**
- `date` - Date
- `email` - User email
- `model_id` - AI model used
- `latest_intent_type` - Intent classification:
  - `CHAT_INTENT_FUNCTION_DOCSTRING` - Documentation generation
  - `CHAT_INTENT_CODE_EXPLANATION` - Code explanation
  - `CHAT_INTENT_CODE_GENERATION` - New code creation
  - `CHAT_INTENT_REFACTOR` - Code refactoring
  - And more...
- `num_chats_received` - Number of AI responses
- `chat_accepted` - Number of responses user accepted
- `chat_inserted_at_cursor` - Responses inserted into code

**Use cases:**
- Intent distribution (what users ask for)
- Chat acceptance rates by intent
- Model performance by intent type
- Feature demand analysis

**Example queries:**
```sql
-- Most common intents
SELECT
    latest_intent_type,
    SUM(num_chats_received) as chats,
    SUM(chat_accepted) * 100.0 / NULLIF(SUM(num_chats_received), 0) as acceptance_rate
FROM windsurf_chat
GROUP BY latest_intent_type
ORDER BY chats DESC;

-- User chat patterns
SELECT
    email,
    COUNT(DISTINCT latest_intent_type) as intents_used,
    SUM(num_chats_received) as total_chats,
    SUM(chat_inserted_at_cursor) as insertions
FROM windsurf_chat
GROUP BY email
ORDER BY total_chats DESC;
```

---

### 7. Command Execution (`windsurf_commands`)

**API:** CustomAnalytics (COMMAND_DATA)
**Endpoint:** `https://server.codeium.com/api/v1/Analytics`
**Granularity:** Per user, per language, per IDE, per command source, per day
**Update frequency:** Daily

**Fields:**
- `date` - Date
- `email` - User email
- `language` - Programming language
- `ide` - IDE type
- `command_source` - Where command originated
- `provider_source` - AI provider used
- `lines_added` - Lines added by command
- `lines_removed` - Lines removed by command
- `accepted` - Boolean - was command accepted?

**Use cases:**
- Command acceptance rates
- Code churn analysis (adds vs removes)
- Provider performance comparison
- Refactoring activity tracking

**Example queries:**
```sql
-- Acceptance rates by provider
SELECT
    provider_source,
    COUNT(*) as commands,
    SUM(CASE WHEN accepted THEN 1 ELSE 0 END) * 100.0 / COUNT(*) as acceptance_rate
FROM windsurf_commands
GROUP BY provider_source
ORDER BY commands DESC;

-- Code churn by user
SELECT
    email,
    SUM(lines_added) as added,
    SUM(lines_removed) as removed,
    SUM(lines_added) - SUM(lines_removed) as net_change
FROM windsurf_commands
WHERE accepted = true
GROUP BY email
ORDER BY net_change DESC;
```

---

### 8. Percent Code Written (`windsurf_code_written`)

**API:** CustomAnalytics (PCW_DATA)
**Endpoint:** `https://server.codeium.com/api/v1/Analytics`
**Granularity:** Per user, per day
**Update frequency:** Daily

**Fields:**
- `date` - Date
- `email` - User email
- `percent_code_written` - Percentage of code written by AI (0-100)
- `codeium_bytes` - Total bytes written by AI
- `user_bytes` - Total bytes written by user
- `codeium_bytes_by_autocomplete` - AI bytes via autocomplete
- `codeium_bytes_by_command` - AI bytes via commands

**Use cases:**
- AI assistance ratio
- User vs AI contribution
- Feature utilization (autocomplete vs commands)
- Productivity impact measurement

**Example queries:**
```sql
-- AI contribution by user
SELECT
    email,
    AVG(percent_code_written) as avg_ai_percent,
    SUM(codeium_bytes) as total_ai_bytes,
    SUM(user_bytes) as total_user_bytes
FROM windsurf_code_written
GROUP BY email
ORDER BY avg_ai_percent DESC;

-- Autocomplete vs command contribution
SELECT
    email,
    SUM(codeium_bytes_by_autocomplete) * 100.0 / NULLIF(SUM(codeium_bytes), 0) as pct_autocomplete,
    SUM(codeium_bytes_by_command) * 100.0 / NULLIF(SUM(codeium_bytes), 0) as pct_command
FROM windsurf_code_written
GROUP BY email;
```

---

## Cross-Source Analytics Opportunities

### Work Flow Tracking

Combine multiple sources to understand user workflows:

```sql
-- Daily user activity summary
SELECT
    u.email,
    u.name,
    cl.lines_accepted as cascade_lines,
    ac.num_acceptances as autocomplete_accepts,
    ch.num_chats_received as chat_interactions,
    cmd.lines_added + cmd.lines_removed as command_changes,
    cw.percent_code_written as ai_contribution_pct
FROM windsurf_users u
LEFT JOIN windsurf_cascade_lines cl ON u.email = cl.email AND cl.day = CURRENT_DATE
LEFT JOIN (
    SELECT email, SUM(num_acceptances) as num_acceptances
    FROM windsurf_autocomplete
    WHERE date = CURRENT_DATE
    GROUP BY email
) ac ON u.email = ac.email
LEFT JOIN (
    SELECT email, SUM(num_chats_received) as num_chats_received
    FROM windsurf_chat
    WHERE date = CURRENT_DATE
    GROUP BY email
) ch ON u.email = ch.email
LEFT JOIN (
    SELECT email, SUM(lines_added) as lines_added, SUM(lines_removed) as lines_removed
    FROM windsurf_commands
    WHERE date = CURRENT_DATE AND accepted = true
    GROUP BY email
) cmd ON u.email = cmd.email
LEFT JOIN windsurf_code_written cw ON u.email = cw.email AND cw.date = CURRENT_DATE
ORDER BY cascade_lines DESC NULLS LAST;
```

### User Segmentation

```sql
-- Classify users by usage patterns
WITH user_metrics AS (
    SELECT
        u.email,
        u.active_days,
        COALESCE(SUM(cl.lines_accepted), 0) as total_lines,
        COALESCE(COUNT(DISTINCT cr.cascade_id), 0) as cascade_sessions,
        COALESCE(AVG(cw.percent_code_written), 0) as avg_ai_pct
    FROM windsurf_users u
    LEFT JOIN windsurf_cascade_lines cl ON u.email = cl.email
    LEFT JOIN windsurf_cascade_runs cr ON u.email = cr.email
    LEFT JOIN windsurf_code_written cw ON u.email = cw.email
    GROUP BY u.email, u.active_days
)
SELECT
    email,
    CASE
        WHEN cascade_sessions > 100 AND avg_ai_pct > 50 THEN 'Power User'
        WHEN cascade_sessions > 50 THEN 'Active User'
        WHEN cascade_sessions > 10 THEN 'Regular User'
        ELSE 'Occasional User'
    END as user_segment,
    active_days,
    total_lines,
    cascade_sessions,
    ROUND(avg_ai_pct, 1) as avg_ai_contribution
FROM user_metrics
ORDER BY cascade_sessions DESC;
```

---

## Incremental Sync Strategy

The ingestor uses **sync metadata tracking** for efficient incremental updates:

1. **First run:** Fetches up to 365 days of historical data
2. **Subsequent runs:** Only fetches data since `last_sync_timestamp`
3. **Lookback overlap:** Goes back 7 days to catch late-arriving data
4. **Upsert logic:** Uses `ON CONFLICT` to handle duplicates
5. **Error tracking:** Logs failures in `windsurf_sync_metadata`

**Sync frequency recommendations:**
- User data: Every 6 hours (low change rate)
- Cascade analytics: Every 1 hour (moderate activity)
- Custom analytics: Every 1 hour (high granularity)

---

## Data Volumes & Performance

**Expected data volumes (100 users, 1 year):**

| Table | Rows | Est. Size |
|-------|------|-----------|
| windsurf_users | 100 | < 1 MB |
| windsurf_cascade_lines | 36,500 | ~10 MB |
| windsurf_cascade_runs | 500,000 | ~100 MB |
| windsurf_cascade_tools | 180,000 | ~30 MB |
| windsurf_autocomplete | 1,000,000 | ~200 MB |
| windsurf_chat | 500,000 | ~100 MB |
| windsurf_commands | 300,000 | ~80 MB |
| windsurf_code_written | 36,500 | ~10 MB |
| **Total** | **~2.5M rows** | **~530 MB** |

**Indexes:** All date, email, and composite unique columns are indexed for fast queries.

---

## API Limitations & Considerations

1. **Authentication:** Requires service key with "Teams Read-only" permissions
2. **User-level access:** Must enable individual-level analytics in team settings
3. **Rate limits:** Not publicly documented - implement exponential backoff if needed
4. **Timestamp format:** RFC 3339 (e.g., `2025-01-01T00:00:00Z`)
5. **Data retention:** Windsurf may have retention limits (typically 1 year)
6. **API key mapping:** Custom analytics returns API key hash - join with users table for email

---

## Integration with Future Data Sources

This Windsurf ingestor establishes the pattern for other sources:

**JIRA ingestor:**
- Similar incremental sync with `jira_sync_metadata`
- Track tickets, sprints, transitions, comments
- Link to users via email

**GitHub ingestor:**
- PRs, commits, reviews, issues
- Link to users via GitHub username → email mapping
- Track repository activity

**Cross-source joins:**
```sql
-- Link Windsurf usage to JIRA tickets
SELECT
    j.ticket_key,
    j.assignee_email,
    SUM(w.lines_accepted) as windsurf_lines_on_ticket_days
FROM jira_tickets j
JOIN windsurf_cascade_lines w
    ON j.assignee_email = w.email
    AND w.day BETWEEN j.created_date AND COALESCE(j.closed_date, CURRENT_DATE)
GROUP BY j.ticket_key, j.assignee_email;
```

---

## Next Steps

1. ✅ **Windsurf data ingestion** - Complete
2. **JIRA ingestor** - Build similar pattern
3. **GitHub ingestor** - Build similar pattern
4. **Freshdesk ingestor** - Build similar pattern
5. **Vanna integration** - Text-to-SQL over unified dataset
6. **Qdrant integration** - Similarity search over descriptions
7. **Chainlit UI** - Chat interface
8. **Scheduled jobs** - APScheduler for automation

This foundation supports the full chatbot vision: tracking operational metrics and work flow across your organization.
