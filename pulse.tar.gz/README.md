# Pulse - Operational Metrics Chatbot

Production-grade chatbot for tracking operational metrics and work flow across your organization's tools: Windsurf, JIRA, GitHub, and Freshdesk.

## 🎯 Vision

Help you understand:
- How work moves across your organization
- Team productivity and bottlenecks
- Cross-tool workflows and dependencies
- Operational metrics through natural language queries

## 🏗️ Architecture

### Hybrid Query System

```
User Query → Query Router
              ↓
    ┌─────────┴─────────┐
    ↓                   ↓
Text-to-SQL        Similarity Search
 (Vanna)              (Qdrant)
    ↓                   ↓
PostgreSQL          Vector DB
    ↓                   ↓
  Visualization    Similar Items
```

### Tech Stack

**Data Layer:**
- **PostgreSQL**: Structured data (metrics, relationships)
- **Qdrant**: Vector database for semantic similarity
- **Redis**: Caching layer

**Application Layer:**
- **Vanna**: Self-learning text-to-SQL
- **Chainlit**: Conversational UI
- **Claude API**: LLM for query understanding
- **Ollama**: Local embeddings (nomic-embed-text)

**Orchestration:**
- **Prefect**: Workflow automation
- **Docker Compose**: Service orchestration

**Monitoring:**
- **Grafana**: Dashboards and visualization
- **Loki**: Log aggregation
- **Promtail**: Log shipping

## 🚀 Quick Start

```bash
# 1. Setup
make setup

# 2. Configure .env
cp .env.example .env
# Edit .env with your API keys

# 3. Start services
make start

# 4. Pull embedding model
make setup-ollama

# 5. Deploy workflows
make deploy-flows

# 6. Run first sync
make run-sync
```

**That's it!** Open http://localhost:4200 for Prefect UI and http://localhost:3000 for Grafana.

## 📊 Data Sources

### ✅ Windsurf (Implemented)

**8 datasets covering:**
- User profiles and activity
- Cascade AI suggestions (lines, runs, tools)
- Autocomplete metrics by language/IDE
- Chat interactions and intent types
- Command execution and acceptance
- Code written (AI vs human contribution)

**Status:** Fully automated with Prefect
- Incremental sync: Every hour
- Full sync: Daily at 2 AM UTC

### ✅ JIRA (Implemented)

**11 datasets covering:**
- Projects and users
- Complete issue data (all fields, custom fields)
- Issue changelog (status, assignments, all changes)
- Comments, worklogs, attachments
- Boards and sprints
- Sprint-issue relationships
- Issue links (blocks, relates, etc.)

**Status:** Fully automated with Prefect
- Incremental sync: Every 2 hours
- Full sync: Daily at 3 AM UTC

### 🔜 GitHub (Planned)

- Pull requests, commits, reviews
- Repository activity
- Developer contributions
- Linking to JIRA tickets

### 🔜 Freshdesk (Planned)

- Support tickets
- Response times
- Customer satisfaction
- Agent performance

## 📁 Project Structure

```
pulse_final/
├── config/                      # Service configurations
│   ├── loki-config.yml
│   ├── promtail-config.yml
│   └── grafana-datasources.yml
├── flows/                       # Prefect workflows
│   ├── windsurf_flow.py
│   └── jira_flow.py
├── ingestors/                   # Data ingestion scripts
│   ├── windsurf_ingestor.py
│   └── jira_ingestor.py
├── logs/                        # Application logs
├── schema/                      # Database schemas
│   ├── windsurf_schema.sql
│   └── jira_schema.sql
├── tests/                       # Test suites
│   └── test_windsurf_setup.py
├── docker-compose.yml           # Infrastructure
├── Makefile                     # Common commands
├── requirements.txt             # Python dependencies
├── .env.example                 # Configuration template
├── SETUP.md                     # Detailed setup guide
├── QUICKSTART.md                # Quick Windsurf setup
├── README_WINDSURF.md           # Windsurf docs
├── README_JIRA.md               # JIRA docs
└── WINDSURF_ANALYSIS.md         # Data analysis reference
```

## 🎮 Usage

### Command Reference

```bash
# Service Management
make start              # Start all services
make stop               # Stop all services
make restart            # Restart services
make status             # Check health
make logs               # View all logs
make logs-postgres      # View specific service logs

# Data Operations
make run-sync           # Manual data sync
make stats              # Show database statistics
make sync-status        # Check sync metadata

# Database Operations
make db-shell           # Open PostgreSQL shell
make db-backup          # Backup database
make db-restore         # Restore from latest backup

# Monitoring
make monitor            # Open dashboards
make prefect-ui         # Open Prefect UI
make grafana-ui         # Open Grafana UI

# Deployment
make deploy-flows       # Deploy Prefect workflows
make setup-ollama       # Pull embedding model

# Maintenance
make clean              # Remove all data (WARNING!)
make clean-logs         # Remove old logs
make test               # Run tests
```

### Example Queries (Future)

Once the chatbot UI is built:

**Metrics Queries (Text-to-SQL):**
- "Show me ticket volume by team over last month"
- "What's the average cycle time for completed JIRA tickets?"
- "How many lines of code did team X accept from Windsurf last week?"
- "Compare PR merge times across repositories"

**Similarity Queries (Vector Search):**
- "Find tickets similar to JIRA-123"
- "Has anyone worked on authentication bugs before?"
- "Show me related issues across JIRA and GitHub"

**Cross-Source Queries:**
- "Show Windsurf usage for developers working on JIRA-456"
- "Link PRs to JIRA tickets closed last sprint"
- "Find support tickets that led to code changes"

## 🔧 Configuration

### Environment Variables

See [.env.example](.env.example) for all configuration options.

**Required:**
- `WINDSURF_SERVICE_KEY`: From https://windsurf.com/team/team_settings
- `ANTHROPIC_API_KEY`: From https://console.anthropic.com

**Optional:**
- `WINDSURF_EMAILS`: Filter specific users (comma-separated)
- Database passwords (use secure values in production)

### Service Customization

**Prefect Schedules**: Edit [flows/windsurf_flow.py](flows/windsurf_flow.py)
**Database Schema**: Edit [schema/windsurf_schema.sql](schema/windsurf_schema.sql)
**Logging Config**: Edit [config/promtail-config.yml](config/promtail-config.yml)

## 📈 Monitoring

### Grafana Dashboards

Access: http://localhost:3000 (admin/admin)

**Pre-configured datasources:**
- Loki (logs)
- PostgreSQL (metrics)
- Redis (cache stats)

**Sample Queries:**

```sql
-- User Activity Trend
SELECT
  date_trunc('day', last_update_time) as time,
  count(*) as active_users
FROM windsurf_users
WHERE last_update_time >= NOW() - INTERVAL '30 days'
GROUP BY 1
ORDER BY 1;

-- AI Acceptance Rate
SELECT
  email,
  SUM(lines_accepted) * 100.0 / NULLIF(SUM(lines_suggested), 0) as acceptance_rate
FROM windsurf_cascade_lines
GROUP BY email
ORDER BY acceptance_rate DESC;
```

### Prefect Monitoring

Access: http://localhost:4200

- View flow runs
- Check execution logs
- Monitor failures and retries
- Trigger manual runs

### Log Queries (Loki)

Access via Grafana Explore → Loki

```
{app="windsurf_ingestor"}
{app="prefect"} |= "error"
{job="pulse"} |= "failed"
```

## 🧪 Testing

```bash
# Run setup validation
make test

# Should see:
# ✅ PASS: Environment Variables
# ✅ PASS: Database Connection
# ✅ PASS: Schema
# ✅ PASS: Database Write Permissions
# ✅ PASS: API Connectivity
# ✅ PASS: Service Key Format
```

## 🔐 Security

**Production Checklist:**
- [ ] Change all default passwords in `.env`
- [ ] Use strong database passwords
- [ ] Restrict Docker network access
- [ ] Enable SSL/TLS for external services
- [ ] Set up firewall rules
- [ ] Rotate API keys regularly
- [ ] Review service logs for anomalies
- [ ] Implement backup encryption

## 🐛 Troubleshooting

### Services Won't Start

```bash
# Check Docker
docker compose ps

# View logs
docker compose logs

# Restart specific service
docker compose restart postgres
```

### Database Connection Issues

```bash
# Test connection
docker exec -it pulse_postgres psql -U pulse_user -d pulse

# Check if running
docker compose ps postgres
```

### Prefect Flows Not Running

```bash
# Check Prefect server
curl http://localhost:4200/api/health

# View Prefect logs
docker compose logs prefect-server

# Redeploy flows
make deploy-flows
```

### No Data After Sync

```bash
# Check sync status
make sync-status

# View ingestor logs
tail -f logs/windsurf_flow.log

# Run manual sync with verbose logging
./venv/bin/python ingestors/windsurf_ingestor.py
```

## 📚 Documentation

- **[SETUP.md](SETUP.md)**: Complete setup guide
- **[QUICKSTART.md](QUICKSTART.md)**: Quick Windsurf setup
- **[README_WINDSURF.md](README_WINDSURF.md)**: Windsurf-specific documentation
- **[WINDSURF_ANALYSIS.md](WINDSURF_ANALYSIS.md)**: Data analysis reference

## 🛣️ Roadmap

### Phase 1: Foundation (Current)
- [x] Windsurf data ingestion
- [x] PostgreSQL schema
- [x] Prefect workflow automation
- [x] Grafana monitoring setup
- [x] Docker compose infrastructure

### Phase 2: Core Functionality (In Progress)
- [x] JIRA ingestor
- [ ] GitHub ingestor
- [ ] Freshdesk ingestor
- [ ] Vanna text-to-SQL integration
- [ ] Qdrant vector database setup
- [ ] Basic query router

### Phase 3: User Interface
- [ ] Chainlit chat UI
- [ ] Query visualization (Plotly)
- [ ] Result caching
- [ ] User authentication

### Phase 4: Intelligence
- [ ] Cross-source queries
- [ ] Similarity search
- [ ] Work flow analysis
- [ ] Bottleneck detection
- [ ] Predictive analytics

### Phase 5: Production Hardening
- [ ] Performance optimization
- [ ] Error handling improvements
- [ ] Comprehensive test suite
- [ ] Documentation completion
- [ ] Deployment automation

## 🤝 Contributing

**Pattern for New Ingestors:**

1. Create schema in `schema/`
2. Build ingestor in `ingestors/`
3. Create Prefect flow in `flows/`
4. Add tests in `tests/`
5. Update documentation

**Example**: Copy `ingestors/windsurf_ingestor.py` as a template.

## 📄 License

[Add your license here]

## 🙏 Acknowledgments

Built with:
- [Prefect](https://www.prefect.io/) - Workflow orchestration
- [Vanna AI](https://vanna.ai/) - Text-to-SQL
- [Qdrant](https://qdrant.tech/) - Vector database
- [Chainlit](https://chainlit.io/) - Chat UI
- [Grafana](https://grafana.com/) - Monitoring
- [Anthropic Claude](https://www.anthropic.com/) - LLM

---

**Status**: 🟢 Phase 2 In Progress - Windsurf + JIRA operational

**Current Capabilities:**
- ✅ Automated Windsurf data sync (8 datasets, hourly + daily)
- ✅ Automated JIRA data sync (11 datasets, every 2 hours + daily)
- ✅ PostgreSQL storage with 19 tables
- ✅ Prefect workflow orchestration
- ✅ Grafana monitoring and logging
- ✅ Docker-based infrastructure

**Next**: Implement GitHub and Freshdesk ingestors, then build the chatbot UI.
