"""
Test script to validate Windsurf ingestor setup and configuration

Run this before running the full ingestor to catch configuration issues.
"""

import os
import sys
from datetime import datetime, timezone

import psycopg2
from dotenv import load_dotenv

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

load_dotenv()


def test_env_variables():
    """Test that required environment variables are set"""
    print("Testing environment variables...")

    required = ['WINDSURF_SERVICE_KEY', 'DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD']
    missing = []

    for var in required:
        value = os.getenv(var)
        if not value:
            missing.append(var)
            print(f"  ❌ {var}: NOT SET")
        else:
            # Mask sensitive values
            if 'KEY' in var or 'PASSWORD' in var:
                display = value[:8] + '...' if len(value) > 8 else '***'
            else:
                display = value
            print(f"  ✅ {var}: {display}")

    if missing:
        print(f"\n❌ Missing required variables: {', '.join(missing)}")
        return False

    print("✅ All required environment variables set\n")
    return True


def test_database_connection():
    """Test PostgreSQL connection"""
    print("Testing database connection...")

    try:
        conn = psycopg2.connect(
            host=os.getenv('DB_HOST'),
            database=os.getenv('DB_NAME'),
            user=os.getenv('DB_USER'),
            password=os.getenv('DB_PASSWORD'),
            port=int(os.getenv('DB_PORT', 5432))
        )

        cursor = conn.cursor()
        cursor.execute("SELECT version();")
        version = cursor.fetchone()[0]
        print(f"  ✅ Connected to PostgreSQL")
        print(f"  ℹ️  Version: {version[:50]}...")

        cursor.close()
        conn.close()

        print("✅ Database connection successful\n")
        return True

    except Exception as e:
        print(f"  ❌ Connection failed: {e}\n")
        return False


def test_schema_exists():
    """Test that required tables exist"""
    print("Testing schema...")

    required_tables = [
        'windsurf_users',
        'windsurf_cascade_lines',
        'windsurf_cascade_runs',
        'windsurf_cascade_tools',
        'windsurf_autocomplete',
        'windsurf_chat',
        'windsurf_commands',
        'windsurf_code_written',
        'windsurf_sync_metadata'
    ]

    try:
        conn = psycopg2.connect(
            host=os.getenv('DB_HOST'),
            database=os.getenv('DB_NAME'),
            user=os.getenv('DB_USER'),
            password=os.getenv('DB_PASSWORD'),
            port=int(os.getenv('DB_PORT', 5432))
        )

        cursor = conn.cursor()
        missing_tables = []

        for table in required_tables:
            cursor.execute(
                """
                SELECT EXISTS (
                    SELECT FROM information_schema.tables
                    WHERE table_schema = 'public'
                    AND table_name = %s
                );
                """,
                (table,)
            )
            exists = cursor.fetchone()[0]

            if exists:
                print(f"  ✅ {table}")
            else:
                print(f"  ❌ {table} (missing)")
                missing_tables.append(table)

        cursor.close()
        conn.close()

        if missing_tables:
            print(f"\n❌ Missing tables: {', '.join(missing_tables)}")
            print("   Run: psql -d pulse -f schema/windsurf_schema.sql\n")
            return False

        print("✅ All required tables exist\n")
        return True

    except Exception as e:
        print(f"  ❌ Schema check failed: {e}\n")
        return False


def test_api_connectivity():
    """Test that Windsurf API is reachable"""
    print("Testing Windsurf API connectivity...")

    try:
        import requests

        # Simple connectivity test to Windsurf server
        response = requests.get("https://server.codeium.com", timeout=10)

        if response.status_code in [200, 301, 302, 404]:  # Any response means server is reachable
            print(f"  ✅ Windsurf API server reachable")
            print("✅ API connectivity test passed\n")
            return True
        else:
            print(f"  ⚠️  Unexpected status: {response.status_code}")
            return True  # Still reachable

    except requests.exceptions.RequestException as e:
        print(f"  ❌ Cannot reach Windsurf API: {e}\n")
        return False


def test_service_key_format():
    """Test that service key looks valid (basic format check)"""
    print("Testing service key format...")

    service_key = os.getenv('WINDSURF_SERVICE_KEY')

    if not service_key:
        print("  ❌ Service key not set\n")
        return False

    # Basic validation (service keys are typically long strings)
    if len(service_key) < 20:
        print("  ⚠️  Service key seems too short")
        print("  ℹ️  Make sure you copied the full key from Windsurf\n")
        return False

    print(f"  ✅ Service key format looks valid (length: {len(service_key)})")
    print("✅ Service key format test passed\n")
    return True


def test_write_permissions():
    """Test that we can write to the database"""
    print("Testing database write permissions...")

    try:
        conn = psycopg2.connect(
            host=os.getenv('DB_HOST'),
            database=os.getenv('DB_NAME'),
            user=os.getenv('DB_USER'),
            password=os.getenv('DB_PASSWORD'),
            port=int(os.getenv('DB_PORT', 5432))
        )

        cursor = conn.cursor()

        # Test write to sync_metadata table
        test_timestamp = datetime.now(timezone.utc)
        cursor.execute(
            """
            INSERT INTO windsurf_sync_metadata
            (api_endpoint, last_sync_timestamp, last_sync_status)
            VALUES (%s, %s, %s)
            ON CONFLICT (api_endpoint) DO UPDATE
            SET last_sync_timestamp = EXCLUDED.last_sync_timestamp
            """,
            ('_test', test_timestamp, 'test')
        )

        # Clean up test record
        cursor.execute("DELETE FROM windsurf_sync_metadata WHERE api_endpoint = '_test'")

        conn.commit()
        cursor.close()
        conn.close()

        print("  ✅ Write test successful")
        print("✅ Database write permissions confirmed\n")
        return True

    except Exception as e:
        print(f"  ❌ Write test failed: {e}\n")
        return False


def main():
    """Run all tests"""
    print("="*60)
    print("Windsurf Ingestor Setup Validation")
    print("="*60)
    print()

    tests = [
        ("Environment Variables", test_env_variables),
        ("Database Connection", test_database_connection),
        ("Schema", test_schema_exists),
        ("Database Write Permissions", test_write_permissions),
        ("API Connectivity", test_api_connectivity),
        ("Service Key Format", test_service_key_format),
    ]

    results = []

    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"❌ Test '{name}' crashed: {e}\n")
            results.append((name, False))

    # Summary
    print("="*60)
    print("Test Summary")
    print("="*60)

    passed = sum(1 for _, result in results if result)
    total = len(results)

    for name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {name}")

    print()
    print(f"Results: {passed}/{total} tests passed")

    if passed == total:
        print("\n🎉 All tests passed! You're ready to run the ingestor.")
        print("\nNext step:")
        print("  python ingestors/windsurf_ingestor.py")
        return 0
    else:
        print("\n⚠️  Some tests failed. Please fix the issues above before running the ingestor.")
        return 1


if __name__ == '__main__':
    sys.exit(main())
