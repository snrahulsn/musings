# Pulse - Operational Metrics Chatbot 🎯

A production-grade chatbot for querying operational metrics across your organization using natural language.

## Overview

Pulse is a comprehensive data analytics platform that ingests data from multiple sources and provides a conversational interface for querying metrics. It combines SQL-based analytics (70%) with semantic similarity search (30%) to answer a wide range of operational questions.

### Data Sources

- **Windsurf**: AI coding analytics (cascade runs, autocomplete, chat, code written)
- **JIRA**: Project management (issues, sprints, boards, worklogs, custom fields)
- **GitHub**: Code repositories (PRs, issues, commits, reviews, custom fields)
- **Freshdesk**: Customer support (tickets, conversations, time entries, custom fields)

### Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        User Interface                            │
│                    Chainlit Chat UI (app.py)                     │
└─────────────────────┬───────────────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────────────┐
│                      Query Router                                │
│     Routes queries to SQL (70%) or Similarity Search (30%)       │
│                 Uses Claude for classification                   │
└─────────┬────────────────────────────────────────────┬──────────┘
          │                                              │
┌─────────▼──────────┐                      ┌───────────▼─────────┐
│   Vanna (SQL)      │                      │ Qdrant (Similarity) │
│ Text-to-SQL Engine │                      │  Vector Search      │
│ Powered by Claude  │                      │  Ollama Embeddings  │
└─────────┬──────────┘                      └───────────┬─────────┘
          │                                              │
          └──────────────────┬───────────────────────────┘
                             │
┌────────────────────────────▼───────────────────────────────────┐
│                     PostgreSQL Database                         │
│  Windsurf | JIRA | GitHub | Freshdesk (50 tables, ~3.35M rows) │
└─────────────────────────────────────────────────────────────────┘
                             ▲
                             │
┌────────────────────────────┴───────────────────────────────────┐
│                   Data Ingestion Pipeline                       │
│                  Prefect Workflows (Scheduled)                  │
│   - Hourly incremental syncs                                    │
│   - Daily full syncs with lookback                              │
│   - Retry logic, logging to Loki                                │
└─────────────────────────────────────────────────────────────────┘
```

## Features

### 🔍 Query Capabilities

**Metrics & Analytics (SQL)**
- "How many JIRA tickets are open?"
- "What is the average PR review time by repository?"
- "Who resolved the most issues last week?"
- "Show me code lines written by each developer this month"
- "What is the first response time by Freshdesk agent?"

**Similarity Search**
- "Find JIRA tickets similar to JIRA-123"
- "Show me GitHub issues related to authentication"
- "What are similar support tickets to this description?"
- "Find PRs that deal with database performance"

### 🎨 Visualizations

- Automatic chart generation with Plotly
- Interactive tables
- Score-based similarity rankings

### ⚡ Real-time Data

- Incremental sync every 1-2 hours
- Full sync daily with configurable lookback
- Idempotent upserts for data consistency

### 📊 Monitoring

- Grafana dashboards for metrics
- Loki for centralized logging
- Prefect UI for workflow monitoring
- Database statistics and sync status

## Quick Start

### 1. Prerequisites

- Docker & Docker Compose
- Python 3.11+
- Git
- API keys for:
  - Anthropic Claude
  - Windsurf
  - JIRA
  - GitHub
  - Freshdesk

### 2. Clone and Setup

```bash
# Clone repository
cd /path/to/pulse_final

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Copy and configure environment variables
cp .env.example .env
# Edit .env with your API keys
```

### 3. Start Infrastructure

```bash
# Start all Docker services
make start

# Wait for services to be healthy (check with)
make status

# Pull Ollama embedding model
make setup-ollama
```

### 4. Initialize Pulse

```bash
# Create schemas, train Vanna, setup Qdrant
make setup-pulse
```

### 5. Deploy Workflows

```bash
# Deploy Prefect flows
make deploy-flows
```

### 6. Run Initial Ingestion

```bash
# Run first sync (or wait for scheduled runs)
make run-sync
```

### 7. Start Chat UI

```bash
# Launch Chainlit interface
make run-ui
```

Visit http://localhost:8000 to use the chat interface!

## Project Structure

```
pulse_final/
├── app.py                      # Chainlit chat UI
├── deploy_flows.py             # Prefect deployment config
├── setup_pulse.py              # Setup script
│
├── ingestors/                  # Data ingestion modules
│   ├── windsurf_ingestor.py   # Windsurf API client
│   ├── jira_ingestor.py        # JIRA API client
│   ├── github_ingestor.py      # GitHub API client
│   └── freshdesk_ingestor.py   # Freshdesk API client
│
├── flows/                      # Prefect workflows
│   ├── windsurf_flow.py
│   ├── jira_flow.py
│   ├── github_flow.py
│   └── freshdesk_flow.py
│
├── query_engine/               # Query processing
│   ├── vanna_config.py         # Text-to-SQL engine
│   ├── qdrant_config.py        # Vector similarity search
│   └── query_router.py         # Query classification & routing
│
├── schema/                     # Database schemas
│   ├── windsurf_schema.sql     # 9 tables
│   ├── jira_schema.sql         # 12 tables (with custom fields)
│   ├── github_schema.sql       # 16 tables (with custom fields)
│   └── freshdesk_schema.sql    # 13 tables (with custom fields)
│
├── config/                     # Service configurations
│   ├── loki-config.yml
│   ├── promtail-config.yml
│   └── grafana-datasources.yml
│
├── logs/                       # Application logs
├── backups/                    # Database backups
├── docker-compose.yml          # Infrastructure definition
├── Makefile                    # Convenience commands
└── requirements.txt            # Python dependencies
```

## Makefile Commands

### Setup & Management
- `make setup` - Initial Python environment setup
- `make start` - Start all Docker services
- `make stop` - Stop all services
- `make restart` - Restart services
- `make status` - Check service health
- `make setup-pulse` - Initialize Pulse (schemas, Vanna, Qdrant)

### Data Operations
- `make deploy-flows` - Deploy Prefect workflows
- `make run-sync` - Manual data sync
- `make train-vanna` - Train Vanna on schemas
- `make index-qdrant` - Index data into Qdrant
- `make stats` - Show database statistics
- `make sync-status` - Check sync metadata

### UI & Monitoring
- `make run-ui` - Start Chainlit chat interface
- `make prefect-ui` - Open Prefect UI
- `make grafana-ui` - Open Grafana UI
- `make monitor` - Open all monitoring dashboards

### Database
- `make db-shell` - Open PostgreSQL shell
- `make db-backup` - Backup database
- `make db-restore` - Restore from backup

### Logs & Debugging
- `make logs` - View all logs
- `make logs-postgres` - View specific service logs
- `make clean-logs` - Remove old log files

## Service URLs

| Service | URL | Description |
|---------|-----|-------------|
| Chainlit UI | http://localhost:8000 | Chat interface |
| Prefect | http://localhost:4200 | Workflow monitoring |
| Grafana | http://localhost:3000 | Metrics & logs (admin/admin) |
| Qdrant | http://localhost:6333 | Vector database |
| PostgreSQL | localhost:5432 | Main database |
| Redis | localhost:6379 | Cache |
| Ollama | http://localhost:11434 | Embeddings |
| Loki | http://localhost:3100 | Log aggregation |

## Data Schema Summary

Total: **50 tables**, ~3.35M rows, ~1.88 GB

### Windsurf (9 tables)
- Users, cascade analytics, autocomplete, chat, commands, code written
- No custom fields (API provides predefined fields)

### JIRA (12 tables)
- Projects, users, issues, changelog, comments, worklogs
- Boards, sprints, sprint_issues, issue_links, attachments
- **Custom fields**: JSONB + typed columns

### GitHub (16 tables)
- Organizations, repos, users, PRs, commits, reviews, issues
- Releases, workflows, workflow_runs
- **Custom fields**: Project fields with JSONB

### Freshdesk (13 tables)
- Agents, groups, companies, contacts, tickets
- Conversations, time_entries, satisfaction_ratings
- **Custom fields**: Ticket fields with JSONB

## Example Queries

### SQL Queries (Vanna)

```
"How many JIRA tickets are in each status?"
→ SELECT status, COUNT(*) FROM jira_issues GROUP BY status

"What is the average time to resolve high priority tickets?"
→ SELECT AVG(EXTRACT(EPOCH FROM (resolved_at - created_at)) / 3600)
  FROM jira_issues WHERE priority = 'High' AND resolved_at IS NOT NULL

"Who merged the most PRs this month?"
→ SELECT u.login, COUNT(*) as merged_prs
  FROM github_pull_requests pr
  JOIN github_users u ON pr.user_id = u.user_id
  WHERE pr.merged = true AND pr.merged_at >= DATE_TRUNC('month', CURRENT_DATE)
  GROUP BY u.login ORDER BY merged_prs DESC

"Show me code activity by developer this week"
→ SELECT u.display_name, SUM(lines_added) as lines
  FROM windsurf_code_written cw
  JOIN windsurf_users u ON cw.user_id = u.user_id
  WHERE date >= CURRENT_DATE - INTERVAL '7 days'
  GROUP BY u.display_name ORDER BY lines DESC
```

### Similarity Queries (Qdrant)

```
"Find JIRA tickets similar to authentication issues"
→ Searches jira_issues_vectors collection
→ Returns top 10 most similar tickets with scores

"Show me GitHub PRs related to database performance"
→ Searches github_prs_vectors collection
→ Returns similar PRs with context

"What support tickets are similar to 'login timeout error'?"
→ Searches freshdesk_tickets_vectors collection
→ Returns related tickets
```

## Scheduled Workflows

All workflows run automatically via Prefect:

| Workflow | Schedule | Description |
|----------|----------|-------------|
| windsurf-incremental | Every hour | Last 7 days |
| windsurf-full | Daily 2 AM UTC | Full sync |
| jira-incremental | Every 2 hours | Last 7 days |
| jira-full | Daily 3 AM UTC | 30-day lookback |
| github-incremental | Every 2 hours (:15) | Last 7 days |
| github-full | Daily 4 AM UTC | 90-day lookback |
| freshdesk-incremental | Every 2 hours (:30) | Last 7 days |
| freshdesk-full | Daily 5 AM UTC | 90-day lookback |

## Configuration

### Environment Variables (.env)

Required:
```bash
# LLM
ANTHROPIC_API_KEY=your_key

# Data Sources
WINDSURF_SERVICE_KEY=your_key
JIRA_URL=https://yourcompany.atlassian.net
JIRA_EMAIL=your@email.com
JIRA_API_TOKEN=your_token
GITHUB_TOKEN=your_token
GITHUB_ORG=your_org
FRESHDESK_DOMAIN=yourcompany.freshdesk.com
FRESHDESK_API_KEY=your_key

# Database
DB_PASSWORD=pulse_password

# Monitoring
GRAFANA_PASSWORD=admin
```

### Customization

**Add more training examples to Vanna:**
Edit `query_engine/vanna_config.py` → `train_common_questions()`

**Adjust sync schedules:**
Edit `deploy_flows.py` → Change cron expressions

**Add custom fields processing:**
Edit `ingestors/*_ingestor.py` → Modify `_upsert_custom_fields()`

## Troubleshooting

### Services won't start
```bash
# Check Docker
docker ps

# View logs
make logs

# Restart services
make restart
```

### Vanna not generating SQL
```bash
# Retrain Vanna
make train-vanna

# Check training data
./venv/bin/python -c "from query_engine.vanna_config import VannaSQL; v = VannaSQL(); print(v.get_training_data())"
```

### Qdrant search not working
```bash
# Reindex data
make index-qdrant

# Check collections
curl http://localhost:6333/collections
```

### Ingestion failing
```bash
# Check sync metadata
make sync-status

# View flow logs
make logs-prefect

# Run manually with debug
./venv/bin/python ingestors/windsurf_ingestor.py
```

## Performance

- **Query latency**: 2-5 seconds (SQL), 1-2 seconds (similarity)
- **Ingestion throughput**: ~1000 records/minute
- **Database size**: ~1.88 GB for 3.35M rows
- **Vector search**: Sub-second similarity queries

## Security

- API keys stored in .env (gitignored)
- Database passwords in environment variables
- No hardcoded credentials
- Docker network isolation
- Grafana authentication required

## Future Enhancements

- [ ] Add Slack integration for alerts
- [ ] Real-time streaming ingestion
- [ ] Advanced analytics (forecasting, anomaly detection)
- [ ] Multi-tenant support
- [ ] Custom dashboard builder
- [ ] Export query results to CSV/Excel
- [ ] Query result caching with Redis
- [ ] Voice interface

## Support

For issues or questions:
1. Check logs: `make logs`
2. Verify health: `make status`
3. Review documentation in `/docs`
4. Check Prefect UI for workflow errors

## License

Proprietary - Internal use only

---

Built with ❤️ using Claude Code
