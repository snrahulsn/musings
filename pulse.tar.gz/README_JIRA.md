# JIRA Analytics Ingestor

This ingestor pulls comprehensive JIRA data incrementally into PostgreSQL for operational metrics tracking.

## Available Data Sources

### 1. Projects (`jira_projects`)
**Project metadata:**
- Project key, ID, name
- Project type (software, business, service_desk)
- Project lead
- Description and URL

### 2. Users (`jira_users`)
**User profiles:**
- Account ID, email, display name
- Active status
- Time zone
- Account type (atlassian, app, customer)

### 3. Issues (`jira_issues`)
**Complete ticket data:**
- Issue key, type, summary, description
- Status, priority, resolution
- Assignee, reporter, creator
- Created/updated/resolved timestamps
- Due dates
- Parent/epic relationships
- Story points
- Time tracking (original estimate, remaining, time spent)
- Labels, components, fix versions

### 4. Issue Changelog (`jira_issue_changelog`)
**History of all changes:**
- Status transitions
- Assignee changes
- Priority updates
- Field modifications
- Author and timestamp for each change

### 5. Comments (`jira_comments`)
**Issue discussions:**
- Comment body and author
- Created/updated timestamps
- Full comment thread

### 6. Worklogs (`jira_worklogs`)
**Time tracking:**
- Time spent (in seconds)
- Work started timestamp
- Author and comments
- Work log history

### 7. Boards (`jira_boards`)
**Scrum and Kanban boards:**
- Board name, type (scrum/kanban)
- Associated project
- Board configuration

### 8. Sprints (`jira_sprints`)
**Sprint data:**
- Sprint name, state (future/active/closed)
- Start/end/complete dates
- Sprint goal
- Associated board

### 9. Sprint Issues (`jira_sprint_issues`)
**Issues in sprints:**
- Sprint-to-issue mappings
- When issues were added to sprints

### 10. Issue Links (`jira_issue_links`)
**Relationships between issues:**
- Link types (Blocks, Clones, Duplicates, Relates)
- Inward and outward relationships

### 11. Attachments (`jira_attachments`)
**File attachments metadata:**
- Filename, size, MIME type
- Author and creation timestamp
- Content URL

## Setup

### 1. Get JIRA API Token

1. Go to https://id.atlassian.com/manage-profile/security/api-tokens
2. Click "Create API token"
3. Give it a name (e.g., "Pulse Chatbot")
4. Copy the token immediately (you won't see it again)

### 2. Configure Environment

Add to `.env`:

```bash
# JIRA Configuration
JIRA_URL=https://your-domain.atlassian.net
JIRA_EMAIL=your-email@company.com
JIRA_API_TOKEN=your_api_token_here

# Optional: Filter specific projects (comma-separated)
JIRA_PROJECT_KEYS=PROJ1,PROJ2,PROJ3
```

### 3. Load Schema

```bash
# Schema is loaded automatically by Docker, or manually:
psql -d pulse -f schema/jira_schema.sql
```

### 4. Run First Sync

```bash
# Manual run
source venv/bin/activate
python ingestors/jira_ingestor.py

# Or via Makefile
make run-jira-sync
```

## Usage

### Manual Sync

```bash
python ingestors/jira_ingestor.py
```

### Via Prefect (Recommended)

```bash
# Deploy flows (includes JIRA)
python deploy_flows.py

# Or via Makefile
make deploy-flows
```

**Scheduled runs:**
- **Incremental sync**: Every 2 hours
- **Full sync**: Daily at 3 AM UTC

### Filter Specific Projects

```bash
# In .env
JIRA_PROJECT_KEYS=PROJ1,PROJ2

# Then run ingestor
python ingestors/jira_ingestor.py
```

## Data Flow

```
JIRA Cloud API
    ↓
┌───────────────────────────────────┐
│   jira_ingestor.py                │
│                                   │
│  1. Check last_sync_timestamp     │
│  2. Build JQL for updates         │
│  3. Fetch issues (paginated)      │
│  4. Process changelog/comments    │
│  5. Fetch boards/sprints          │
│  6. Upsert to PostgreSQL          │
│  7. Update sync_metadata          │
└───────────────────────────────────┘
    ↓
PostgreSQL Tables
├── jira_projects
├── jira_users
├── jira_issues
├── jira_issue_changelog
├── jira_comments
├── jira_worklogs
├── jira_boards
├── jira_sprints
├── jira_sprint_issues
├── jira_issue_links
├── jira_attachments
└── jira_sync_metadata
```

## Incremental Sync Strategy

The ingestor uses **JQL-based incremental sync**:

1. **First run**: Fetches all issues updated in last 365 days
2. **Subsequent runs**: Only fetches issues updated since last sync
3. **Lookback overlap**: Goes back 7-30 days to catch late updates
4. **Upsert logic**: Uses `ON CONFLICT` to handle duplicates
5. **Changelog tracking**: Processes full changelog for each updated issue

## Example Queries

### Cycle Time Analysis

```sql
-- Average time from "In Progress" to "Done" by project
WITH status_changes AS (
    SELECT
        i.issue_key,
        i.project_key,
        i.issue_type,
        MAX(CASE WHEN c.to_string = 'In Progress' THEN c.created_at END) as started_at,
        MAX(CASE WHEN c.to_string = 'Done' THEN c.created_at END) as completed_at
    FROM jira_issues i
    JOIN jira_issue_changelog c ON i.issue_key = c.issue_key
    WHERE c.field_name = 'status'
    GROUP BY i.issue_key, i.project_key, i.issue_type
)
SELECT
    project_key,
    issue_type,
    COUNT(*) as issues,
    AVG(EXTRACT(EPOCH FROM (completed_at - started_at))/3600) as avg_hours_to_complete
FROM status_changes
WHERE started_at IS NOT NULL AND completed_at IS NOT NULL
GROUP BY project_key, issue_type
ORDER BY avg_hours_to_complete DESC;
```

### Sprint Velocity

```sql
-- Story points completed per sprint
SELECT
    s.sprint_name,
    s.state,
    COUNT(DISTINCT si.issue_key) as issues_count,
    SUM(i.story_points) as total_story_points,
    s.start_date,
    s.end_date
FROM jira_sprints s
LEFT JOIN jira_sprint_issues si ON s.sprint_id = si.sprint_id
LEFT JOIN jira_issues i ON si.issue_key = i.issue_key AND i.status = 'Done'
WHERE s.state = 'closed'
GROUP BY s.sprint_id, s.sprint_name, s.state, s.start_date, s.end_date
ORDER BY s.start_date DESC
LIMIT 10;
```

### Team Workload

```sql
-- Current open issues by assignee
SELECT
    u.display_name,
    i.project_key,
    COUNT(*) as open_issues,
    SUM(i.story_points) as total_story_points,
    SUM(i.remaining_estimate_seconds)/3600 as remaining_hours
FROM jira_issues i
JOIN jira_users u ON i.assignee_account_id = u.account_id
WHERE i.status NOT IN ('Done', 'Closed', 'Resolved')
GROUP BY u.display_name, i.project_key
ORDER BY open_issues DESC;
```

### Issue Flow (Linked Issues)

```sql
-- Find all issues blocked by PROJ-123
WITH RECURSIVE blocked_issues AS (
    -- Start with the issue
    SELECT
        'PROJ-123' as issue_key,
        0 as depth

    UNION ALL

    -- Recursively find blocked issues
    SELECT
        l.outward_issue_key,
        bi.depth + 1
    FROM blocked_issues bi
    JOIN jira_issue_links l ON bi.issue_key = l.inward_issue_key
    WHERE l.link_type = 'Blocks'
      AND bi.depth < 5  -- Prevent infinite recursion
)
SELECT
    bi.issue_key,
    bi.depth,
    i.summary,
    i.status,
    i.assignee_account_id
FROM blocked_issues bi
JOIN jira_issues i ON bi.issue_key = i.issue_key
ORDER BY bi.depth;
```

### Work Log Summary

```sql
-- Time spent by user over last 30 days
SELECT
    u.display_name,
    COUNT(DISTINCT w.issue_key) as issues_worked_on,
    SUM(w.time_spent_seconds)/3600 as total_hours,
    AVG(w.time_spent_seconds)/3600 as avg_hours_per_log
FROM jira_worklogs w
JOIN jira_users u ON w.author_account_id = u.account_id
WHERE w.started_at >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY u.display_name
ORDER BY total_hours DESC;
```

## Cross-Source Analytics

### Link JIRA to Windsurf

```sql
-- Windsurf usage by developers working on specific JIRA tickets
SELECT
    ju.display_name,
    ji.issue_key,
    ji.summary,
    SUM(wcl.lines_accepted) as windsurf_lines_accepted,
    COUNT(DISTINCT wcl.day) as days_active_in_windsurf
FROM jira_issues ji
JOIN jira_users ju ON ji.assignee_account_id = ju.account_id
LEFT JOIN windsurf_cascade_lines wcl
    ON ju.email = wcl.email
    AND wcl.day BETWEEN ji.created_at::date AND COALESCE(ji.resolved_at::date, CURRENT_DATE)
WHERE ji.project_key = 'PROJ'
  AND ji.created_at >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY ju.display_name, ji.issue_key, ji.summary
ORDER BY windsurf_lines_accepted DESC NULLS LAST;
```

## Monitoring

### Check Sync Status

```bash
make sync-status

# Or directly:
psql -d pulse -c "SELECT * FROM jira_sync_metadata ORDER BY updated_at DESC;"
```

### View Logs

```bash
tail -f logs/jira_flow.log

# Or in Grafana (Loki)
{app="jira"}
{app="jira"} |= "error"
```

### Database Statistics

```bash
make stats

# Or:
psql -d pulse -c "
SELECT 'jira_issues' as table_name, COUNT(*) FROM jira_issues
UNION ALL
SELECT 'jira_comments', COUNT(*) FROM jira_comments
UNION ALL
SELECT 'jira_worklogs', COUNT(*) FROM jira_worklogs
UNION ALL
SELECT 'jira_sprints', COUNT(*) FROM jira_sprints;
"
```

## Troubleshooting

### Authentication Errors

- Verify JIRA_URL includes `https://` and ends with `.atlassian.net`
- Check API token hasn't expired
- Ensure email matches the Atlassian account

### No Data Returned

- Check `JIRA_PROJECT_KEYS` filter (remove to sync all projects)
- Verify you have access to the projects
- Check date range (default: last 365 days)

### Rate Limiting

JIRA Cloud has rate limits:
- 300 requests per minute for search
- Adjust pagination size if hitting limits

### Changelog Truncation

JIRA API returns max 100 changelog entries per issue. For issues with >100 changes, some history may be missing.

## Performance

**Expected data volumes (100 users, 10 projects, 1 year):**

| Table | Rows | Est. Size |
|-------|------|-----------|
| jira_projects | 10 | < 1 MB |
| jira_users | 100 | < 1 MB |
| jira_issues | 10,000 | ~50 MB |
| jira_issue_changelog | 100,000 | ~100 MB |
| jira_comments | 20,000 | ~50 MB |
| jira_worklogs | 30,000 | ~20 MB |
| jira_boards | 20 | < 1 MB |
| jira_sprints | 100 | < 1 MB |
| jira_sprint_issues | 5,000 | ~5 MB |
| jira_issue_links | 5,000 | ~5 MB |
| jira_attachments | 10,000 | ~10 MB |
| **Total** | **~180K rows** | **~242 MB** |

**Sync times:**
- First run (1 year): 30-60 minutes
- Incremental (hourly): 1-5 minutes

## Next Steps

After JIRA data is ingested:
1. Build similar ingestors for GitHub and Freshdesk
2. Create cross-source analytics queries
3. Implement text-to-SQL with Vanna
4. Build Chainlit chat interface
5. Add Grafana dashboards for JIRA metrics

## API References

- [JIRA Cloud REST API](https://developer.atlassian.com/cloud/jira/platform/rest/v3/)
- [JIRA Software REST API (Sprints)](https://developer.atlassian.com/cloud/jira/software/rest/)
- [Python JIRA Library](https://jira.readthedocs.io/)
