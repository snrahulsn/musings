# Pulse Deployment Checklist

Use this checklist when deploying Pulse to a new system.

## Pre-Deployment

- [ ] System has Docker and Docker Compose installed
- [ ] System has Python 3.11+ installed
- [ ] System has sufficient resources:
  - [ ] 8GB+ RAM
  - [ ] 20GB+ free disk space
  - [ ] 4+ CPU cores recommended
- [ ] All API keys are ready (see API_KEYS_SETUP.md)
- [ ] Network ports are available:
  - [ ] 5434 (PostgreSQL)
  - [ ] 6333, 6334 (Qdrant)
  - [ ] 6380 (Redis)
  - [ ] 11434 (Ollama)
  - [ ] 4200 (Prefect)
  - [ ] 3000 (Grafana)
  - [ ] 3100 (Loki)
  - [ ] 8000 (Chainlit UI)

## Deployment Steps

### 1. Extract Archive
```bash
tar -xzf pulse.tar.gz
cd pulse_final
```

### 2. Configure Environment
```bash
# Copy example env file
cp .env.example .env

# Edit with your API keys
nano .env  # or vim, code, etc.
```

**Required: Fill in at minimum:**
- `ANTHROPIC_API_KEY` (required for query engine)
- Data source API keys (as needed)
- Change default passwords (`DB_PASSWORD`, `GRAFANA_PASSWORD`)

### 3. Create Virtual Environment
```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 4. Start Infrastructure
```bash
# Start all Docker services
docker compose up -d

# Wait for services to be healthy (~30 seconds)
sleep 30

# Verify all services are running
docker compose ps
```

Expected output: All services should show "Up" status.

### 5. Create Database Schemas
```bash
# Schemas are created automatically via Docker init
# Or manually:
for schema in schema/*.sql; do
  docker exec -i pulse_postgres psql -U pulse_user -d pulse < "$schema"
done
```

### 6. Pull Ollama Model
```bash
docker exec pulse_ollama ollama pull nomic-embed-text
```

This downloads ~300MB and takes 1-2 minutes.

### 7. Initialize Pulse
```bash
# Activate venv if not already active
source venv/bin/activate

# Run setup script
python setup_pulse.py
```

This will:
- Validate environment variables
- Check Docker services
- Create schemas (if not already done)
- Train Vanna on schemas
- Create Qdrant collections
- Run health checks

### 8. Deploy Workflows (Optional)
```bash
# For automatic scheduled data sync
python deploy_flows.py
```

Leave this running in a terminal or use `nohup`:
```bash
nohup python deploy_flows.py > logs/deploy_flows.log 2>&1 &
```

### 9. Run Initial Data Sync (Optional)
```bash
# Only if you want to populate data immediately
# Otherwise, scheduled workflows will handle it

# Windsurf
python ingestors/windsurf_ingestor.py

# JIRA
python ingestors/jira_ingestor.py

# GitHub
python ingestors/github_ingestor.py

# Freshdesk
python ingestors/freshdesk_ingestor.py
```

### 10. Start Chat UI
```bash
# Activate venv if not already active
source venv/bin/activate

# Start Chainlit UI
chainlit run app.py -w
```

Or in background:
```bash
nohup chainlit run app.py -w > logs/chainlit.log 2>&1 &
```

### 11. Verify Deployment
```bash
# Check all services
curl http://localhost:6333/health  # Qdrant
curl http://localhost:11434/api/version  # Ollama
curl http://localhost:4200/api/health  # Prefect
curl http://localhost:3000/api/health  # Grafana

# Check database
docker exec pulse_postgres psql -U pulse_user -d pulse -c "\dt" | grep -c windsurf

# Access UIs
# Chainlit: http://localhost:8000
# Prefect: http://localhost:4200
# Grafana: http://localhost:3000 (admin/admin)
```

## Post-Deployment

### Security Hardening

- [ ] Changed all default passwords
- [ ] API keys stored securely (not in .env for production)
- [ ] Enabled HTTPS/TLS for all services
- [ ] Configured firewall rules
- [ ] Set up automated backups
- [ ] Enabled authentication on Chainlit UI
- [ ] Reviewed and restricted network access

### Monitoring Setup

- [ ] Grafana dashboards configured
- [ ] Loki log retention set appropriately
- [ ] Alerts configured for:
  - [ ] Service failures
  - [ ] Data ingestion errors
  - [ ] Database disk usage
  - [ ] API rate limits
- [ ] Backup verification process in place

### Data Ingestion

- [ ] Verified all data source credentials
- [ ] Tested manual ingestion for each source
- [ ] Confirmed scheduled workflows are running
- [ ] Checked Prefect UI for successful runs
- [ ] Reviewed sync metadata tables

### Query Engine

- [ ] Vanna trained on all schemas
- [ ] Qdrant collections created
- [ ] Tested SQL query generation
- [ ] Tested similarity search
- [ ] Verified query router classification

### Documentation

- [ ] Team trained on using Pulse
- [ ] Runbook created for common issues
- [ ] On-call procedures documented
- [ ] Backup/restore procedures tested

## Troubleshooting

### Services won't start
```bash
# Check Docker
docker ps
docker compose logs

# Check ports
netstat -tuln | grep -E '(5434|6333|6380|11434|4200|3000|8000)'

# Restart services
docker compose down
docker compose up -d
```

### Database connection errors
```bash
# Check PostgreSQL
docker exec pulse_postgres pg_isready -U pulse_user

# Check logs
docker compose logs postgres

# Reset database (WARNING: deletes data)
docker compose down -v
docker compose up -d
```

### Vanna initialization fails
```bash
# Check Anthropic API key
echo $ANTHROPIC_API_KEY

# Check PostgreSQL connection
python -c "import psycopg2; psycopg2.connect(host='localhost', port=5434, database='pulse', user='pulse_user', password='pulse_password')"

# Retry training
python query_engine/vanna_config.py
```

### Ollama model not found
```bash
# Check model list
docker exec pulse_ollama ollama list

# Pull model again
docker exec pulse_ollama ollama pull nomic-embed-text
```

### Ingestion failing
```bash
# Check API credentials in .env
cat .env | grep API

# Test connection manually
python -c "import requests; print(requests.get('https://api.github.com', headers={'Authorization': 'token YOUR_TOKEN'}).status_code)"

# Check logs
tail -f logs/windsurf_flow.log
tail -f logs/jira_flow.log
```

## Rollback Procedure

If deployment fails:

1. **Stop all services:**
   ```bash
   docker compose down
   ```

2. **Restore from backup (if applicable):**
   ```bash
   cat backups/pulse_backup_YYYYMMDD_HHMMSS.sql | docker exec -i pulse_postgres psql -U pulse_user pulse
   ```

3. **Revert to previous version:**
   ```bash
   cd ..
   tar -xzf pulse_previous_version.tar.gz
   cd pulse_final
   ```

4. **Restart services:**
   ```bash
   docker compose up -d
   ```

## Production Best Practices

1. **Use orchestration:** Deploy with Kubernetes or Docker Swarm for high availability
2. **Separate databases:** Use managed PostgreSQL (RDS, Cloud SQL) instead of containerized
3. **Load balancing:** Put Chainlit UI behind load balancer (NGINX, ALB)
4. **Secrets management:** Use Vault, AWS Secrets Manager, or similar
5. **Monitoring:** Integrate with Datadog, New Relic, or Prometheus
6. **Backups:** Automated daily backups with off-site replication
7. **Disaster recovery:** Regular DR drills
8. **CI/CD:** Automate deployments with GitHub Actions, GitLab CI, etc.

## Support

- Documentation: README_FINAL.md
- Quick start: QUICKSTART_FULL.md
- API keys: API_KEYS_SETUP.md
- Implementation details: IMPLEMENTATION_SUMMARY.md
- Schemas: SCHEMAS_SUMMARY.md

## Deployment Complete! ✅

When all items are checked, your Pulse deployment is complete and ready for use.

Access the chat UI at http://localhost:8000 and start querying your operational metrics!
