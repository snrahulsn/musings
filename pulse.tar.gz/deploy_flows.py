"""
Deploy Prefect flows and schedules

This script deploys all Prefect flows with their schedules to the Prefect server.
"""

from prefect import serve
from prefect.client.schemas.schedules import CronSchedule
from flows.windsurf_flow import windsurf_incremental_flow, windsurf_sync_flow
from flows.jira_flow import jira_incremental_flow, jira_sync_flow
from flows.github_flow import github_incremental_flow, github_sync_flow
from flows.freshdesk_flow import freshdesk_incremental_flow, freshdesk_sync_flow
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def deploy_flows():
    """Deploy all flows with schedules"""

    logger.info("Deploying Prefect flows...")

    # ========== Windsurf Flows ==========
    windsurf_incremental_deployment = windsurf_incremental_flow.to_deployment(
        name="windsurf-incremental-hourly",
        description="Incremental Windsurf data sync (runs every hour)",
        schedules=[
            CronSchedule(cron="0 * * * *", timezone="UTC")  # Every hour
        ],
        tags=["windsurf", "incremental", "hourly"],
        parameters={"emails": None}
    )

    windsurf_full_deployment = windsurf_sync_flow.to_deployment(
        name="windsurf-full-daily",
        description="Full Windsurf data sync (runs daily at 2 AM UTC)",
        schedules=[
            CronSchedule(cron="0 2 * * *", timezone="UTC")  # Daily at 2 AM
        ],
        tags=["windsurf", "full", "daily"],
        parameters={"emails": None, "lookback_days": 7}
    )

    logger.info("✅ Windsurf flows deployed")
    logger.info("   - Incremental sync: Every hour")
    logger.info("   - Full sync: Daily at 2 AM UTC")

    # ========== JIRA Flows ==========
    jira_incremental_deployment = jira_incremental_flow.to_deployment(
        name="jira-incremental-hourly",
        description="Incremental JIRA data sync (runs every 2 hours)",
        schedules=[
            CronSchedule(cron="0 */2 * * *", timezone="UTC")  # Every 2 hours
        ],
        tags=["jira", "incremental", "hourly"],
        parameters={"project_keys": None}
    )

    jira_full_deployment = jira_sync_flow.to_deployment(
        name="jira-full-daily",
        description="Full JIRA data sync (runs daily at 3 AM UTC)",
        schedules=[
            CronSchedule(cron="0 3 * * *", timezone="UTC")  # Daily at 3 AM
        ],
        tags=["jira", "full", "daily"],
        parameters={"project_keys": None, "lookback_days": 30}
    )

    logger.info("✅ JIRA flows deployed")
    logger.info("   - Incremental sync: Every 2 hours")
    logger.info("   - Full sync: Daily at 3 AM UTC")

    # ========== GitHub Flows ==========
    github_incremental_deployment = github_incremental_flow.to_deployment(
        name="github-incremental-2hourly",
        description="Incremental GitHub data sync (runs every 2 hours)",
        schedules=[
            CronSchedule(cron="15 */2 * * *", timezone="UTC")  # Every 2 hours at :15
        ],
        tags=["github", "incremental", "2hourly"],
        parameters={"repo_names": None}
    )

    github_full_deployment = github_sync_flow.to_deployment(
        name="github-full-daily",
        description="Full GitHub data sync (runs daily at 4 AM UTC)",
        schedules=[
            CronSchedule(cron="0 4 * * *", timezone="UTC")  # Daily at 4 AM
        ],
        tags=["github", "full", "daily"],
        parameters={"repo_names": None, "lookback_days": 90}
    )

    logger.info("✅ GitHub flows deployed")
    logger.info("   - Incremental sync: Every 2 hours at :15")
    logger.info("   - Full sync: Daily at 4 AM UTC")

    # ========== Freshdesk Flows ==========
    freshdesk_incremental_deployment = freshdesk_incremental_flow.to_deployment(
        name="freshdesk-incremental-2hourly",
        description="Incremental Freshdesk data sync (runs every 2 hours)",
        schedules=[
            CronSchedule(cron="30 */2 * * *", timezone="UTC")  # Every 2 hours at :30
        ],
        tags=["freshdesk", "incremental", "2hourly"],
        parameters={}
    )

    freshdesk_full_deployment = freshdesk_sync_flow.to_deployment(
        name="freshdesk-full-daily",
        description="Full Freshdesk data sync (runs daily at 5 AM UTC)",
        schedules=[
            CronSchedule(cron="0 5 * * *", timezone="UTC")  # Daily at 5 AM
        ],
        tags=["freshdesk", "full", "daily"],
        parameters={"lookback_days": 90}
    )

    logger.info("✅ Freshdesk flows deployed")
    logger.info("   - Incremental sync: Every 2 hours at :30")
    logger.info("   - Full sync: Daily at 5 AM UTC")

    # Serve all deployments
    logger.info("\n" + "=" * 80)
    logger.info("Starting Prefect worker to serve all deployments...")
    logger.info("=" * 80)
    serve(
        windsurf_incremental_deployment,
        windsurf_full_deployment,
        jira_incremental_deployment,
        jira_full_deployment,
        github_incremental_deployment,
        github_full_deployment,
        freshdesk_incremental_deployment,
        freshdesk_full_deployment,
        limit=8  # Max 8 concurrent flow runs (2 per data source)
    )


if __name__ == '__main__':
    deploy_flows()
