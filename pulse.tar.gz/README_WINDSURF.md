# Windsurf Analytics Ingestor

This ingestor pulls user-level analytics data from Windsurf APIs incrementally into PostgreSQL.

## Available Data Sources

### 1. UserPageAnalytics API
**User profile and activity data:**
- Email, name, API key hash
- Active days count
- Last activity timestamps (autocomplete, chat, command)
- User access status

**Table:** `windsurf_users`

### 2. CascadeAnalytics API
**Cascade usage metrics:**

a) **Cascade Lines** (`windsurf_cascade_lines`)
   - Lines suggested per day
   - Lines accepted per day
   - Per user aggregation

b) **Cascade Runs** (`windsurf_cascade_runs`)
   - Model usage (which AI model)
   - Mode (DEFAULT, READ_ONLY, NO_TOOL)
   - Messages sent, prompts used
   - Cascade execution IDs

c) **Tool Usage** (`windsurf_cascade_tools`)
   - Tool identifiers (CODE_ACTION, VIEW_FILE, etc.)
   - Usage counts per tool

### 3. CustomAnalytics API

a) **Autocomplete Data** (`windsurf_autocomplete`)
   - Acceptances by language and IDE
   - Lines accepted
   - Per user, per day

b) **Chat Data** (`windsurf_chat`)
   - Chat interactions received
   - Chat acceptances
   - Insertions at cursor
   - Intent types (FUNCTION_DOCSTRING, etc.)
   - Model usage

c) **Command Data** (`windsurf_commands`)
   - Commands executed
   - Lines added/removed
   - Acceptance status
   - Command source and provider

d) **Code Written** (`windsurf_code_written`)
   - Percent code written by AI vs user
   - Bytes breakdown (autocomplete vs command)

## Setup

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Setup PostgreSQL Database

```bash
# Create database
createdb pulse

# Run schema
psql -d pulse -f schema/windsurf_schema.sql
```

### 3. Configure Environment

```bash
# Copy example config
cp .env.example .env

# Edit .env and add:
# - WINDSURF_SERVICE_KEY (from https://windsurf.com/team/team_settings)
# - DB_PASSWORD
# - Optional: WINDSURF_EMAILS for specific users
```

### 4. Obtain Windsurf Service Key

1. Go to [Windsurf Team Settings](https://windsurf.com/team/team_settings)
2. Create a service key as an admin user
3. Ensure your admin user has **"Teams Read-only"** permissions
4. Enable individual-level analytics at [Manage Team](https://windsurf.com/team/manage)

## Usage

### Run Full Sync

```bash
python ingestors/windsurf_ingestor.py
```

This will:
1. Fetch all available historical data (or from last sync)
2. Upsert into PostgreSQL tables
3. Track sync metadata for incremental runs

### Sync Specific Users

```bash
# In .env file:
WINDSURF_EMAILS=user1@company.com,user2@company.com

# Then run:
python ingestors/windsurf_ingestor.py
```

### Incremental Sync

The ingestor automatically tracks the last successful sync timestamp in `windsurf_sync_metadata` table. Subsequent runs will only fetch new data.

**Lookback overlap:** By default, the script looks back 7 days to catch late-arriving data.

## Data Flow

```
Windsurf APIs
    ↓
┌─────────────────────────────────────┐
│   windsurf_ingestor.py              │
│                                     │
│  1. Check last_sync_timestamp       │
│  2. Fetch incremental data          │
│  3. Upsert to PostgreSQL            │
│  4. Update sync_metadata            │
└─────────────────────────────────────┘
    ↓
PostgreSQL Tables
├── windsurf_users
├── windsurf_cascade_lines
├── windsurf_cascade_runs
├── windsurf_cascade_tools
├── windsurf_autocomplete
├── windsurf_chat
├── windsurf_commands
├── windsurf_code_written
└── windsurf_sync_metadata
```

## Scheduling (Future)

To run automatically, add to cron:

```bash
# Run every hour
0 * * * * cd /path/to/pulse_final && /path/to/venv/bin/python ingestors/windsurf_ingestor.py >> logs/windsurf_sync.log 2>&1
```

Or use APScheduler (integration coming soon).

## Key Features

✅ **Incremental sync** - Only fetches new data after first run
✅ **User-level data** - All metrics tracked per user
✅ **Idempotent** - Safe to re-run, uses upserts
✅ **Error tracking** - Sync metadata logs failures
✅ **Lookback overlap** - Catches late-arriving data
✅ **Email filtering** - Optional per-user sync

## Troubleshooting

### Authentication Errors
- Verify `WINDSURF_SERVICE_KEY` is correct
- Ensure admin user has "Teams Read-only" permissions
- Check service key hasn't expired

### No Data Returned
- Verify individual-level analytics is enabled at https://windsurf.com/team/manage
- Check date range (API may have data retention limits)
- Try running without email filters first

### Database Errors
- Ensure schema is created: `psql -d pulse -f schema/windsurf_schema.sql`
- Check database connection parameters
- Verify PostgreSQL version >= 12

## API Rate Limits

Windsurf APIs may have rate limits. The ingestor includes:
- 30-second timeout per request
- Error handling and retry metadata
- Incremental sync to minimize API calls

## Next Steps

After Windsurf data is ingested, you can:
1. Build similar ingestors for JIRA, GitHub, Freshdesk
2. Query the data with SQL
3. Build analytics dashboards
4. Implement the chatbot with Vanna + Qdrant

## Schema Reference

See [windsurf_schema.sql](schema/windsurf_schema.sql) for complete table definitions, indexes, and constraints.
