# Pulse Quick Start Guide 🚀

Get Pulse up and running in 10 minutes!

## Prerequisites Checklist

- [ ] Docker Desktop installed and running
- [ ] Python 3.11+ installed
- [ ] Git installed
- [ ] API keys ready:
  - [ ] Anthropic Claude API key
  - [ ] Windsurf service key
  - [ ] JIRA credentials (URL, email, API token)
  - [ ] GitHub personal access token
  - [ ] Freshdesk API key

## Step-by-Step Setup

### 1. Environment Setup (2 minutes)

```bash
# Navigate to project directory
cd /Users/rahulnatarajan/Documents/pulse_final

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install Python dependencies
pip install -r requirements.txt
```

### 2. Configure API Keys (2 minutes)

```bash
# Copy example environment file
cp .env.example .env

# Edit .env with your credentials
nano .env  # or use any text editor
```

**Required variables:**
```bash
# LLM
ANTHROPIC_API_KEY=sk-ant-...

# Windsurf
WINDSURF_SERVICE_KEY=your_windsurf_key

# JIRA
JIRA_URL=https://yourcompany.atlassian.net
JIRA_EMAIL=you@company.com
JIRA_API_TOKEN=your_jira_token

# GitHub
GITHUB_TOKEN=ghp_...
GITHUB_ORG=your-org-name

# Freshdesk
FRESHDESK_DOMAIN=yourcompany.freshdesk.com
FRESHDESK_API_KEY=your_freshdesk_key

# Database (can leave as default)
DB_PASSWORD=pulse_password
```

### 3. Start Infrastructure (3 minutes)

```bash
# Start all Docker services
make start

# This will start:
# - PostgreSQL (database)
# - Qdrant (vector search)
# - Ollama (embeddings)
# - Redis (cache)
# - Prefect (workflow orchestration)
# - Loki + Promtail (logging)
# - Grafana (monitoring)

# Wait ~30 seconds for services to be healthy, then check status
make status
```

**Expected output:**
```
  ✅ Qdrant:   Running
  ✅ Prefect:  Running
  ✅ Grafana:  Running
  ✅ Loki:     Running
  ✅ Postgres: Running
```

### 4. Pull Embedding Model (1 minute)

```bash
# Pull Ollama model for vector embeddings
make setup-ollama

# This will download nomic-embed-text (~300MB)
# May take 1-2 minutes depending on your connection
```

### 5. Initialize Pulse (2 minutes)

```bash
# Create database schemas, train Vanna, setup Qdrant
make setup-pulse

# This will:
# - Create all 50 database tables
# - Train Vanna on your schemas
# - Create Qdrant vector collections
# - Run health checks
```

**Expected output:**
```
✅ All schemas created
✅ Vanna setup complete
✅ Qdrant collections created

HEALTH CHECK SUMMARY
PostgreSQL: ✅ HEALTHY
Qdrant: ✅ HEALTHY
Ollama: ✅ HEALTHY
Redis: ✅ HEALTHY
Prefect: ✅ HEALTHY
```

### 6. Deploy Workflows (Optional - 1 minute)

```bash
# Deploy Prefect flows for automatic data sync
make deploy-flows

# This starts a background process that runs:
# - Hourly incremental syncs
# - Daily full syncs
```

**Note:** You can skip this and run manual syncs instead.

### 7. Run Initial Data Sync (Optional)

```bash
# Run first sync to populate data
# (or wait for scheduled sync if you deployed flows)
make run-sync

# This will sync Windsurf data
# For other sources, run:
./venv/bin/python ingestors/jira_ingestor.py
./venv/bin/python ingestors/github_ingestor.py
./venv/bin/python ingestors/freshdesk_ingestor.py
```

### 8. Start Chat UI

```bash
# Launch Chainlit interface
make run-ui

# The UI will open at http://localhost:8000
```

## Testing Your Setup

### Test SQL Query

In the Chainlit UI, ask:
```
How many records are in the database?
```

Expected response:
- SQL query shown
- Results table with counts
- Execution time

### Test Similarity Search

Ask:
```
Find JIRA tickets similar to authentication issues
```

Expected response:
- Collection searched
- Top 10 similar items with scores
- Item details (issue key, summary, etc.)

## Quick Commands Reference

```bash
# Start everything
make start

# Check status
make status

# View logs
make logs

# Open monitoring
make monitor

# Start chat UI
make run-ui

# Manual sync
make run-sync

# Database shell
make db-shell

# Stop everything
make stop
```

## Troubleshooting

### "Port already in use"
```bash
# Stop conflicting services
docker ps  # Find conflicting containers
docker stop <container_id>

# Or use different ports in docker-compose.yml
```

### "Cannot connect to Docker"
```bash
# Start Docker Desktop
# Wait for it to fully start
# Try again: make start
```

### "Database connection failed"
```bash
# Check if PostgreSQL is running
docker ps | grep postgres

# Check logs
make logs-postgres

# Restart if needed
docker restart pulse_postgres
```

### "Vanna training failed"
```bash
# Check Anthropic API key
echo $ANTHROPIC_API_KEY

# Retry training
make train-vanna
```

### "Ollama model not found"
```bash
# Pull model again
make setup-ollama

# Verify model
docker exec pulse_ollama ollama list
```

## Next Steps

### 1. Explore Monitoring
```bash
# Open Grafana
make grafana-ui
# Login: admin/admin
# Explore PostgreSQL and Loki dashboards

# Open Prefect
make prefect-ui
# View workflow runs and schedules
```

### 2. Customize Training

Edit `query_engine/vanna_config.py` to add your own Q&A examples:

```python
("Your question?", "SELECT ...")
```

Then retrain:
```bash
make train-vanna
```

### 3. Index More Data

After running syncs, index data for similarity search:
```bash
make index-qdrant
```

### 4. Backup Data

```bash
# Create backup
make db-backup

# Backups saved to backups/ directory
```

## Configuration Tips

### Adjust Sync Schedules

Edit `deploy_flows.py`:
```python
CronSchedule(cron="0 * * * *", timezone="UTC")  # Every hour
CronSchedule(cron="0 */2 * * *", timezone="UTC")  # Every 2 hours
CronSchedule(cron="0 0 * * *", timezone="UTC")  # Daily at midnight
```

### Filter Data Sources

**Windsurf - specific users:**
```bash
# In .env
WINDSURF_EMAILS=user1@company.com,user2@company.com
```

**JIRA - specific projects:**
```python
# When calling flow
jira_sync_flow(project_keys=['PROJ1', 'PROJ2'])
```

**GitHub - specific repos:**
```python
# When calling flow
github_sync_flow(repo_names=['repo1', 'repo2'])
```

## Common Use Cases

### Daily Standup Report

Ask Pulse:
```
Show me what each developer worked on yesterday
```

### Sprint Review

```
What issues were completed in the last sprint?
How many story points were completed?
```

### PR Review Metrics

```
What is the average PR review time by repository?
Who has the most pending PR reviews?
```

### Support Ticket Analysis

```
How many high priority support tickets are open?
What is the average first response time?
```

### Code Activity

```
How many lines of code were written this week?
Which files had the most changes?
```

## Production Deployment Tips

1. **Use strong passwords** in .env
2. **Enable HTTPS** for all services
3. **Set up automated backups** (daily)
4. **Configure log retention** (30 days recommended)
5. **Monitor disk usage** (database + logs)
6. **Set resource limits** in docker-compose.yml
7. **Enable authentication** on all UIs
8. **Use secrets management** (not .env files)

## Getting Help

1. Check logs: `make logs`
2. Check status: `make status`
3. Review README_FINAL.md for detailed docs
4. Check Prefect UI for workflow errors
5. Check Grafana for metrics and logs

---

**You're all set! 🎉**

Start asking questions in the Chainlit UI and explore your operational metrics!
