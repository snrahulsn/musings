# API Keys Configuration Guide

## Where to Configure API Keys

All API keys for data ingestion and LLM services must be configured in the `.env` file located in the project root directory.

### Setup Steps

1. **Copy the example file:**
   ```bash
   cp .env.example .env
   ```

2. **Edit the .env file:**
   ```bash
   nano .env  # or use any text editor
   ```

3. **Fill in the required API keys** (see sections below)

## Required API Keys

### 1. LLM Services (REQUIRED for Query Engine)

```bash
# Anthropic Claude API Key
# Get from: https://console.anthropic.com/
ANTHROPIC_API_KEY=sk-ant-api03-your_key_here
```

**Used for:**
- Text-to-SQL generation (Vanna)
- Query routing and classification
- SQL query optimization

### 2. Windsurf (Optional - for Windsurf data ingestion)

```bash
# Windsurf Service Key
# Get from: Windsurf dashboard > API Settings
WINDSURF_SERVICE_KEY=your_windsurf_service_key
```

**Used for:**
- Pulling AI coding analytics
- Cascade runs, autocomplete stats, chat data
- Code writing metrics

### 3. JIRA (Optional - for JIRA data ingestion)

```bash
# JIRA Configuration
# Get API token from: https://id.atlassian.com/manage-profile/security/api-tokens
JIRA_URL=https://yourcompany.atlassian.net
JIRA_EMAIL=your.email@company.com
JIRA_API_TOKEN=your_jira_api_token_here
```

**Used for:**
- Pulling JIRA issues, sprints, boards
- Issue changelog and comments
- Custom fields
- Worklogs and attachments

### 4. GitHub (Optional - for GitHub data ingestion)

```bash
# GitHub Configuration
# Get token from: https://github.com/settings/tokens
# Required scopes: repo, read:org
GITHUB_TOKEN=ghp_your_github_token_here
GITHUB_ORG=your-organization-name
```

**Used for:**
- Pulling repositories, pull requests, issues
- PR reviews and comments
- Commits and releases
- Workflows and custom fields

### 5. Freshdesk (Optional - for Freshdesk data ingestion)

```bash
# Freshdesk Configuration
# Get API key from: Freshdesk Admin > Profile Settings > Your API Key
FRESHDESK_DOMAIN=yourcompany.freshdesk.com
FRESHDESK_API_KEY=your_freshdesk_api_key_here
```

**Used for:**
- Pulling support tickets
- Conversations and time entries
- Agent performance metrics
- Custom ticket fields

## Infrastructure Configuration (Pre-configured)

These are already set with working defaults in `.env.example`:

```bash
# PostgreSQL Database
DB_HOST=localhost
DB_PORT=5434
DB_NAME=pulse
DB_USER=pulse_user
DB_PASSWORD=pulse_password  # Change for production!

# Qdrant Vector Database
QDRANT_HOST=localhost
QDRANT_PORT=6333

# Redis Cache
REDIS_HOST=localhost
REDIS_PORT=6380

# Ollama Embeddings
OLLAMA_HOST=http://localhost:11434
EMBEDDING_MODEL=nomic-embed-text

# Prefect Orchestration
PREFECT_API_URL=http://localhost:4200/api

# Grafana Monitoring
GRAFANA_PASSWORD=admin  # Change for production!
```

## Minimal Setup (Just for Testing)

If you just want to test the UI and query engine without data ingestion, you only need:

```bash
# Minimum required for UI testing
ANTHROPIC_API_KEY=sk-ant-api03-your_key_here

# Infrastructure (use defaults)
DB_HOST=localhost
DB_PORT=5434
DB_PASSWORD=pulse_password
```

Then you can:
1. Start Docker services: `make start`
2. Create schemas: Run schema files
3. Start UI: `make run-ui`
4. Ask questions (results will be empty without data, but query generation works)

## Full Production Setup

For production with all data sources:

```bash
# 1. LLM (Required)
ANTHROPIC_API_KEY=sk-ant-api03-...

# 2. All Data Sources (for full ingestion)
WINDSURF_SERVICE_KEY=...
JIRA_URL=...
JIRA_EMAIL=...
JIRA_API_TOKEN=...
GITHUB_TOKEN=ghp_...
GITHUB_ORG=...
FRESHDESK_DOMAIN=...
FRESHDESK_API_KEY=...

# 3. Infrastructure (change passwords!)
DB_PASSWORD=<strong_password>
GRAFANA_PASSWORD=<strong_password>
```

## Validation

After configuring your `.env` file, validate it:

```bash
# Check environment variables are loaded
source .env
echo $ANTHROPIC_API_KEY  # Should show your key

# Or run the setup script which validates all keys
make setup-pulse
```

## Security Best Practices

1. **Never commit .env file to git** (already in .gitignore)
2. **Use strong passwords** for DB_PASSWORD and GRAFANA_PASSWORD
3. **Rotate API keys regularly** (every 90 days recommended)
4. **Use read-only API tokens** where possible (GitHub, JIRA)
5. **Limit API token scopes** to minimum required permissions
6. **Store production .env securely** (use secrets management like AWS Secrets Manager, HashiCorp Vault)

## API Key Permissions

### GitHub Token Scopes
Required:
- `repo` (for private repos) or `public_repo` (for public only)
- `read:org` (for organization access)

### JIRA API Token
Permissions:
- Read access to projects, issues, boards, sprints
- No write access needed

### Freshdesk API Key
Permissions:
- Read access to tickets, contacts, agents
- No write access needed

## Troubleshooting

### "ANTHROPIC_API_KEY not set"
**Solution:** Make sure .env file exists and contains `ANTHROPIC_API_KEY=sk-ant-...`

### "Failed to connect to JIRA"
**Solution:** Verify `JIRA_URL`, `JIRA_EMAIL`, and `JIRA_API_TOKEN` are correct

### "GitHub API rate limit exceeded"
**Solution:**
- Check your GitHub token is valid
- Authenticated tokens get 5000 req/hour vs 60 req/hour unauthenticated

### "Windsurf ingestion failing"
**Solution:** Verify `WINDSURF_SERVICE_KEY` is correct and has necessary permissions

## Next Steps

After configuring API keys:

1. **Start infrastructure:**
   ```bash
   make start
   ```

2. **Initialize Pulse:**
   ```bash
   make setup-pulse
   ```

3. **Deploy workflows (for automatic sync):**
   ```bash
   make deploy-flows
   ```

4. **Or run manual sync:**
   ```bash
   ./venv/bin/python ingestors/windsurf_ingestor.py
   ./venv/bin/python ingestors/jira_ingestor.py
   ./venv/bin/python ingestors/github_ingestor.py
   ./venv/bin/python ingestors/freshdesk_ingestor.py
   ```

5. **Start the UI:**
   ```bash
   make run-ui
   ```

## Support

For issues with API keys:
- Check `.env` file syntax (no spaces around =)
- Ensure quotes are not needed around values
- Verify keys are active in respective platforms
- Check logs: `make logs`
