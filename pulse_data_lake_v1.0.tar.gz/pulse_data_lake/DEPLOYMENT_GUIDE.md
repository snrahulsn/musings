# Pulse Data Lake - Deployment Guide

## What You're Getting

A complete operational metrics platform that:
- ✅ Fetches **ALL data** from GitHub, JIRA, Freshdesk, Windsurf (NO limits, NO restrictions)
- ✅ **ALL custom fields** dynamically discovered and captured
- ✅ 40+ predefined analytical queries
- ✅ Smart intent classification (90% queries don't need LLM)
- ✅ GPT-4o/Claude fallback for complex queries
- ✅ OpenAI-compatible API (works with Open WebUI, LibreChat, etc.)
- ✅ All data joinable via normalized emails/issue keys
- ✅ Automatic rate limit handling with retry/sleep
- ✅ Comprehensive cross-reference extraction (JIRA keys, ticket IDs)

## Installation

### 1. Extract Package
```bash
tar -xzf pulse_data_lake.tar.gz
cd pulse_data_lake
```

### 2. Create Virtual Environment
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 3. Configure API Keys
```bash
cp config/config.example.yaml config/config.yaml
nano config/config.yaml  # Edit with your keys
```

Required:
- **GitHub**: Personal Access Token (repo scope)
- **JIRA**: Email + API Token
- **Freshdesk**: API Key
- **OpenAI**: API Key (for LLM fallback)

Optional:
- **Windsurf**: Service Key (Enterprise only)

### 4. Initialize Database
```bash
python -c "from db.database import init_db; init_db()"
```

### 5. Run Initial Sync (Test)
```bash
# Test with one source first
python -c "
from db.database import get_db
from config.settings import get_settings
from ingest.github_poller import GitHubPoller

config = get_settings()
db = get_db()

if config.sources.github.enabled:
    poller = GitHubPoller(db, config.sources.github.dict())
    result = poller.poll()
    print(f'Synced: {result}')
"
```

### 6. Start Server
```bash
python main.py
```

Server starts on http://localhost:8000

## Using with Open WebUI

1. Install Open WebUI:
```bash
docker run -d -p 3000:8080 \
  -e OPENAI_API_BASE_URL=http://host.docker.internal:8000/v1 \
  -e OPENAI_API_KEY=dummy \
  ghcr.io/open-webui/open-webui:main
```

2. Access http://localhost:3000
3. Select model "pulse-data-lake"
4. Ask questions like:
   - "How many PRs did john@example.com merge last month?"
   - "What's our team velocity?"
   - "Show me support ticket trends"

## Data Fetched

### GitHub (COMPREHENSIVE)
- ✅ All commits with full stats, file changes, verification
- ✅ All PRs with reviews, comments, labels, milestones
- ✅ All issues with comments, reactions
- ✅ All releases
- ✅ All workflow runs (GitHub Actions)
- ✅ Cross-references extracted (JIRA keys, ticket IDs)

### JIRA (COMPREHENSIVE)
- ✅ All issues with ALL fields + **ALL custom fields dynamically discovered**
- ✅ All worklogs (time tracking)
- ✅ All status transitions (changelog)
- ✅ All comments
- ✅ Sprint data, story points, estimates
- ✅ Components, labels, priorities, fix versions
- ✅ Attachments metadata with author tracking
- ✅ Resolution, environment, due dates
- ✅ Votes, watchers (engagement metrics)
- ✅ Automatic rate limit handling

### Freshdesk (COMPREHENSIVE)
- ✅ All tickets with ALL fields + **ALL custom fields dynamically discovered**
- ✅ All conversations (ticket responses, internal notes)
- ✅ All time entries (agent time tracking, billable/non-billable)
- ✅ SLA metrics (first response, resolution, escalation tracking)
- ✅ Source tracking (email, portal, phone, chat, social media)
- ✅ Company/contact associations
- ✅ Agent and group enrichment (email resolution for joins)
- ✅ Satisfaction ratings, spam/deleted indicators
- ✅ CC/FWD emails, attachments
- ✅ Associated tickets, product associations
- ✅ Automatic rate limit handling

### Windsurf (ALL METRICS)
- ✅ Comprehensive user activity metrics
- ✅ Chat metrics (prompts, messages, sessions, tokens, model used)
- ✅ Autocomplete metrics (suggestions, accepted, rejected, partial, characters)
- ✅ Command execution (Cascade, terminal, file operations)
- ✅ Code generation (lines generated/accepted/rejected, refactorings)
- ✅ Context metrics (files opened, projects, session duration, context switches)
- ✅ Language/framework usage tracking
- ✅ Performance (response times, error rates, success rates)
- ✅ Tool usage breakdown (Cascade tools, function calls)

## Join Keys

Data is joinable across:
- **Email addresses** (normalized to lowercase)
- **Issue keys** (PROJ-123 extracted from commits/PRs)
- **Ticket IDs** (TICKET-789 extracted from commits)
- **UTC timestamps** (normalized)

## Troubleshooting

### Rate Limits
GitHub poller automatically handles rate limits with retry/sleep.

### Database Locked
```bash
sqlite3 pulse_data.db "PRAGMA journal_mode=WAL;"
```

### Missing Data
Check watermarks:
```bash
python -c "
from db.database import get_db
db = get_db()
for source in ['github', 'jira', 'freshdesk']:
    wm = db.get_watermark(source)
    print(f'{source}: {wm}')
"
```

## Architecture

```
Data Sources → Pollers (incremental) → Raw Tables → Transformer → Unified Events → Query Engine → API
```

**No limits. No restrictions. All data.**
