"""
FastAPI Server - OpenAI-compatible chat endpoint

Compatible with:
- Open WebUI
- LibreChat
- Any OpenAI-compatible client
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import structlog
from datetime import datetime

from db.database import get_db
from chat.intent_classifier import classify_intent
from chat.gpt_fallback import create_llm_fallback
from config.settings import get_settings

logger = structlog.get_logger()
app = FastAPI(title="Pulse Data Lake API")

# CORS for web clients
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models for OpenAI compatibility
class Message(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    model: str = "pulse-data-lake"
    messages: List[Message]
    temperature: Optional[float] = 0.7
    max_tokens: Optional[int] = 1000

class ChatResponse(BaseModel):
    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[Dict[str, Any]]


@app.get("/")
async def root():
    return {"message": "Pulse Data Lake API", "version": "1.0.0"}


@app.get("/health")
async def health():
    """System health check"""
    db = get_db()

    sources = ["github", "jira", "freshdesk", "windsurf"]
    last_syncs = {}

    for source in sources:
        watermark = db.get_watermark(source)
        last_syncs[source] = watermark.get("last_sync_at")

    total_events = db.execute_query("SELECT COUNT(*) as count FROM unified_events")[0]["count"]

    return {
        "status": "healthy",
        "database": "connected",
        "total_events": total_events,
        "last_syncs": last_syncs
    }


@app.post("/v1/chat/completions", response_model=ChatResponse)
async def chat_completions(request: ChatRequest):
    """
    OpenAI-compatible chat completions endpoint

    Works with Open WebUI, LibreChat, etc.
    """
    try:
        # Get last user message
        user_message = next((m.content for m in reversed(request.messages) if m.role == "user"), None)
        if not user_message:
            raise HTTPException(status_code=400, detail="No user message found")

        logger.info("query_received", question=user_message)

        db = get_db()
        settings = get_settings()

        # 1. Try intent classifier
        query_template, params, confidence = classify_intent(user_message)

        answer = None
        sql_used = None
        method = "intent_classifier"

        if query_template and confidence >= 30:
            # Use predefined query
            logger.info("using_template", query_id=query_template.id, confidence=confidence)

            sql_used = query_template.sql_template
            results = db.execute_query(sql_used, params)

            # Format answer
            if results:
                answer = f"Query: {query_template.name}\n\n"
                answer += f"Found {len(results)} results:\n\n"
                for i, row in enumerate(results[:10], 1):
                    answer += f"{i}. {dict(row)}\n"
                if len(results) > 10:
                    answer += f"\n... and {len(results) - 10} more results"
            else:
                answer = "No results found for your query."

        elif settings.llm.enabled:
            # Fallback to LLM
            logger.info("using_llm_fallback")
            method = "llm_fallback"

            llm = create_llm_fallback(settings.llm.dict())
            sql_used, error = llm.generate_sql(user_message, params)

            if error:
                raise HTTPException(status_code=400, detail=f"Could not generate query: {error}")

            results = db.execute_query(sql_used)
            answer = llm.generate_explanation(sql_used, results)

        else:
            raise HTTPException(
                status_code=400,
                detail="Could not match query to template (confidence too low) and LLM fallback is disabled"
            )

        # Return OpenAI-compatible response
        return ChatResponse(
            id=f"chatcmpl-{datetime.now().timestamp()}",
            created=int(datetime.now().timestamp()),
            model=request.model,
            choices=[{
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": answer
                },
                "finish_reason": "stop"
            }]
        )

    except Exception as e:
        logger.error("query_failed", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/v1/models")
async def list_models():
    """List available models (OpenAI compatibility)"""
    return {
        "data": [
            {
                "id": "pulse-data-lake",
                "object": "model",
                "created": int(datetime.now().timestamp()),
                "owned_by": "pulse"
            }
        ]
    }
