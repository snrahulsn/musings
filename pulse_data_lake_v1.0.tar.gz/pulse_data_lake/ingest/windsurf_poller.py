"""
Windsurf Analytics API Poller - Comprehensive AI coding assistant metrics

Fetches ALL available metrics:
- User activity (prompts, messages, autocomplete, commands)
- Tool usage (Cascade tools, functions called)
- Session data (time spent, context switches)
- Code generation metrics (lines accepted, suggestions)
- Language/framework usage
- Performance metrics

NO LIMITS - Fetches ALL data

Join keys:
- User email addresses (normalized)
"""

import requests
from typing import Dict, Any, List
from datetime import datetime, timedelta
import json
import structlog

from ingest.base import BasePoller
from db.database import Database

logger = structlog.get_logger()


class WindsurfPoller(BasePoller):
    """Windsurf analytics poller (Enterprise only)"""

    def __init__(self, db: Database, config: Dict[str, Any]):
        super().__init__(db, config)
        self.api_url = config.get("api_url", "https://server.codeium.com/api/v1")
        self.service_key = config.get("service_key")
        self.team_id = config.get("team_id")

    def get_source_name(self) -> str:
        return "windsurf"

    def fetch_incremental(self, watermark: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
        since = watermark.get("last_sync_at")
        if not since:
            since_dt = datetime.utcnow() - timedelta(days=30)
            since = since_dt.date().isoformat()

        end_date = datetime.utcnow().date().isoformat()

        user_activity = self._fetch_user_activity(since, end_date)
        tool_usage = self._fetch_tool_usage(since, end_date)

        return {
            "user_activity": user_activity,
            "tool_usage": tool_usage
        }

    def _fetch_user_activity(self, start_date: str, end_date: str) -> List[Dict[str, Any]]:
        """
        Fetch COMPREHENSIVE user activity metrics

        Includes ALL available fields for deep productivity insights
        """
        url = f"{self.api_url}/Analytics"
        payload = {
            "service_key": self.service_key,
            "selection": {
                "data_source": "USER_DATA",
                "fields": [
                    # User identification (PRIMARY JOIN KEY)
                    "user_id", "user_email", "user_name",
                    # Chat/prompt activity
                    "prompts_used", "messages_sent", "chat_sessions",
                    "tokens_consumed", "model_used",
                    # Autocomplete metrics
                    "autocomplete_suggestions", "autocomplete_accepted",
                    "autocomplete_rejected", "autocomplete_partial_accepted",
                    "autocomplete_characters_inserted",
                    # Commands and actions
                    "commands_executed", "cascade_invocations",
                    "terminal_commands", "file_operations",
                    # Code generation
                    "code_generated_lines", "code_accepted_lines",
                    "code_rejected_lines", "refactorings_applied",
                    # Context and sessions
                    "files_opened", "projects_worked", "session_duration_seconds",
                    "context_switches", "avg_response_time_ms",
                    # Language/framework usage
                    "languages_used", "frameworks_detected",
                    # Error/success rates
                    "errors_encountered", "successful_completions"
                ]
            },
            "filters": {
                "date_range": {"start": start_date, "end": end_date},
                "team_id": self.team_id if self.team_id else None
            }
        }

        try:
            response = requests.post(url, json=payload, timeout=60)
            response.raise_for_status()
            data = response.json()

            activities = []
            for row in data.get("results", []):
                # Extract language and framework arrays
                languages = row.get("languages_used", [])
                if isinstance(languages, str):
                    languages = [languages]
                frameworks = row.get("frameworks_detected", [])
                if isinstance(frameworks, str):
                    frameworks = [frameworks]

                activities.append({
                    # User (PRIMARY JOIN KEY)
                    "user_id": row.get("user_id"),
                    "user_email": (row.get("user_email") or "").lower().strip() if row.get("user_email") else None,
                    "user_name": row.get("user_name"),
                    "date": row.get("date"),
                    # Chat metrics
                    "prompts_used": row.get("prompts_used", 0),
                    "messages_sent": row.get("messages_sent", 0),
                    "chat_sessions": row.get("chat_sessions", 0),
                    "tokens_consumed": row.get("tokens_consumed", 0),
                    "model_used": row.get("model_used"),
                    # Autocomplete
                    "autocomplete_suggestions": row.get("autocomplete_suggestions", 0),
                    "autocomplete_accepted": row.get("autocomplete_accepted", 0),
                    "autocomplete_rejected": row.get("autocomplete_rejected", 0),
                    "autocomplete_partial_accepted": row.get("autocomplete_partial_accepted", 0),
                    "autocomplete_characters_inserted": row.get("autocomplete_characters_inserted", 0),
                    # Commands
                    "commands_executed": row.get("commands_executed", 0),
                    "cascade_invocations": row.get("cascade_invocations", 0),
                    "terminal_commands": row.get("terminal_commands", 0),
                    "file_operations": row.get("file_operations", 0),
                    # Code generation
                    "code_generated_lines": row.get("code_generated_lines", 0),
                    "code_accepted_lines": row.get("code_accepted_lines", 0),
                    "code_rejected_lines": row.get("code_rejected_lines", 0),
                    "refactorings_applied": row.get("refactorings_applied", 0),
                    # Context
                    "files_opened": row.get("files_opened", 0),
                    "projects_worked": row.get("projects_worked", 0),
                    "session_duration_seconds": row.get("session_duration_seconds", 0),
                    "context_switches": row.get("context_switches", 0),
                    "avg_response_time_ms": row.get("avg_response_time_ms", 0),
                    # Languages/frameworks
                    "languages_used": json.dumps(languages),
                    "frameworks_detected": json.dumps(frameworks),
                    # Quality metrics
                    "errors_encountered": row.get("errors_encountered", 0),
                    "successful_completions": row.get("successful_completions", 0),
                    "fetched_at": datetime.utcnow().isoformat()
                })

            logger.info("windsurf_user_activity_fetched", count=len(activities))
            return activities
        except Exception as e:
            logger.warning("windsurf_fetch_failed", error=str(e))
            return []

    def _fetch_tool_usage(self, start_date: str, end_date: str) -> List[Dict[str, Any]]:
        url = f"{self.api_url}/CascadeAnalytics"
        payload = {
            "service_key": self.service_key,
            "selection": {"fields": ["user_id", "tool_name", "usage_count"]},
            "filters": {"date_range": {"start": start_date, "end": end_date}}
        }

        try:
            response = requests.post(url, json=payload, timeout=60)
            response.raise_for_status()
            return [{
                "user_id": r.get("user_id"),
                "tool_name": r.get("tool_name"),
                "usage_count": r.get("usage_count", 0),
                "date": r.get("date"),
                "fetched_at": datetime.utcnow().isoformat()
            } for r in response.json().get("results", [])]
        except:
            return []

    def insert_raw_data(self, data: Dict[str, List[Dict[str, Any]]]) -> int:
        total = 0
        if data["user_activity"]:
            total += self.db.execute_bulk_insert("windsurf_user_activity", data["user_activity"])
        if data["tool_usage"]:
            total += self.db.execute_bulk_insert("windsurf_tool_usage", data["tool_usage"])
        return total

    def transform_to_unified(self, data: Dict[str, List[Dict[str, Any]]]) -> int:
        total = 0
        for activity in data["user_activity"]:
            self.db.execute_insert("unified_events", {
                "source": "windsurf",
                "event_type": "code_activity",
                "event_date": activity["date"],
                "event_timestamp": f"{activity['date']}T12:00:00Z",
                "actor": activity["user_email"],
                "actor_email": activity["user_email"],
                "metadata": json.dumps({
                    "prompts_used": activity["prompts_used"],
                    "messages_sent": activity["messages_sent"],
                    "autocomplete_accepted": activity["autocomplete_accepted"]
                })
            })
            total += 1
        return total
