"""
Base poller class for all data sources
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List
from datetime import datetime
import structlog

from db.database import Database

logger = structlog.get_logger()


class BasePoller(ABC):
    """Base class for all data source pollers"""

    def __init__(self, db: Database, config: Dict[str, Any]):
        self.db = db
        self.config = config
        self.source_name = self.get_source_name()

    @abstractmethod
    def get_source_name(self) -> str:
        """Return the source name (github, jira, etc.)"""
        pass

    @abstractmethod
    def fetch_incremental(self, watermark: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
        """
        Fetch ALL new data since last watermark

        Returns:
            Dict mapping data types to lists of items
            e.g., {"commits": [...], "prs": [...], "issues": [...]}
        """
        pass

    @abstractmethod
    def insert_raw_data(self, data: Dict[str, List[Dict[str, Any]]]) -> int:
        """Insert raw data into source-specific tables"""
        pass

    @abstractmethod
    def transform_to_unified(self, data: Dict[str, List[Dict[str, Any]]]) -> int:
        """Transform raw data to unified_events"""
        pass

    def poll(self) -> Dict[str, int]:
        """Main polling method"""
        logger.info("poll_started", source=self.source_name)

        try:
            watermark = self.db.get_watermark(self.source_name)
            logger.info("watermark_retrieved",
                       source=self.source_name,
                       last_sync=watermark.get("last_sync_at"))

            raw_data = self.fetch_incremental(watermark)

            total_items = sum(len(items) for items in raw_data.values())
            logger.info("data_fetched",
                       source=self.source_name,
                       total_items=total_items,
                       breakdown={k: len(v) for k, v in raw_data.items()})

            if total_items == 0:
                logger.info("no_new_data", source=self.source_name)
                return {"raw_count": 0, "unified_count": 0}

            raw_count = self.insert_raw_data(raw_data)
            unified_count = self.transform_to_unified(raw_data)

            self.db.update_watermark(
                self.source_name,
                last_sync_at=datetime.utcnow().isoformat(),
                metadata={"last_poll_count": total_items}
            )

            logger.info("poll_completed",
                       source=self.source_name,
                       raw=raw_count,
                       unified=unified_count)

            return {"raw_count": raw_count, "unified_count": unified_count}

        except Exception as e:
            logger.error("poll_failed", source=self.source_name, error=str(e))
            raise
