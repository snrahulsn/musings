"""
GitHub API Poller - COMPREHENSIVE data ingestion
Fetches EVERYTHING: commits, PRs, issues, reviews, comments, reactions, milestones, projects
NO LIMITS - fetches all data
"""

import requests
from typing import Dict, Any, List, Optional
from datetime import datetime
import re
import json
import structlog
import time

from ingest.base import BasePoller
from db.database import Database

logger = structlog.get_logger()


class GitHubPoller(BasePoller):
    """GitHub API poller - fetches ALL available data"""

    def __init__(self, db: Database, config: Dict[str, Any]):
        super().__init__(db, config)
        self.token = config.get("token")
        self.repos = config.get("repos", [])
        self.base_url = "https://api.github.com"
        self.headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/vnd.github.v3+json"
        }
        # Cross-reference patterns
        self.jira_pattern = re.compile(r'\b([A-Z]{2,10}-\d+)\b')
        self.issue_pattern = re.compile(r'#(\d+)')
        self.ticket_pattern = re.compile(r'\b(?:ticket|TICKET)[:\s]*(\d+)\b')

    def get_source_name(self) -> str:
        return "github"

    def _handle_rate_limit(self, response):
        """Handle rate limiting with proper retry"""
        if response.status_code == 403 and 'X-RateLimit-Remaining' in response.headers:
            remaining = int(response.headers['X-RateLimit-Remaining'])
            if remaining == 0:
                reset_time = int(response.headers['X-RateLimit-Reset'])
                sleep_time = reset_time - int(time.time()) + 10
                logger.warning("rate_limit_hit", sleep_seconds=sleep_time)
                time.sleep(sleep_time)
                return True
        return False

    def _fetch_all_pages(self, url: str, params: Dict = None, repo_context: str = "") -> List[Dict]:
        """Fetch ALL pages from a paginated endpoint - NO LIMITS"""
        all_items = []
        params = params or {}
        params["per_page"] = 100
        page = 1

        while True:
            params["page"] = page
            try:
                response = requests.get(url, headers=self.headers, params=params, timeout=60)
                
                if self._handle_rate_limit(response):
                    continue

                response.raise_for_status()
                items = response.json()

                if not items or (isinstance(items, list) and len(items) == 0):
                    break

                if isinstance(items, dict):
                    items = [items]

                all_items.extend(items)
                logger.info("fetched_page", url=url, page=page, items=len(items), total=len(all_items), context=repo_context)

                page += 1

                # Stop if less than full page (last page)
                if len(items) < 100:
                    break

            except Exception as e:
                logger.error("fetch_failed", url=url, page=page, error=str(e))
                break

        return all_items

    def fetch_incremental(self, watermark: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
        """Fetch EVERYTHING from GitHub - ALL data points"""
        since = watermark.get("last_sync_at")
        if not since:
            from datetime import timedelta
            since_dt = datetime.utcnow() - timedelta(days=90)
            since = since_dt.isoformat() + "Z"

        all_data = {
            "commits": [],
            "pull_requests": [],
            "issues": [],
            "pr_reviews": [],
            "pr_comments": [],
            "issue_comments": [],
            "releases": [],
            "workflows": [],
            "code_scanning": [],
            "dependabot": []
        }

        for repo in self.repos:
            logger.info("fetching_complete_repo_data", repo=repo, since=since)

            # 1. COMMITS - with full stats
            all_data["commits"].extend(self._fetch_commits_complete(repo, since))

            # 2. PULL REQUESTS - everything
            prs = self._fetch_pull_requests_complete(repo, since)
            all_data["pull_requests"].extend(prs)

            # For each PR: reviews, review comments, comments, commits
            for pr in prs:
                pr_num = pr["number"]
                all_data["pr_reviews"].extend(self._fetch_pr_reviews_complete(repo, pr_num))
                all_data["pr_comments"].extend(self._fetch_pr_comments_complete(repo, pr_num))

            # 3. ISSUES - everything
            issues = self._fetch_issues_complete(repo, since)
            all_data["issues"].extend(issues)

            # For each issue: comments, events, timeline
            for issue in issues:
                issue_num = issue["number"]
                all_data["issue_comments"].extend(self._fetch_issue_comments_complete(repo, issue_num))

            # 4. RELEASES
            all_data["releases"].extend(self._fetch_releases_complete(repo))

            # 5. GitHub Actions Workflows (if available)
            all_data["workflows"].extend(self._fetch_workflows_complete(repo, since))

        return all_data

    def _fetch_commits_complete(self, repo: str, since: str) -> List[Dict[str, Any]]:
        """Fetch ALL commits with COMPLETE data including stats"""
        url = f"{self.base_url}/repos/{repo}/commits"
        commits_basic = self._fetch_all_pages(url, {"since": since}, f"commits:{repo}")

        commits = []
        for commit_data in commits_basic:
            # Fetch FULL commit data including stats
            sha = commit_data["sha"]
            commit_detail_url = f"{self.base_url}/repos/{repo}/commits/{sha}"
            
            try:
                response = requests.get(commit_detail_url, headers=self.headers, timeout=30)
                response.raise_for_status()
                full_commit = response.json()

                commit_obj = full_commit.get("commit", {})
                author = commit_obj.get("author", {})
                committer = commit_obj.get("committer", {})
                stats = full_commit.get("stats", {})
                files = full_commit.get("files", [])

                message = commit_obj.get("message", "")
                jira_keys = self.jira_pattern.findall(message)
                issue_refs = self.issue_pattern.findall(message)
                ticket_refs = self.ticket_pattern.findall(message)

                # Get parent commits
                parents = [p["sha"] for p in full_commit.get("parents", [])]

                commits.append({
                    "sha": sha,
                    "repo_name": repo,
                    "author_name": author.get("name"),
                    "author_email": (author.get("email") or "").lower().strip() if author.get("email") else None,
                    "author_date": author.get("date"),
                    "committer_name": committer.get("name"),
                    "committer_email": (committer.get("email") or "").lower().strip() if committer.get("email") else None,
                    "committer_date": committer.get("date"),
                    "message": message,
                    "additions": stats.get("additions", 0),
                    "deletions": stats.get("deletions", 0),
                    "total_changes": stats.get("total", 0),
                    "files_changed": len(files),
                    "parent_shas": json.dumps(parents),
                    "jira_keys": json.dumps(jira_keys),
                    "issue_refs": json.dumps(issue_refs),
                    "ticket_refs": json.dumps(ticket_refs),
                    "verification": json.dumps(commit_obj.get("verification", {})),
                    "files_detail": json.dumps([{
                        "filename": f.get("filename"),
                        "status": f.get("status"),
                        "additions": f.get("additions"),
                        "deletions": f.get("deletions"),
                        "changes": f.get("changes")
                    } for f in files[:50]]),  # First 50 files
                    "fetched_at": datetime.utcnow().isoformat()
                })

                time.sleep(0.1)  # Small delay to avoid secondary rate limits

            except Exception as e:
                logger.warning("failed_to_fetch_commit_detail", repo=repo, sha=sha, error=str(e))
                # Fallback to basic commit data
                commit_obj = commit_data.get("commit", {})
                commits.append({
                    "sha": sha,
                    "repo_name": repo,
                    "author_email": (commit_obj.get("author", {}).get("email") or "").lower().strip(),
                    "message": commit_obj.get("message"),
                    "fetched_at": datetime.utcnow().isoformat()
                })

        logger.info("commits_fetched_complete", repo=repo, count=len(commits))
        return commits

    def _fetch_pull_requests_complete(self, repo: str, since: str) -> List[Dict[str, Any]]:
        """Fetch ALL PRs with COMPLETE data"""
        url = f"{self.base_url}/repos/{repo}/pulls"
        prs_basic = self._fetch_all_pages(url, {"state": "all", "sort": "updated", "direction": "desc"}, f"prs:{repo}")

        prs = []
        since_dt = datetime.fromisoformat(since.replace("Z", "+00:00"))

        for pr_data in prs_basic:
            updated_at = datetime.fromisoformat(pr_data["updated_at"].replace("Z", "+00:00"))
            if updated_at < since_dt:
                break  # Stop fetching older PRs

            user = pr_data.get("user", {})
            merged_by = pr_data.get("merged_by", {}) if pr_data.get("merged_by") else {}

            body = pr_data.get("body") or ""
            title = pr_data.get("title") or ""
            combined = f"{title} {body}"

            jira_keys = self.jira_pattern.findall(combined)
            issue_refs = self.issue_pattern.findall(combined)
            ticket_refs = self.ticket_pattern.findall(combined)

            assignees = [a.get("login") for a in pr_data.get("assignees", [])]
            reviewers = [r.get("login") for r in pr_data.get("requested_reviewers", [])]
            labels = [l.get("name") for l in pr_data.get("labels", [])]

            prs.append({
                "pr_number": pr_data["number"],
                "repo_name": repo,
                "title": title,
                "body": body[:5000],  # First 5000 chars
                "state": pr_data.get("state"),
                "draft": pr_data.get("draft", False),
                "author": (user.get("login") or "").lower().strip() if user.get("login") else None,
                "author_association": pr_data.get("author_association"),
                "created_at_gh": pr_data.get("created_at"),
                "updated_at_gh": pr_data.get("updated_at"),
                "closed_at_gh": pr_data.get("closed_at"),
                "merged_at_gh": pr_data.get("merged_at"),
                "merged_by": (merged_by.get("login") or "").lower().strip() if merged_by.get("login") else None,
                "merge_commit_sha": pr_data.get("merge_commit_sha"),
                "additions": pr_data.get("additions", 0),
                "deletions": pr_data.get("deletions", 0),
                "changed_files": pr_data.get("changed_files", 0),
                "comments_count": pr_data.get("comments", 0),
                "review_comments_count": pr_data.get("review_comments", 0),
                "commits_count": pr_data.get("commits", 0),
                "assignees": json.dumps(assignees),
                "reviewers": json.dumps(reviewers),
                "labels": json.dumps(labels),
                "milestone": pr_data.get("milestone", {}).get("title") if pr_data.get("milestone") else None,
                "head_ref": pr_data.get("head", {}).get("ref"),
                "base_ref": pr_data.get("base", {}).get("ref"),
                "head_sha": pr_data.get("head", {}).get("sha"),
                "base_sha": pr_data.get("base", {}).get("sha"),
                "mergeable": pr_data.get("mergeable"),
                "mergeable_state": pr_data.get("mergeable_state"),
                "jira_keys": json.dumps(jira_keys),
                "issue_refs": json.dumps(issue_refs),
                "ticket_refs": json.dumps(ticket_refs),
                "fetched_at": datetime.utcnow().isoformat()
            })

        logger.info("pull_requests_fetched_complete", repo=repo, count=len(prs))
        return prs

    def _fetch_issues_complete(self, repo: str, since: str) -> List[Dict[str, Any]]:
        """Fetch ALL issues (not PRs) with COMPLETE data"""
        url = f"{self.base_url}/repos/{repo}/issues"
        issues_all = self._fetch_all_pages(url, {"state": "all", "since": since}, f"issues:{repo}")

        issues = []
        for issue_data in issues_all:
            if "pull_request" in issue_data:
                continue  # Skip PRs

            user = issue_data.get("user", {})
            assignee = issue_data.get("assignee", {}) if issue_data.get("assignee") else {}
            assignees = [a.get("login") for a in issue_data.get("assignees", [])]
            labels = [l.get("name") for l in issue_data.get("labels", [])]

            body = issue_data.get("body") or ""
            title = issue_data.get("title") or ""
            combined = f"{title} {body}"

            jira_keys = self.jira_pattern.findall(combined)
            ticket_refs = self.ticket_pattern.findall(combined)

            issues.append({
                "issue_number": issue_data["number"],
                "repo_name": repo,
                "title": title,
                "body": body[:5000],
                "state": issue_data.get("state"),
                "author": (user.get("login") or "").lower().strip() if user.get("login") else None,
                "assignee": (assignee.get("login") or "").lower().strip() if assignee.get("login") else None,
                "assignees": json.dumps(assignees),
                "labels": json.dumps(labels),
                "milestone": issue_data.get("milestone", {}).get("title") if issue_data.get("milestone") else None,
                "created_at_gh": issue_data.get("created_at"),
                "updated_at_gh": issue_data.get("updated_at"),
                "closed_at_gh": issue_data.get("closed_at"),
                "comments_count": issue_data.get("comments", 0),
                "reactions": json.dumps(issue_data.get("reactions", {})),
                "jira_keys": json.dumps(jira_keys),
                "ticket_refs": json.dumps(ticket_refs),
                "fetched_at": datetime.utcnow().isoformat()
            })

        logger.info("issues_fetched_complete", repo=repo, count=len(issues))
        return issues

    def _fetch_pr_reviews_complete(self, repo: str, pr_number: int) -> List[Dict[str, Any]]:
        """Fetch ALL PR reviews"""
        url = f"{self.base_url}/repos/{repo}/pulls/{pr_number}/reviews"
        reviews = self._fetch_all_pages(url, {}, f"pr_reviews:{repo}#{pr_number}")

        return [{
            "repo_name": repo,
            "pr_number": pr_number,
            "review_id": r["id"],
            "reviewer": (r.get("user", {}).get("login") or "").lower().strip() if r.get("user") else None,
            "state": r.get("state"),
            "body": r.get("body"),
            "submitted_at": r.get("submitted_at"),
            "commit_id": r.get("commit_id"),
            "fetched_at": datetime.utcnow().isoformat()
        } for r in reviews]

    def _fetch_pr_comments_complete(self, repo: str, pr_number: int) -> List[Dict[str, Any]]:
        """Fetch ALL PR review comments"""
        url = f"{self.base_url}/repos/{repo}/pulls/{pr_number}/comments"
        comments = self._fetch_all_pages(url, {}, f"pr_comments:{repo}#{pr_number}")

        return [{
            "repo_name": repo,
            "pr_number": pr_number,
            "comment_id": c["id"],
            "commenter": (c.get("user", {}).get("login") or "").lower().strip() if c.get("user") else None,
            "body": c.get("body"),
            "path": c.get("path"),
            "line": c.get("line"),
            "created_at": c.get("created_at"),
            "fetched_at": datetime.utcnow().isoformat()
        } for c in comments]

    def _fetch_issue_comments_complete(self, repo: str, issue_number: int) -> List[Dict[str, Any]]:
        """Fetch ALL issue comments"""
        url = f"{self.base_url}/repos/{repo}/issues/{issue_number}/comments"
        comments = self._fetch_all_pages(url, {}, f"issue_comments:{repo}#{issue_number}")

        return [{
            "repo_name": repo,
            "issue_number": issue_number,
            "comment_id": c["id"],
            "commenter": (c.get("user", {}).get("login") or "").lower().strip() if c.get("user") else None,
            "body": c.get("body"),
            "created_at": c.get("created_at"),
            "reactions": json.dumps(c.get("reactions", {})),
            "fetched_at": datetime.utcnow().isoformat()
        } for c in comments]

    def _fetch_releases_complete(self, repo: str) -> List[Dict[str, Any]]:
        """Fetch ALL releases"""
        url = f"{self.base_url}/repos/{repo}/releases"
        releases = self._fetch_all_pages(url, {}, f"releases:{repo}")

        return [{
            "repo_name": repo,
            "release_id": r["id"],
            "tag_name": r.get("tag_name"),
            "name": r.get("name"),
            "draft": r.get("draft", False),
            "prerelease": r.get("prerelease", False),
            "created_at": r.get("created_at"),
            "published_at": r.get("published_at"),
            "author": (r.get("author", {}).get("login") or "").lower().strip() if r.get("author") else None,
            "fetched_at": datetime.utcnow().isoformat()
        } for r in releases]

    def _fetch_workflows_complete(self, repo: str, since: str) -> List[Dict[str, Any]]:
        """Fetch workflow runs (GitHub Actions)"""
        url = f"{self.base_url}/repos/{repo}/actions/runs"
        try:
            runs = self._fetch_all_pages(url, {"created": f">={since[:10]}"}, f"workflows:{repo}")
            return [{
                "repo_name": repo,
                "run_id": r["id"],
                "name": r.get("name"),
                "status": r.get("status"),
                "conclusion": r.get("conclusion"),
                "workflow_id": r.get("workflow_id"),
                "created_at": r.get("created_at"),
                "updated_at": r.get("updated_at"),
                "run_started_at": r.get("run_started_at"),
                "actor": (r.get("actor", {}).get("login") or "").lower().strip() if r.get("actor") else None,
                "fetched_at": datetime.utcnow().isoformat()
            } for r in runs.get("workflow_runs", []) if isinstance(runs, dict)] if runs else []
        except:
            return []

    def insert_raw_data(self, data: Dict[str, List[Dict[str, Any]]]) -> int:
        total = 0
        if data["commits"]:
            total += self.db.execute_bulk_insert("github_commits", data["commits"])
        if data["pull_requests"]:
            total += self.db.execute_bulk_insert("github_pull_requests", data["pull_requests"])
        if data["issues"]:
            total += self.db.execute_bulk_insert("github_issues", data["issues"])
        return total

    def transform_to_unified(self, data: Dict[str, List[Dict[str, Any]]]) -> int:
        total = 0
        # Transform commits
        for commit in data["commits"]:
            self.db.execute_insert("unified_events", {
                "source": "github",
                "event_type": "commit",
                "event_date": commit["author_date"][:10] if commit.get("author_date") else datetime.utcnow().date().isoformat(),
                "event_timestamp": commit.get("author_date") or datetime.utcnow().isoformat(),
                "actor": commit.get("author_email"),
                "actor_email": commit.get("author_email"),
                "work_item_id": f"{commit['repo_name']}#{commit['sha'][:7]}",
                "work_item_title": (commit.get("message") or "").split('\n')[0][:100],
                "change_volume": commit.get("total_changes", 0),
                "metadata": json.dumps({
                    "repo": commit["repo_name"],
                    "sha": commit["sha"],
                    "additions": commit.get("additions", 0),
                    "deletions": commit.get("deletions", 0),
                    "files_changed": commit.get("files_changed", 0),
                    "jira_keys": json.loads(commit.get("jira_keys") or "[]"),
                    "issue_refs": json.loads(commit.get("issue_refs") or "[]")
                })
            })
            total += 1

        # Transform PRs
        for pr in data["pull_requests"]:
            if pr.get("created_at_gh"):
                self.db.execute_insert("unified_events", {
                    "source": "github",
                    "event_type": "pr_created",
                    "event_date": pr["created_at_gh"][:10],
                    "event_timestamp": pr["created_at_gh"],
                    "actor": pr.get("author"),
                    "work_item_id": f"{pr['repo_name']}#PR{pr['pr_number']}",
                    "work_item_title": pr.get("title"),
                    "work_item_status": pr.get("state"),
                    "change_volume": pr.get("additions", 0) + pr.get("deletions", 0),
                    "metadata": json.dumps({
                        "repo": pr["repo_name"],
                        "pr_number": pr["pr_number"],
                        "labels": json.loads(pr.get("labels") or "[]"),
                        "jira_keys": json.loads(pr.get("jira_keys") or "[]")
                    })
                })
                total += 1

            if pr.get("merged_at_gh"):
                self.db.execute_insert("unified_events", {
                    "source": "github",
                    "event_type": "pr_merged",
                    "event_date": pr["merged_at_gh"][:10],
                    "event_timestamp": pr["merged_at_gh"],
                    "actor": pr.get("merged_by") or pr.get("author"),
                    "work_item_id": f"{pr['repo_name']}#PR{pr['pr_number']}",
                    "work_item_title": pr.get("title"),
                    "work_item_status": "merged",
                    "change_volume": pr.get("additions", 0) + pr.get("deletions", 0),
                    "metadata": json.dumps({"repo": pr["repo_name"], "pr_number": pr["pr_number"]})
                })
                total += 1

        # Transform PR reviews
        for review in data["pr_reviews"]:
            if review.get("submitted_at"):
                self.db.execute_insert("unified_events", {
                    "source": "github",
                    "event_type": "pr_reviewed",
                    "event_date": review["submitted_at"][:10],
                    "event_timestamp": review["submitted_at"],
                    "actor": review.get("reviewer"),
                    "work_item_id": f"{review['repo_name']}#PR{review['pr_number']}",
                    "metadata": json.dumps({"review_state": review.get("state")})
                })
                total += 1

        return total
