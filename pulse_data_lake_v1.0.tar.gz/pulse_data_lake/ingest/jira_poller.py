"""
JIRA API Poller - Comprehensive issue tracking data

Fetches:
- Issues (with all fields, custom fields, story points)
- Worklogs (time tracking data)
- Issue changelog (status transitions, assignee changes)
- Sprint data (velocity, burndown)
- Comments (for engagement metrics)

Join keys:
- Email addresses from assignee/reporter
- Issue keys in commits/PRs (extracted by GitHub poller)
- Project keys for repo mapping
"""

import requests
from typing import Dict, Any, List, Optional
from datetime import datetime
import json
import structlog
from requests.auth import HTTPBasicAuth

from ingest.base import BasePoller
from db.database import Database

logger = structlog.get_logger()


class JiraPoller(BasePoller):
    """JIRA API poller with comprehensive data extraction"""

    def __init__(self, db: Database, config: Dict[str, Any]):
        super().__init__(db, config)
        self.base_url = config.get("base_url").rstrip("/")
        self.email = config.get("email")
        self.api_token = config.get("api_token")
        self.projects = config.get("projects", [])
        self.auth = HTTPBasicAuth(self.email, self.api_token)

    def get_source_name(self) -> str:
        return "jira"

    def fetch_incremental(self, watermark: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
        """
        Fetch ALL JIRA data since watermark

        Returns issues, worklogs, transitions, sprints
        """
        since = watermark.get("last_sync_at")
        if not since:
            # First sync - go back 90 days
            from datetime import timedelta
            since_dt = datetime.utcnow() - timedelta(days=90)
            since = since_dt.strftime("%Y-%m-%d %H:%M")

        all_data = {
            "issues": [],
            "worklogs": [],
            "transitions": [],
            "comments": []
        }

        for project in self.projects:
            logger.info("fetching_jira_project", project=project, since=since)

            # Fetch issues with ALL useful fields
            issues = self._fetch_issues(project, since)
            all_data["issues"].extend(issues)

            # For each issue, fetch worklogs and changelog
            for issue in issues:
                worklogs = self._fetch_worklogs(issue["issue_key"])
                all_data["worklogs"].extend(worklogs)

                transitions = self._fetch_status_transitions(issue["issue_key"], issue["changelog"])
                all_data["transitions"].extend(transitions)

                comments = self._fetch_comments(issue["issue_key"], issue["comments_data"])
                all_data["comments"].extend(comments)

        return all_data

    def _get_all_fields(self) -> List[str]:
        """
        Fetch ALL field definitions from JIRA to get custom fields dynamically

        This ensures we capture ALL custom fields, not just hardcoded ones
        """
        url = f"{self.base_url}/rest/api/3/field"

        try:
            response = requests.get(url, auth=self.auth)
            response.raise_for_status()
            fields = response.json()

            # Return all field IDs
            field_ids = [f["id"] for f in fields]
            logger.info("jira_fields_discovered", count=len(field_ids))
            return field_ids
        except Exception as e:
            logger.warning("failed_to_fetch_fields", error=str(e))
            # Fallback to common fields
            return [
                "summary", "description", "status", "issuetype",
                "priority", "reporter", "assignee", "creator",
                "created", "updated", "resolutiondate", "resolved",
                "labels", "components", "fixVersions", "attachment",
                "timetracking", "aggregatetimeoriginalestimate",
                "aggregatetimespent", "worklog", "comment", "votes",
                "watches", "resolution", "environment", "duedate"
            ]

    def _fetch_issues(self, project: str, since: str) -> List[Dict[str, Any]]:
        """
        Fetch issues with COMPLETE data - ALL FIELDS including custom fields

        NO LIMITS - Fetches ALL pages

        Critical fields for joins:
        - reporter.emailAddress (person join)
        - assignee.emailAddress (person join)
        - issue key (for GitHub commit references)
        - sprint data (for velocity)
        - story points (for capacity planning)
        - ALL custom fields dynamically discovered
        """
        url = f"{self.base_url}/rest/api/3/search"

        # Get ALL fields including custom fields
        all_fields = self._get_all_fields()

        # JQL to get updated issues
        jql = f'project = {project} AND updated >= "{since}" ORDER BY updated ASC'

        issues = []
        start_at = 0
        max_results = 100

        # NO LIMITS - fetch ALL pages
        while True:
            payload = {
                "jql": jql,
                "startAt": start_at,
                "maxResults": max_results,
                "fields": all_fields,  # ALL fields including custom
                "expand": ["changelog", "renderedFields", "names", "schema", "operations", "editmeta"]
            }

            response = requests.post(
                url,
                json=payload,
                auth=self.auth,
                headers={"Content-Type": "application/json"},
                timeout=60
            )

            if response.status_code == 429:
                # Rate limited - wait and retry
                retry_after = int(response.headers.get("Retry-After", 60))
                logger.warning("jira_rate_limited", project=project, retry_after=retry_after)
                import time
                time.sleep(retry_after)
                continue

            response.raise_for_status()
            data = response.json()

            for issue_data in data.get("issues", []):
                fields = issue_data.get("fields", {})

                # Extract reporter and assignee emails (PRIMARY JOIN KEYS)
                reporter = fields.get("reporter") or {}
                assignee = fields.get("assignee") or {}
                creator = fields.get("creator") or {}

                # Extract sprint data (try multiple common custom field IDs)
                sprint_id = None
                sprint_name = None
                story_points = None

                for field_id in ["customfield_10020", "customfield_10010", "customfield_10100"]:
                    sprint_field = fields.get(field_id)
                    if sprint_field and isinstance(sprint_field, list) and len(sprint_field) > 0:
                        sprint = sprint_field[0]
                        if isinstance(sprint, dict):
                            sprint_id = sprint.get("id")
                            sprint_name = sprint.get("name")
                            break

                # Story points (try multiple common IDs)
                for field_id in ["customfield_10016", "customfield_10002", "customfield_10026"]:
                    sp = fields.get(field_id)
                    if sp is not None:
                        story_points = sp
                        break

                # Time tracking
                time_tracking = fields.get("timetracking") or {}
                original_estimate = time_tracking.get("originalEstimateSeconds", 0)
                time_spent = time_tracking.get("timeSpentSeconds", 0)
                remaining_estimate = time_tracking.get("remainingEstimateSeconds", 0)

                # Labels, components, fix versions
                labels = [l for l in fields.get("labels", [])]
                components = [c.get("name") for c in fields.get("components", [])]
                fix_versions = [v.get("name") for v in fields.get("fixVersions", [])]

                # Attachments
                attachments = []
                for att in fields.get("attachment", []):
                    attachments.append({
                        "filename": att.get("filename"),
                        "size": att.get("size"),
                        "mimeType": att.get("mimeType"),
                        "author": self._normalize_email(att.get("author", {}).get("emailAddress"))
                    })

                # Resolution
                resolution = fields.get("resolution")
                resolution_name = resolution.get("name") if resolution else None

                # Environment and due date
                environment = fields.get("environment")
                due_date = fields.get("duedate")

                # Votes and watchers
                votes = fields.get("votes", {}).get("votes", 0)
                watchers = fields.get("watches", {}).get("watchCount", 0)

                # Collect ALL custom fields dynamically
                all_custom_fields = {}
                for field_id in all_fields:
                    if field_id.startswith("customfield_"):
                        value = fields.get(field_id)
                        if value is not None:
                            # Convert complex objects to JSON strings
                            if isinstance(value, (dict, list)):
                                all_custom_fields[field_id] = json.dumps(value)
                            else:
                                all_custom_fields[field_id] = str(value)

                issues.append({
                    "issue_key": issue_data["key"],
                    "issue_id": issue_data["id"],
                    "project_key": project,
                    "summary": fields.get("summary"),
                    "description": fields.get("description"),
                    "issue_type": fields.get("issuetype", {}).get("name"),
                    "status": fields.get("status", {}).get("name"),
                    "priority": fields.get("priority", {}).get("name") if fields.get("priority") else None,
                    "resolution": resolution_name,
                    # PRIMARY JOIN KEYS - Email addresses
                    "reporter": self._normalize_email(reporter.get("emailAddress")),
                    "reporter_name": reporter.get("displayName"),
                    "assignee": self._normalize_email(assignee.get("emailAddress")),
                    "assignee_name": assignee.get("displayName"),
                    "creator": self._normalize_email(creator.get("emailAddress")),
                    # Timestamps
                    "created_at_jira": fields.get("created"),
                    "updated_at_jira": fields.get("updated"),
                    "resolved_at_jira": fields.get("resolutiondate"),
                    "due_date": due_date,
                    # Sprint and estimation data
                    "sprint_id": sprint_id,
                    "sprint_name": sprint_name,
                    "story_points": story_points,
                    "original_estimate_seconds": original_estimate,
                    "time_spent_seconds": time_spent,
                    "remaining_estimate_seconds": remaining_estimate,
                    # Categorization
                    "labels": json.dumps(labels),
                    "components": json.dumps(components),
                    "fix_versions": json.dumps(fix_versions),
                    "attachments": json.dumps(attachments),
                    "environment": environment,
                    # Engagement metrics
                    "votes": votes,
                    "watchers": watchers,
                    # ALL custom fields dynamically captured
                    "custom_fields": json.dumps(all_custom_fields),
                    # Store changelog and comments for later processing
                    "changelog": issue_data.get("changelog", {}),
                    "comments_data": fields.get("comment", {}),
                    "fetched_at": datetime.utcnow().isoformat()
                })

            start_at += max_results

            # Check if we've fetched all issues
            if start_at >= data.get("total", 0) or len(data.get("issues", [])) == 0:
                break

        logger.info("jira_issues_fetched", project=project, count=len(issues))
        return issues

    def _fetch_worklogs(self, issue_key: str) -> List[Dict[str, Any]]:
        """
        Fetch worklogs for time tracking

        Critical for:
        - Developer productivity
        - Time estimation accuracy
        - Capacity planning
        """
        url = f"{self.base_url}/rest/api/3/issue/{issue_key}/worklog"

        try:
            response = requests.get(url, auth=self.auth)
            response.raise_for_status()

            worklogs = []
            for wl in response.json().get("worklogs", []):
                author = wl.get("author") or {}

                worklogs.append({
                    "worklog_id": wl["id"],
                    "issue_key": issue_key,
                    # PRIMARY JOIN KEY
                    "author": self._normalize_email(author.get("emailAddress")),
                    "author_name": author.get("displayName"),
                    "time_spent_seconds": wl.get("timeSpentSeconds", 0),
                    "started_at": wl.get("started"),
                    "comment": wl.get("comment"),
                    "fetched_at": datetime.utcnow().isoformat()
                })

            return worklogs

        except Exception as e:
            logger.warning("failed_to_fetch_worklogs", issue=issue_key, error=str(e))
            return []

    def _fetch_status_transitions(self, issue_key: str, changelog: Dict) -> List[Dict[str, Any]]:
        """
        Extract status transitions from changelog

        Critical for:
        - Cycle time analysis
        - Bottleneck identification
        - Process metrics
        """
        transitions = []

        for history in changelog.get("histories", []):
            author = history.get("author") or {}
            created = history.get("created")

            for item in history.get("items", []):
                if item.get("field") == "status":
                    transitions.append({
                        "issue_key": issue_key,
                        "from_status": item.get("fromString"),
                        "to_status": item.get("toString"),
                        "transition_date": created,
                        # PRIMARY JOIN KEY
                        "author": self._normalize_email(author.get("emailAddress")),
                        "author_name": author.get("displayName"),
                        "fetched_at": datetime.utcnow().isoformat()
                    })

        return transitions

    def _fetch_comments(self, issue_key: str, comments_data: Dict) -> List[Dict[str, Any]]:
        """Extract comments for engagement metrics"""
        comments = []

        for comment in comments_data.get("comments", []):
            author = comment.get("author") or {}

            comments.append({
                "issue_key": issue_key,
                "comment_id": comment["id"],
                "author": self._normalize_email(author.get("emailAddress")),
                "author_name": author.get("displayName"),
                "created_at": comment.get("created"),
                "body": comment.get("body"),
                "fetched_at": datetime.utcnow().isoformat()
            })

        return comments

    def _normalize_email(self, email: Optional[str]) -> Optional[str]:
        """Normalize email for consistent person joining"""
        if not email:
            return None
        return email.lower().strip()

    def insert_raw_data(self, data: Dict[str, List[Dict[str, Any]]]) -> int:
        """Insert all JIRA data into raw tables"""
        total = 0

        # Insert issues
        if data["issues"]:
            # Remove changelog and comments_data before inserting (already processed)
            issues_clean = []
            for issue in data["issues"]:
                issue_copy = issue.copy()
                issue_copy.pop("changelog", None)
                issue_copy.pop("comments_data", None)
                issues_clean.append(issue_copy)

            total += self.db.execute_bulk_insert("jira_issues", issues_clean)

        # Insert worklogs
        if data["worklogs"]:
            total += self.db.execute_bulk_insert("jira_worklogs", data["worklogs"])

        # Insert status transitions
        if data["transitions"]:
            total += self.db.execute_bulk_insert("jira_status_transitions", data["transitions"])

        return total

    def transform_to_unified(self, data: Dict[str, List[Dict[str, Any]]]) -> int:
        """
        Transform JIRA data to unified_events

        Creates events with proper join keys:
        - actor_email (assignee/reporter email)
        - work_item_id (JIRA issue key - matches GitHub commit references)
        - metadata with sprint, story points, etc.
        """
        total = 0

        # Transform issues
        for issue in data["issues"]:
            # Issue created event
            if issue["created_at_jira"]:
                event = {
                    "source": "jira",
                    "event_type": "issue_created",
                    "event_date": issue["created_at_jira"][:10],
                    "event_timestamp": issue["created_at_jira"],
                    "actor": issue["reporter"],  # PRIMARY JOIN KEY
                    "actor_email": issue["reporter"],
                    "assignee": issue["assignee"],
                    "work_item_id": issue["issue_key"],  # JOIN KEY for GitHub
                    "work_item_title": issue["summary"],
                    "work_item_status": issue["status"],
                    "metadata": json.dumps({
                        "project": issue["project_key"],
                        "issue_type": issue["issue_type"],
                        "priority": issue["priority"],
                        "story_points": issue["story_points"],
                        "sprint_id": issue["sprint_id"],
                        "sprint_name": issue["sprint_name"],
                        "labels": json.loads(issue["labels"]),
                        "components": json.loads(issue["components"])
                    })
                }
                self.db.execute_insert("unified_events", event)
                total += 1

            # Issue resolved event
            if issue["resolved_at_jira"]:
                event = {
                    "source": "jira",
                    "event_type": "issue_closed",
                    "event_date": issue["resolved_at_jira"][:10],
                    "event_timestamp": issue["resolved_at_jira"],
                    "actor": issue["assignee"] or issue["reporter"],
                    "actor_email": issue["assignee"] or issue["reporter"],
                    "work_item_id": issue["issue_key"],
                    "work_item_title": issue["summary"],
                    "work_item_status": "resolved",
                    "duration_seconds": issue["time_spent_seconds"],
                    "metadata": json.dumps({
                        "project": issue["project_key"],
                        "issue_type": issue["issue_type"],
                        "story_points": issue["story_points"],
                        "sprint_name": issue["sprint_name"]
                    })
                }
                self.db.execute_insert("unified_events", event)
                total += 1

        # Transform worklogs
        for worklog in data["worklogs"]:
            event = {
                "source": "jira",
                "event_type": "worklog",
                "event_date": worklog["started_at"][:10],
                "event_timestamp": worklog["started_at"],
                "actor": worklog["author"],  # PRIMARY JOIN KEY
                "actor_email": worklog["author"],
                "work_item_id": worklog["issue_key"],
                "duration_seconds": worklog["time_spent_seconds"],
                "metadata": json.dumps({
                    "worklog_id": worklog["worklog_id"]
                })
            }
            self.db.execute_insert("unified_events", event)
            total += 1

        # Transform status transitions
        for transition in data["transitions"]:
            event = {
                "source": "jira",
                "event_type": "status_change",
                "event_date": transition["transition_date"][:10],
                "event_timestamp": transition["transition_date"],
                "actor": transition["author"],
                "actor_email": transition["author"],
                "work_item_id": transition["issue_key"],
                "work_item_status": transition["to_status"],
                "metadata": json.dumps({
                    "from_status": transition["from_status"],
                    "to_status": transition["to_status"]
                })
            }
            self.db.execute_insert("unified_events", event)
            total += 1

        return total
