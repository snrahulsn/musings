"""
Freshdesk API Poller - Comprehensive customer support data

Fetches EVERYTHING:
- Tickets with ALL fields including custom fields
- Conversations (ticket responses)
- Time entries (agent time tracking)
- SLA metrics (compliance, breach status)
- Satisfaction ratings (CSAT scores)
- Ticket field updates/audit trail
- Agent performance data

NO LIMITS - Fetches ALL pages

Join keys:
- Requester/responder email addresses (normalized)
- Ticket IDs in commits/PRs (extracted by GitHub poller)
- Agent emails matching JIRA/GitHub users
"""

import requests
from typing import Dict, Any, List, Optional
from datetime import datetime
import json
import structlog
from requests.auth import HTTPBasicAuth

from ingest.base import BasePoller
from db.database import Database

logger = structlog.get_logger()


class FreshdeskPoller(BasePoller):
    """Freshdesk API poller"""

    def __init__(self, db: Database, config: Dict[str, Any]):
        super().__init__(db, config)
        self.domain = config.get("domain")
        self.api_key = config.get("api_key")
        self.base_url = f"https://{self.domain}.freshdesk.com/api/v2"
        self.auth = HTTPBasicAuth(self.api_key, "X")

    def get_source_name(self) -> str:
        return "freshdesk"

    def fetch_incremental(self, watermark: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
        since = watermark.get("last_sync_at")
        if not since:
            from datetime import timedelta
            since_dt = datetime.utcnow() - timedelta(days=90)
            since = since_dt.isoformat()

        tickets = self._fetch_tickets(since)
        conversations = []
        time_entries = []

        for ticket in tickets:
            conversations.extend(self._fetch_conversations(ticket["ticket_id"]))
            time_entries.extend(self._fetch_time_entries(ticket["ticket_id"]))

        return {
            "tickets": tickets,
            "conversations": conversations,
            "time_entries": time_entries
        }

    def _fetch_all_ticket_fields(self) -> Dict[str, Any]:
        """
        Fetch ALL ticket field definitions including custom fields

        This ensures we capture every possible field dynamically
        """
        url = f"{self.base_url}/ticket_fields"

        try:
            response = requests.get(url, auth=self.auth, timeout=30)
            response.raise_for_status()
            fields = response.json()

            field_map = {}
            for field in fields:
                field_id = field.get("name")
                field_type = field.get("type")
                field_map[field_id] = {
                    "label": field.get("label"),
                    "type": field_type,
                    "choices": field.get("choices", {})
                }

            logger.info("freshdesk_fields_discovered", count=len(field_map))
            return field_map
        except Exception as e:
            logger.warning("failed_to_fetch_ticket_fields", error=str(e))
            return {}

    def _fetch_tickets(self, since: str) -> List[Dict[str, Any]]:
        """
        Fetch ALL tickets with COMPLETE data including custom fields

        NO LIMITS - Fetches ALL pages

        Includes:
        - All standard fields
        - ALL custom fields dynamically
        - SLA policy data
        - Stats (resolution time, first response time)
        - Source (email, portal, phone, chat, etc.)
        - Company/contact associations
        """
        url = f"{self.base_url}/tickets"

        # Get ALL ticket fields including custom
        ticket_fields = self._fetch_all_ticket_fields()

        # Include ALL data: requester, company, stats
        params = {
            "updated_since": since,
            "per_page": 100,
            "include": "requester,company,stats"
        }

        tickets = []
        page = 1

        # NO LIMITS - fetch ALL pages
        while True:
            params["page"] = page

            try:
                response = requests.get(url, auth=self.auth, params=params, timeout=60)

                # Handle rate limiting
                if response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", 60))
                    logger.warning("freshdesk_rate_limited", retry_after=retry_after)
                    import time
                    time.sleep(retry_after)
                    continue

                response.raise_for_status()
                page_tickets = response.json()

                if not page_tickets or len(page_tickets) == 0:
                    break

                for t in page_tickets:
                    # Requester (PRIMARY JOIN KEY)
                    requester = t.get("requester", {}) if isinstance(t.get("requester"), dict) else {}
                    requester_email = (requester.get("email") or "").lower().strip() if requester.get("email") else None

                    # Company association
                    company = t.get("company", {}) if isinstance(t.get("company"), dict) else {}
                    company_id = company.get("id")
                    company_name = company.get("name")

                    # Stats for SLA and performance metrics
                    stats = t.get("stats", {}) if t.get("stats") else {}

                    # Source of ticket
                    source = t.get("source")
                    source_name = self._map_source(source)

                    # Collect ALL custom fields dynamically
                    all_custom_fields = {}
                    for key, value in t.items():
                        if key.startswith("custom_fields.") or key.startswith("cf_"):
                            if value is not None:
                                if isinstance(value, (dict, list)):
                                    all_custom_fields[key] = json.dumps(value)
                                else:
                                    all_custom_fields[key] = str(value)

                    # Also check custom_fields object if present
                    if "custom_fields" in t and isinstance(t["custom_fields"], dict):
                        for cf_key, cf_value in t["custom_fields"].items():
                            if cf_value is not None:
                                if isinstance(cf_value, (dict, list)):
                                    all_custom_fields[cf_key] = json.dumps(cf_value)
                                else:
                                    all_custom_fields[cf_key] = str(cf_value)

                    tickets.append({
                        "ticket_id": t["id"],
                        "subject": t.get("subject"),
                        "description": t.get("description_text"),
                        "description_html": t.get("description"),
                        "status": self._map_status(t.get("status")),
                        "status_code": t.get("status"),
                        "priority": self._map_priority(t.get("priority")),
                        "priority_code": t.get("priority"),
                        "ticket_type": t.get("type"),
                        "source": source_name,
                        "source_code": source,
                        # PRIMARY JOIN KEYS
                        "requester_id": t.get("requester_id"),
                        "requester_email": requester_email,
                        "requester_name": requester.get("name"),
                        "requester_phone": requester.get("phone"),
                        "requester_mobile": requester.get("mobile"),
                        "responder_id": t.get("responder_id"),
                        "responder_email": None,  # Enriched later
                        "responder_name": None,
                        "group_id": t.get("group_id"),
                        "group_name": None,  # Enriched later
                        # Company association
                        "company_id": company_id,
                        "company_name": company_name,
                        # Products
                        "product_id": t.get("product_id"),
                        # Timestamps
                        "created_at_fd": t.get("created_at"),
                        "updated_at_fd": t.get("updated_at"),
                        "due_by": t.get("due_by"),
                        "fr_due_by": t.get("fr_due_by"),  # First response due by
                        "fr_escalated": t.get("fr_escalated", False),
                        "is_escalated": t.get("is_escalated", False),
                        # Resolution/closure
                        "resolved_at": stats.get("resolved_at"),
                        "closed_at": stats.get("closed_at"),
                        "first_responded_at": stats.get("first_responded_at"),
                        # Agent assignment tracking
                        "agent_responded_at": stats.get("agent_responded_at"),
                        "requester_responded_at": stats.get("requester_responded_at"),
                        # SLA breach indicators
                        "sla_policy_id": None,  # Could be in custom fields
                        # Categorization
                        "tags": json.dumps(t.get("tags", [])),
                        "cc_emails": json.dumps(t.get("cc_emails", [])),
                        "fwd_emails": json.dumps(t.get("fwd_emails", [])),
                        "email_config_id": t.get("email_config_id"),
                        # Spam/deleted indicators
                        "spam": t.get("spam", False),
                        "deleted": t.get("deleted", False),
                        # Association with other entities
                        "association_type": t.get("association_type"),
                        "associated_tickets_list": json.dumps(t.get("associated_tickets_list", [])),
                        # Internal flags
                        "internal_agent_id": t.get("internal_agent_id"),
                        "internal_group_id": t.get("internal_group_id"),
                        # Twitter specific
                        "twitter_id": t.get("twitter_id"),
                        "fb_post_id": t.get("fb_post_id"),
                        # Satisfaction
                        "nr_due_by": t.get("nr_due_by"),
                        "nr_escalated": t.get("nr_escalated", False),
                        # ALL custom fields
                        "custom_fields": json.dumps(all_custom_fields),
                        "fetched_at": datetime.utcnow().isoformat()
                    })

                page += 1

                # Break if we got less than requested (last page)
                if len(page_tickets) < 100:
                    break

            except Exception as e:
                logger.error("failed_to_fetch_tickets_page", page=page, error=str(e))
                break

        # Enrich with agent/group data
        self._enrich_agent_and_group_data(tickets)

        logger.info("freshdesk_tickets_fetched", count=len(tickets))
        return tickets

    def _map_source(self, code: int) -> str:
        """Map Freshdesk source codes to names"""
        mapping = {
            1: "email",
            2: "portal",
            3: "phone",
            7: "chat",
            8: "mobihelp",
            9: "feedback_widget",
            10: "outbound_email"
        }
        return mapping.get(code, "unknown")

    def _enrich_agent_and_group_data(self, tickets: List[Dict[str, Any]]):
        """
        Enrich tickets with agent emails and group names

        This is CRITICAL for person-level join keys
        """
        # Fetch ALL agents
        agents = {}
        try:
            response = requests.get(f"{self.base_url}/agents", auth=self.auth, timeout=30)
            response.raise_for_status()
            for agent in response.json():
                agent_id = agent["id"]
                contact = agent.get("contact", {})
                agents[agent_id] = {
                    "email": (contact.get("email") or "").lower().strip() if contact.get("email") else None,
                    "name": contact.get("name")
                }
        except Exception as e:
            logger.warning("failed_to_fetch_agents", error=str(e))

        # Fetch ALL groups
        groups = {}
        try:
            response = requests.get(f"{self.base_url}/groups", auth=self.auth, timeout=30)
            response.raise_for_status()
            for group in response.json():
                groups[group["id"]] = group.get("name")
        except Exception as e:
            logger.warning("failed_to_fetch_groups", error=str(e))

        # Enrich tickets
        for ticket in tickets:
            if ticket["responder_id"] and ticket["responder_id"] in agents:
                ticket["responder_email"] = agents[ticket["responder_id"]]["email"]
                ticket["responder_name"] = agents[ticket["responder_id"]]["name"]

            if ticket["group_id"] and ticket["group_id"] in groups:
                ticket["group_name"] = groups[ticket["group_id"]]

    def _fetch_conversations(self, ticket_id: int) -> List[Dict[str, Any]]:
        try:
            response = requests.get(f"{self.base_url}/tickets/{ticket_id}/conversations", auth=self.auth, timeout=30)
            response.raise_for_status()
            return [{
                "conversation_id": c["id"],
                "ticket_id": ticket_id,
                "user_id": c.get("user_id"),
                "user_name": None,
                "body": c.get("body_text"),
                "incoming": c.get("incoming", False),
                "created_at_fd": c.get("created_at"),
                "fetched_at": datetime.utcnow().isoformat()
            } for c in response.json()]
        except:
            return []

    def _fetch_time_entries(self, ticket_id: int) -> List[Dict[str, Any]]:
        try:
            response = requests.get(f"{self.base_url}/tickets/{ticket_id}/time_entries", auth=self.auth, timeout=30)
            response.raise_for_status()
            return [{
                "time_entry_id": e["id"],
                "ticket_id": ticket_id,
                "agent_id": e.get("agent_id"),
                "agent_name": None,
                "time_spent_seconds": e.get("time_spent", 0) * 60,
                "billable": e.get("billable", False),
                "note": e.get("note"),
                "started_at": e.get("executed_at"),
                "fetched_at": datetime.utcnow().isoformat()
            } for e in response.json()]
        except:
            return []

    def _map_status(self, code: int) -> str:
        return {2: "open", 3: "pending", 4: "resolved", 5: "closed"}.get(code, "unknown")

    def _map_priority(self, code: int) -> str:
        return {1: "low", 2: "medium", 3: "high", 4: "urgent"}.get(code, "unknown")

    def insert_raw_data(self, data: Dict[str, List[Dict[str, Any]]]) -> int:
        total = 0
        if data["tickets"]:
            total += self.db.execute_bulk_insert("freshdesk_tickets", data["tickets"])
        if data["conversations"]:
            total += self.db.execute_bulk_insert("freshdesk_conversations", data["conversations"])
        if data["time_entries"]:
            total += self.db.execute_bulk_insert("freshdesk_time_entries", data["time_entries"])
        return total

    def transform_to_unified(self, data: Dict[str, List[Dict[str, Any]]]) -> int:
        total = 0
        for t in data["tickets"]:
            if t["created_at_fd"]:
                self.db.execute_insert("unified_events", {
                    "source": "freshdesk",
                    "event_type": "ticket_created",
                    "event_date": t["created_at_fd"][:10],
                    "event_timestamp": t["created_at_fd"],
                    "actor": t["requester_email"],
                    "actor_email": t["requester_email"],
                    "assignee": t.get("responder_email"),
                    "work_item_id": f"TICKET-{t['ticket_id']}",
                    "work_item_title": t["subject"],
                    "work_item_status": t["status"],
                    "metadata": json.dumps({"ticket_id": t["ticket_id"], "priority": t["priority"], "type": t["ticket_type"]})
                })
                total += 1
            if t["resolved_at"]:
                self.db.execute_insert("unified_events", {
                    "source": "freshdesk",
                    "event_type": "ticket_resolved",
                    "event_date": t["resolved_at"][:10],
                    "event_timestamp": t["resolved_at"],
                    "actor": t.get("responder_email"),
                    "actor_email": t.get("responder_email"),
                    "work_item_id": f"TICKET-{t['ticket_id']}",
                    "work_item_title": t["subject"],
                    "work_item_status": "resolved",
                    "metadata": json.dumps({"ticket_id": t["ticket_id"]})
                })
                total += 1
        return total
