-- Watermark tracking table for incremental syncs
CREATE TABLE IF NOT EXISTS sync_watermarks (
    source TEXT PRIMARY KEY,           -- 'github', 'jira', 'freshdesk', 'windsurf'
    last_sync_at DATETIME,
    last_sync_cursor TEXT,             -- for pagination cursors
    metadata JSON,                     -- additional state info
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- GITHUB RAW DATA TABLES
-- ============================================

CREATE TABLE IF NOT EXISTS github_commits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sha TEXT UNIQUE NOT NULL,
    repo_name TEXT NOT NULL,
    author_name TEXT,
    author_email TEXT,
    author_date DATETIME NOT NULL,
    committer_name TEXT,
    committer_date DATETIME,
    message TEXT,
    additions INTEGER,
    deletions INTEGER,
    total_changes INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS github_pull_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pr_number INTEGER NOT NULL,
    repo_name TEXT NOT NULL,
    title TEXT,
    state TEXT,                        -- 'open', 'closed', 'merged'
    author TEXT,
    created_at_gh DATETIME NOT NULL,
    updated_at_gh DATETIME,
    closed_at_gh DATETIME,
    merged_at_gh DATETIME,
    merged_by TEXT,
    additions INTEGER,
    deletions INTEGER,
    changed_files INTEGER,
    comments_count INTEGER,
    review_comments_count INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(repo_name, pr_number)
);

CREATE TABLE IF NOT EXISTS github_issues (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    issue_number INTEGER NOT NULL,
    repo_name TEXT NOT NULL,
    title TEXT,
    state TEXT,                        -- 'open', 'closed'
    author TEXT,
    assignee TEXT,
    labels TEXT,                       -- JSON array
    created_at_gh DATETIME NOT NULL,
    updated_at_gh DATETIME,
    closed_at_gh DATETIME,
    comments_count INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(repo_name, issue_number)
);

-- ============================================
-- JIRA RAW DATA TABLES
-- ============================================

CREATE TABLE IF NOT EXISTS jira_issues (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    issue_key TEXT UNIQUE NOT NULL,
    issue_id TEXT,
    project_key TEXT,
    summary TEXT,
    description TEXT,
    issue_type TEXT,
    status TEXT,
    priority TEXT,
    resolution TEXT,
    reporter TEXT,
    reporter_name TEXT,
    assignee TEXT,
    assignee_name TEXT,
    creator TEXT,
    created_at_jira DATETIME NOT NULL,
    updated_at_jira DATETIME,
    resolved_at_jira DATETIME,
    due_date DATETIME,
    story_points REAL,
    original_estimate_seconds INTEGER,
    time_spent_seconds INTEGER,
    remaining_estimate_seconds INTEGER,
    labels TEXT,                       -- JSON array
    components TEXT,                   -- JSON array
    fix_versions TEXT,                 -- JSON array
    attachments TEXT,                  -- JSON array with metadata
    environment TEXT,
    votes INTEGER DEFAULT 0,
    watchers INTEGER DEFAULT 0,
    sprint_id TEXT,
    sprint_name TEXT,
    custom_fields TEXT,                -- JSON object with ALL custom fields
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS jira_worklogs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    worklog_id TEXT UNIQUE NOT NULL,
    issue_key TEXT NOT NULL,
    author TEXT,
    time_spent_seconds INTEGER,
    started_at DATETIME NOT NULL,
    comment TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (issue_key) REFERENCES jira_issues(issue_key)
);

CREATE TABLE IF NOT EXISTS jira_status_transitions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    issue_key TEXT NOT NULL,
    from_status TEXT,
    to_status TEXT,
    transition_date DATETIME NOT NULL,
    author TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (issue_key) REFERENCES jira_issues(issue_key)
);

-- ============================================
-- FRESHDESK RAW DATA TABLES
-- ============================================

CREATE TABLE IF NOT EXISTS freshdesk_tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id INTEGER UNIQUE NOT NULL,
    subject TEXT,
    description TEXT,
    description_html TEXT,
    status TEXT,                       -- 'open', 'pending', 'resolved', 'closed'
    status_code INTEGER,
    priority TEXT,
    priority_code INTEGER,
    ticket_type TEXT,
    source TEXT,                       -- 'email', 'portal', 'phone', 'chat', etc.
    source_code INTEGER,
    requester_id INTEGER,
    requester_email TEXT,              -- PRIMARY JOIN KEY
    requester_name TEXT,
    requester_phone TEXT,
    requester_mobile TEXT,
    responder_id INTEGER,
    responder_email TEXT,              -- PRIMARY JOIN KEY
    responder_name TEXT,
    group_id INTEGER,
    group_name TEXT,
    company_id INTEGER,
    company_name TEXT,
    product_id INTEGER,
    created_at_fd DATETIME NOT NULL,
    updated_at_fd DATETIME,
    due_by DATETIME,
    fr_due_by DATETIME,                -- first response due by
    fr_escalated BOOLEAN DEFAULT 0,
    is_escalated BOOLEAN DEFAULT 0,
    resolved_at DATETIME,
    closed_at DATETIME,
    first_responded_at DATETIME,
    agent_responded_at DATETIME,
    requester_responded_at DATETIME,
    sla_policy_id INTEGER,
    tags TEXT,                         -- JSON array
    cc_emails TEXT,                    -- JSON array
    fwd_emails TEXT,                   -- JSON array
    email_config_id INTEGER,
    spam BOOLEAN DEFAULT 0,
    deleted BOOLEAN DEFAULT 0,
    association_type TEXT,
    associated_tickets_list TEXT,      -- JSON array
    internal_agent_id INTEGER,
    internal_group_id INTEGER,
    twitter_id TEXT,
    fb_post_id TEXT,
    nr_due_by DATETIME,
    nr_escalated BOOLEAN DEFAULT 0,
    custom_fields TEXT,                -- JSON object with ALL custom fields
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS freshdesk_conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER UNIQUE NOT NULL,
    ticket_id INTEGER NOT NULL,
    user_id INTEGER,
    user_name TEXT,
    body TEXT,
    incoming BOOLEAN,
    created_at_fd DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES freshdesk_tickets(ticket_id)
);

CREATE TABLE IF NOT EXISTS freshdesk_time_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    time_entry_id INTEGER UNIQUE NOT NULL,
    ticket_id INTEGER NOT NULL,
    agent_id INTEGER,
    agent_name TEXT,
    time_spent_seconds INTEGER,
    billable BOOLEAN,
    note TEXT,
    started_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES freshdesk_tickets(ticket_id)
);

-- ============================================
-- WINDSURF RAW DATA TABLES
-- ============================================

CREATE TABLE IF NOT EXISTS windsurf_user_activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    user_email TEXT,                   -- PRIMARY JOIN KEY
    user_name TEXT,
    date DATE NOT NULL,
    -- Chat metrics
    prompts_used INTEGER DEFAULT 0,
    messages_sent INTEGER DEFAULT 0,
    chat_sessions INTEGER DEFAULT 0,
    tokens_consumed INTEGER DEFAULT 0,
    model_used TEXT,
    -- Autocomplete metrics
    autocomplete_suggestions INTEGER DEFAULT 0,
    autocomplete_accepted INTEGER DEFAULT 0,
    autocomplete_rejected INTEGER DEFAULT 0,
    autocomplete_partial_accepted INTEGER DEFAULT 0,
    autocomplete_characters_inserted INTEGER DEFAULT 0,
    -- Commands
    commands_executed INTEGER DEFAULT 0,
    cascade_invocations INTEGER DEFAULT 0,
    terminal_commands INTEGER DEFAULT 0,
    file_operations INTEGER DEFAULT 0,
    -- Code generation
    code_generated_lines INTEGER DEFAULT 0,
    code_accepted_lines INTEGER DEFAULT 0,
    code_rejected_lines INTEGER DEFAULT 0,
    refactorings_applied INTEGER DEFAULT 0,
    -- Context
    files_opened INTEGER DEFAULT 0,
    projects_worked INTEGER DEFAULT 0,
    session_duration_seconds INTEGER DEFAULT 0,
    context_switches INTEGER DEFAULT 0,
    avg_response_time_ms INTEGER DEFAULT 0,
    -- Languages/frameworks
    languages_used TEXT,               -- JSON array
    frameworks_detected TEXT,          -- JSON array
    -- Quality
    errors_encountered INTEGER DEFAULT 0,
    successful_completions INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, date)
);

CREATE TABLE IF NOT EXISTS windsurf_tool_usage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    usage_count INTEGER,
    date DATE NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, tool_name, date)
);

CREATE TABLE IF NOT EXISTS windsurf_chat_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT UNIQUE NOT NULL,
    user_id TEXT NOT NULL,
    started_at DATETIME NOT NULL,
    ended_at DATETIME,
    messages_count INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- UNIFIED SCHEMA (Denormalized for easy querying)
-- ============================================

-- Single unified events table - combines all activity across systems
CREATE TABLE IF NOT EXISTS unified_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Source identification
    source TEXT NOT NULL,              -- 'github', 'jira', 'freshdesk', 'windsurf'
    event_type TEXT NOT NULL,          -- 'commit', 'pr_created', 'pr_merged', 'issue_created', 'issue_closed',
                                       -- 'ticket_created', 'ticket_resolved', 'status_change', 'code_activity'

    -- Core fields (denormalized)
    event_date DATE NOT NULL,
    event_timestamp DATETIME NOT NULL,

    -- People involved
    actor TEXT,                        -- person who performed the action (normalized email/username)
    actor_email TEXT,
    assignee TEXT,                     -- person assigned to work (for issues/tickets)

    -- Work item details
    work_item_id TEXT,                 -- external ID (PR#123, TICKET-456, etc)
    work_item_title TEXT,
    work_item_status TEXT,             -- current status

    -- Metrics
    duration_seconds INTEGER,          -- time spent (worklogs, time entries)
    change_volume INTEGER,             -- lines of code, file count, etc.

    -- Additional context (flexible JSON)
    metadata JSON,                     -- source-specific fields: {repo, sprint, priority, etc}

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    UNIQUE(source, event_type, work_item_id, event_timestamp)
);

-- Person mapping table (normalize names/emails across systems)
CREATE TABLE IF NOT EXISTS person_mapping (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    canonical_email TEXT UNIQUE NOT NULL,
    github_username TEXT,
    jira_username TEXT,
    freshdesk_id INTEGER,
    windsurf_user_id TEXT,
    display_name TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================

-- Watermarks
CREATE INDEX IF NOT EXISTS idx_watermarks_source ON sync_watermarks(source);

-- GitHub
CREATE INDEX IF NOT EXISTS idx_github_commits_date ON github_commits(author_date);
CREATE INDEX IF NOT EXISTS idx_github_commits_author ON github_commits(author_email);
CREATE INDEX IF NOT EXISTS idx_github_prs_created ON github_pull_requests(created_at_gh);
CREATE INDEX IF NOT EXISTS idx_github_prs_author ON github_pull_requests(author);
CREATE INDEX IF NOT EXISTS idx_github_issues_created ON github_issues(created_at_gh);

-- JIRA
CREATE INDEX IF NOT EXISTS idx_jira_issues_created ON jira_issues(created_at_jira);
CREATE INDEX IF NOT EXISTS idx_jira_issues_assignee ON jira_issues(assignee);
CREATE INDEX IF NOT EXISTS idx_jira_worklogs_started ON jira_worklogs(started_at);
CREATE INDEX IF NOT EXISTS idx_jira_worklogs_issue ON jira_worklogs(issue_key);

-- Freshdesk
CREATE INDEX IF NOT EXISTS idx_fd_tickets_created ON freshdesk_tickets(created_at_fd);
CREATE INDEX IF NOT EXISTS idx_fd_tickets_responder ON freshdesk_tickets(responder_id);
CREATE INDEX IF NOT EXISTS idx_fd_conversations_ticket ON freshdesk_conversations(ticket_id);

-- Windsurf
CREATE INDEX IF NOT EXISTS idx_windsurf_user_date ON windsurf_user_activity(user_id, date);
CREATE INDEX IF NOT EXISTS idx_windsurf_tool_date ON windsurf_tool_usage(date);

-- Unified events (critical for query performance)
CREATE INDEX IF NOT EXISTS idx_unified_events_date ON unified_events(event_date);
CREATE INDEX IF NOT EXISTS idx_unified_events_actor ON unified_events(actor);
CREATE INDEX IF NOT EXISTS idx_unified_events_type ON unified_events(event_type);
CREATE INDEX IF NOT EXISTS idx_unified_events_source ON unified_events(source);
CREATE INDEX IF NOT EXISTS idx_unified_events_source_type ON unified_events(source, event_type);
CREATE INDEX IF NOT EXISTS idx_unified_events_actor_date ON unified_events(actor, event_date);
