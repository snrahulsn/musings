"""
Database connection and initialization module
Handles SQLite connection, schema setup, and query execution
"""

import sqlite3
import json
from typing import List, Dict, Any, Optional
from pathlib import Path
from datetime import datetime
import structlog

logger = structlog.get_logger()


class Database:
    """SQLite database manager"""

    def __init__(self, db_path: str = "pulse_data.db"):
        """
        Initialize database connection

        Args:
            db_path: Path to SQLite database file
        """
        self.db_path = db_path
        self.conn = None
        self._connect()

    def _connect(self):
        """Establish database connection"""
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row  # Return rows as dictionaries
        self.conn.execute("PRAGMA foreign_keys = ON")  # Enable foreign keys
        self.conn.execute("PRAGMA journal_mode = WAL")  # Better concurrency
        logger.info("database_connected", path=self.db_path)

    def initialize_schema(self, schema_path: str = None):
        """
        Initialize database schema from SQL file

        Args:
            schema_path: Path to schema.sql file
        """
        if schema_path is None:
            schema_path = Path(__file__).parent / "schema.sql"

        with open(schema_path, 'r') as f:
            schema_sql = f.read()

        cursor = self.conn.cursor()
        cursor.executescript(schema_sql)
        self.conn.commit()
        logger.info("schema_initialized", path=schema_path)

    def execute_query(
        self,
        sql: str,
        parameters: Dict[str, Any] = None
    ) -> List[Dict[str, Any]]:
        """
        Execute a SELECT query and return results

        Args:
            sql: SQL query string
            parameters: Query parameters

        Returns:
            List of result rows as dictionaries
        """
        cursor = self.conn.cursor()

        try:
            if parameters:
                cursor.execute(sql, parameters)
            else:
                cursor.execute(sql)

            rows = cursor.fetchall()
            results = [dict(row) for row in rows]

            logger.info(
                "query_executed",
                sql=sql[:100],
                params=parameters,
                result_count=len(results)
            )

            return results

        except Exception as e:
            logger.error("query_failed", sql=sql, error=str(e))
            raise

    def execute_insert(
        self,
        table: str,
        data: Dict[str, Any],
        ignore_duplicates: bool = True
    ) -> Optional[int]:
        """
        Insert a row into a table

        Args:
            table: Table name
            data: Dictionary of column: value pairs
            ignore_duplicates: Use INSERT OR IGNORE to skip duplicates

        Returns:
            Last inserted row ID or None
        """
        columns = list(data.keys())
        placeholders = [f":{col}" for col in columns]

        insert_clause = "INSERT OR IGNORE" if ignore_duplicates else "INSERT"
        sql = f"{insert_clause} INTO {table} ({', '.join(columns)}) VALUES ({', '.join(placeholders)})"

        cursor = self.conn.cursor()

        try:
            cursor.execute(sql, data)
            self.conn.commit()
            return cursor.lastrowid if cursor.lastrowid > 0 else None

        except Exception as e:
            logger.error("insert_failed", table=table, error=str(e))
            self.conn.rollback()
            raise

    def execute_bulk_insert(
        self,
        table: str,
        rows: List[Dict[str, Any]],
        ignore_duplicates: bool = True
    ) -> int:
        """
        Insert multiple rows efficiently

        Args:
            table: Table name
            rows: List of dictionaries
            ignore_duplicates: Use INSERT OR IGNORE

        Returns:
            Number of rows inserted
        """
        if not rows:
            return 0

        columns = list(rows[0].keys())
        placeholders = [f":{col}" for col in columns]

        insert_clause = "INSERT OR IGNORE" if ignore_duplicates else "INSERT"
        sql = f"{insert_clause} INTO {table} ({', '.join(columns)}) VALUES ({', '.join(placeholders)})"

        cursor = self.conn.cursor()

        try:
            cursor.executemany(sql, rows)
            self.conn.commit()
            inserted = cursor.rowcount
            logger.info("bulk_insert_completed", table=table, rows=inserted)
            return inserted

        except Exception as e:
            logger.error("bulk_insert_failed", table=table, error=str(e))
            self.conn.rollback()
            raise

    def get_watermark(self, source: str) -> Dict[str, Any]:
        """
        Get sync watermark for a data source

        Args:
            source: Source name (github, jira, etc.)

        Returns:
            Watermark dictionary with last_sync_at, last_sync_cursor, metadata
        """
        sql = """
            SELECT last_sync_at, last_sync_cursor, metadata
            FROM sync_watermarks
            WHERE source = :source
        """

        results = self.execute_query(sql, {"source": source})

        if results:
            row = results[0]
            return {
                "last_sync_at": row["last_sync_at"],
                "last_sync_cursor": row["last_sync_cursor"],
                "metadata": json.loads(row["metadata"]) if row["metadata"] else {}
            }

        return {
            "last_sync_at": None,
            "last_sync_cursor": None,
            "metadata": {}
        }

    def update_watermark(
        self,
        source: str,
        last_sync_at: str = None,
        last_sync_cursor: str = None,
        metadata: Dict[str, Any] = None
    ):
        """
        Update sync watermark for a data source

        Args:
            source: Source name
            last_sync_at: ISO timestamp of last sync
            last_sync_at: Pagination cursor
            metadata: Additional metadata
        """
        data = {
            "source": source,
            "last_sync_at": last_sync_at or datetime.utcnow().isoformat(),
            "last_sync_cursor": last_sync_cursor,
            "metadata": json.dumps(metadata) if metadata else None,
            "updated_at": datetime.utcnow().isoformat()
        }

        sql = """
            INSERT INTO sync_watermarks (source, last_sync_at, last_sync_cursor, metadata, updated_at)
            VALUES (:source, :last_sync_at, :last_sync_cursor, :metadata, :updated_at)
            ON CONFLICT(source) DO UPDATE SET
                last_sync_at = excluded.last_sync_at,
                last_sync_cursor = excluded.last_sync_cursor,
                metadata = excluded.metadata,
                updated_at = excluded.updated_at
        """

        cursor = self.conn.cursor()
        cursor.execute(sql, data)
        self.conn.commit()

        logger.info("watermark_updated", source=source, timestamp=data["last_sync_at"])

    def close(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()
            logger.info("database_closed")

    def __enter__(self):
        """Context manager entry"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.close()


# Global database instance
_db_instance: Optional[Database] = None


def get_db(db_path: str = "pulse_data.db") -> Database:
    """Get or create global database instance"""
    global _db_instance
    if _db_instance is None:
        _db_instance = Database(db_path)
    return _db_instance


def init_db(db_path: str = "pulse_data.db", schema_path: str = None):
    """Initialize database with schema"""
    db = get_db(db_path)
    db.initialize_schema(schema_path)
    return db
