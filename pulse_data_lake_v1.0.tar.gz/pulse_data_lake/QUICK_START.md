# Quick Start Guide

## 5-Minute Setup

### 1. Install Dependencies (2 min)
```bash
cd pulse_data_lake
source venv/bin/activate
pip install -r requirements.txt
```

### 2. Configure (2 min)
```bash
# Copy example config
cp config/config.example.yaml config/config.yaml

# Edit with your API keys
nano config/config.yaml  # or use your editor
```

**Minimum required:**
- GitHub token: https://github.com/settings/tokens (scope: `repo`)
- OpenAI API key: https://platform.openai.com/api-keys (for LLM fallback)

### 3. Initialize Database (1 min)
```bash
python3 << EOF
from db.database import init_db
init_db()
print("✅ Database initialized!")
EOF
```

### 4. Test Query System (1 min)
```bash
python3 << EOF
from chat.intent_classifier import classify_intent
from chat.query_bank import ALL_QUERIES

# Test intent classification
question = "How many PRs did john merge last month?"
query, params, confidence = classify_intent(question)

print(f"Question: {question}")
print(f"Matched Query: {query.name if query else 'None'}")
print(f"Confidence: {confidence}%")
print(f"Parameters: {params}")
print(f"\nSQL Template:\n{query.sql_template if query else 'N/A'}")
EOF
```

Expected output:
```
Question: How many PRs did john merge last month?
Matched Query: PRs Merged by Developer
Confidence: 87.3%
Parameters: {'developer': 'john', 'start_date': '2025-09-01', 'end_date': '2025-10-01'}

SQL Template:
SELECT actor, COUNT(*) as merged_count
FROM unified_events
WHERE event_type = 'pr_merged' AND actor = :developer ...
```

## What's Working Now

✅ **Query Intelligence** (No coding needed)
- 40 predefined analytical queries
- Intent classification via fuzzy matching
- Time period extraction ("last month", "this week")
- Developer name extraction
- LLM fallback for complex questions

✅ **Database** (No data yet, structure ready)
- Schema created
- Indexes applied
- Watermark tracking ready

## Next Steps to Get Data

### Option A: Manual Test Data (Quick)
```bash
# Create sample data for testing
python3 << EOF
from db.database import get_db
from datetime import datetime, timedelta

db = get_db()

# Insert sample events
sample_events = [
    {
        "source": "github",
        "event_type": "pr_merged",
        "event_date": (datetime.now() - timedelta(days=1)).date().isoformat(),
        "event_timestamp": (datetime.now() - timedelta(days=1)).isoformat(),
        "actor": "john@example.com",
        "work_item_id": "PR#123",
        "work_item_title": "Add new feature",
        "change_volume": 150
    },
    {
        "source": "jira",
        "event_type": "issue_closed",
        "event_date": datetime.now().date().isoformat(),
        "event_timestamp": datetime.now().isoformat(),
        "actor": "sarah@example.com",
        "work_item_id": "PROJ-456",
        "work_item_title": "Fix bug in login",
        "duration_seconds": 7200
    }
]

for event in sample_events:
    db.execute_insert("unified_events", event)

print("✅ Sample data inserted!")
print(f"Total events: {db.execute_query('SELECT COUNT(*) as count FROM unified_events')[0]['count']}")
EOF
```

### Option B: Build Ingestion Jobs (Production)
Follow `IMPLEMENTATION_STATUS.md` to build:
1. GitHub poller → Fetch commits, PRs, issues
2. JIRA poller → Fetch issues, worklogs
3. Transformer → Map to unified schema

## Test Queries (With Sample Data)

```bash
# Count events by source
python3 << EOF
from db.database import get_db

db = get_db()
results = db.execute_query("""
    SELECT source, event_type, COUNT(*) as count
    FROM unified_events
    GROUP BY source, event_type
""")

for row in results:
    print(f"{row['source']}.{row['event_type']}: {row['count']} events")
EOF
```

## Test LLM Fallback

```bash
# Make sure OPENAI_API_KEY is set
export OPENAI_API_KEY="sk-your-key-here"

python3 << EOF
from chat.gpt_fallback import create_llm_fallback

config = {
    "provider": "openai",
    "model": "gpt-4o-mini",  # Cheaper for testing
    "api_key": "$OPENAI_API_KEY"
}

llm = create_llm_fallback(config)

question = "Show me all events from last week"
sql, error = llm.generate_sql(question)

if error:
    print(f"Error: {error}")
else:
    print(f"Generated SQL:\n{sql}")
EOF
```

## Common Issues

### Issue: `ModuleNotFoundError: No module named 'pydantic'`
**Solution:**
```bash
source venv/bin/activate  # Make sure venv is active!
pip install -r requirements.txt
```

### Issue: `FileNotFoundError: config/config.yaml`
**Solution:**
```bash
cp config/config.example.yaml config/config.yaml
```

### Issue: `openai.AuthenticationError`
**Solution:**
```bash
export OPENAI_API_KEY="sk-your-actual-key"
# Or edit config/config.yaml and add your key
```

### Issue: Database locked
**Solution:**
```bash
sqlite3 pulse_data.db "PRAGMA journal_mode=WAL;"
```

## Explore the Query Bank

```bash
# List all available queries
python3 << EOF
from chat.query_bank import ALL_QUERIES

print(f"Total queries available: {len(ALL_QUERIES)}\n")

categories = {}
for q in ALL_QUERIES:
    if q.category not in categories:
        categories[q.category] = []
    categories[q.category].append(q)

for category, queries in categories.items():
    print(f"\n{category.upper()} ({len(queries)} queries)")
    print("=" * 50)
    for q in queries:
        print(f"  • {q.name}")
        print(f"    Example: {q.example_question}")
EOF
```

## Test Intent Classification Accuracy

```bash
python3 << EOF
from chat.intent_classifier import classify_intent

test_questions = [
    "How many PRs did john merge last month?",
    "What's our team's velocity this sprint?",
    "Show me commit trends for the last week",
    "Which developers are most active?",
    "What's the average cycle time?",
    "Is our support load increasing?",
]

print("Testing Intent Classification\n" + "="*60)

for question in test_questions:
    query, params, confidence = classify_intent(question)

    print(f"\nQ: {question}")
    print(f"   Matched: {query.name if query else 'NONE'}")
    print(f"   Confidence: {confidence:.1f}%")
    print(f"   Method: {'✓ Intent Classifier' if confidence >= 30 else '✗ LLM Fallback Needed'}")
EOF
```

## Check System Status

```bash
# Database status
python3 << EOF
from db.database import get_db

db = get_db()

# Tables
tables = db.execute_query("""
    SELECT name FROM sqlite_master
    WHERE type='table' AND name NOT LIKE 'sqlite_%'
    ORDER BY name
""")

print("Database Tables:")
for t in tables:
    count = db.execute_query(f"SELECT COUNT(*) as count FROM {t['name']}")[0]['count']
    print(f"  • {t['name']}: {count} rows")

# Watermarks
print("\nSync Watermarks:")
watermarks = db.execute_query("SELECT * FROM sync_watermarks")
if watermarks:
    for w in watermarks:
        print(f"  • {w['source']}: {w['last_sync_at'] or 'Never synced'}")
else:
    print("  (No syncs yet)")
EOF
```

## Development Workflow

### 1. Add a New Query Template
```python
# Edit chat/query_bank.py

NEW_QUERY = QueryTemplate(
    id="my_custom_query",
    category="custom",
    name="My Custom Metric",
    description="What it does",
    keywords=["keyword1", "keyword2"],
    sql_template="""
        SELECT ...
        FROM unified_events
        WHERE ...
    """,
    parameters=["param1", "param2"],
    example_question="Example question?"
)

# Add to appropriate list (DEVELOPER_QUERIES, TEAM_QUERIES, etc.)
```

### 2. Test It
```python
from chat.intent_classifier import classify_intent

query, params, confidence = classify_intent("your test question")
print(f"Matched: {query.id if query else 'None'}")
```

### 3. Execute Against Real Data
```python
from db.database import get_db

db = get_db()
results = db.execute_query(query.sql_template, params)
print(results)
```

## What to Build Next

**Priority 1: Get Real Data**
1. Build GitHub poller (`ingest/github_poller.py`)
2. Test with one repo first
3. Verify data in `unified_events`

**Priority 2: API Server**
1. Create `api/main.py`
2. Implement `/query` endpoint
3. Test with curl

**Priority 3: Automate**
1. Create `scheduler.py`
2. Run pollers every 30 min
3. Start on boot

## Useful Commands

```bash
# Activate environment
source venv/bin/activate

# Check database
sqlite3 pulse_data.db "SELECT * FROM unified_events LIMIT 5"

# Run Python interactively with modules loaded
python3 -i << EOF
from db.database import get_db
from chat.intent_classifier import classify_intent
from chat.query_bank import ALL_QUERIES
db = get_db()
print("Ready! Try: classify_intent('your question')")
EOF

# Reset database (DANGER: deletes all data)
rm pulse_data.db
python3 -c "from db.database import init_db; init_db()"
```

## Help & Debugging

### Enable Debug Logging
```python
import structlog
import logging

logging.basicConfig(level=logging.DEBUG)
structlog.configure(wrapper_class=structlog.make_filtering_bound_logger(logging.DEBUG))
```

### Inspect Database Schema
```bash
sqlite3 pulse_data.db ".schema unified_events"
```

### Test LLM Without API Key
```python
# Use intent classifier only (no LLM needed)
from chat.intent_classifier import classify_intent

query, params, conf = classify_intent("How many PRs this week?")
print(f"Can answer without LLM: {conf >= 30}")
```

## Resources

- **Full Documentation**: `README.md`
- **Implementation Guide**: `IMPLEMENTATION_STATUS.md`
- **Technical Details**: `TECHNICAL_ANALYSIS.md`
- **Project Overview**: `PROJECT_SUMMARY.md`

---

**You're all set!** The query intelligence is ready. Build the ingestion jobs to start getting real insights.
