"""
Intent Classifier for Natural Language Query Matching

Uses fuzzy string matching to map user questions to predefined query templates.
No ML required - simple, fast, and effective for structured queries.
"""

from typing import List, Tuple, Optional, Dict, Any
from datetime import datetime, timedelta
import re
from fuzzywuzzy import fuzz
from dateutil import parser as date_parser
from dateutil.relativedelta import relativedelta

from chat.query_bank import QueryTemplate, ALL_QUERIES


class IntentClassifier:
    """Maps natural language questions to SQL query templates"""

    def __init__(self, queries: List[QueryTemplate] = None):
        self.queries = queries or ALL_QUERIES
        self.time_patterns = self._build_time_patterns()

    def _build_time_patterns(self) -> Dict[str, Any]:
        """Build regex patterns for time period extraction"""
        return {
            'last_week': {
                'patterns': [r'last week', r'previous week', r'past week'],
                'delta': {'weeks': 1}
            },
            'last_month': {
                'patterns': [r'last month', r'previous month', r'past month'],
                'delta': {'months': 1}
            },
            'last_quarter': {
                'patterns': [r'last quarter', r'previous quarter', r'past quarter', r'this quarter'],
                'delta': {'months': 3}
            },
            'last_year': {
                'patterns': [r'last year', r'previous year', r'past year'],
                'delta': {'years': 1}
            },
            'this_week': {
                'patterns': [r'this week', r'current week'],
                'delta': {'days': 7}
            },
            'this_month': {
                'patterns': [r'this month', r'current month'],
                'delta': {'days': 30}
            },
            'yesterday': {
                'patterns': [r'yesterday'],
                'delta': {'days': 1}
            },
            'today': {
                'patterns': [r'today'],
                'delta': {'days': 0}
            },
            'last_sprint': {
                'patterns': [r'last sprint', r'previous sprint'],
                'delta': {'weeks': 2}
            },
        }

    def classify(self, question: str) -> Tuple[Optional[QueryTemplate], Dict[str, Any], float]:
        """
        Classify a natural language question to a query template

        Returns:
            - QueryTemplate: Best matching template (or None)
            - Dict: Extracted parameters
            - float: Confidence score (0-100)
        """
        question_lower = question.lower().strip()

        # Extract parameters from question
        params = self._extract_parameters(question_lower)

        # Find best matching query
        best_match = None
        best_score = 0.0

        for query in self.queries:
            score = self._calculate_match_score(question_lower, query)

            if score > best_score:
                best_score = score
                best_match = query

        # Validate we have required parameters
        if best_match and best_score >= 30:  # Minimum threshold
            missing_params = self._check_required_params(best_match, params)
            if missing_params:
                # Try to infer missing parameters with defaults
                params = self._add_default_params(params, missing_params)

            return best_match, params, best_score

        return None, params, 0.0

    def _calculate_match_score(self, question: str, query: QueryTemplate) -> float:
        """Calculate how well a question matches a query template"""
        scores = []

        # 1. Fuzzy match against query name
        name_score = fuzz.partial_ratio(question, query.name.lower())
        scores.append(name_score * 1.2)  # Weight name matching higher

        # 2. Fuzzy match against description
        desc_score = fuzz.partial_ratio(question, query.description.lower())
        scores.append(desc_score)

        # 3. Keyword matching (most important)
        keyword_score = 0
        for keyword in query.keywords:
            if keyword.lower() in question:
                keyword_score += 20  # Exact keyword match is strong signal
            else:
                # Fuzzy match for typos
                fuzzy = fuzz.partial_ratio(question, keyword.lower())
                if fuzzy > 80:
                    keyword_score += 10

        scores.append(min(keyword_score, 100))  # Cap at 100

        # 4. Example question similarity
        example_score = fuzz.token_set_ratio(question, query.example_question.lower())
        scores.append(example_score * 0.8)

        # Average all scores
        return sum(scores) / len(scores)

    def _extract_parameters(self, question: str) -> Dict[str, Any]:
        """Extract parameters from the question"""
        params = {}

        # Extract person/developer name (email or name)
        person_match = re.search(r'(?:for|by|from)\s+([a-zA-Z]+(?:@[a-zA-Z0-9.-]+)?)', question)
        if person_match:
            params['developer'] = person_match.group(1)
        else:
            # Look for standalone email
            email_match = re.search(r'([a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+)', question)
            if email_match:
                params['developer'] = email_match.group(1)
            else:
                # Look for common names (John, Sarah, etc.)
                name_match = re.search(r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\b', question)
                if name_match:
                    params['developer'] = name_match.group(1).lower()

        # Extract time periods
        time_params = self._extract_time_period(question)
        params.update(time_params)

        return params

    def _extract_time_period(self, question: str) -> Dict[str, str]:
        """Extract start and end dates from time expressions"""
        today = datetime.now().date()

        for period_name, period_config in self.time_patterns.items():
            for pattern in period_config['patterns']:
                if re.search(pattern, question):
                    delta = period_config['delta']

                    if 'years' in delta:
                        start_date = today - relativedelta(years=delta['years'])
                    elif 'months' in delta:
                        start_date = today - relativedelta(months=delta['months'])
                    elif 'weeks' in delta:
                        start_date = today - timedelta(weeks=delta['weeks'])
                    elif 'days' in delta:
                        start_date = today - timedelta(days=delta['days'])
                    else:
                        start_date = today

                    return {
                        'start_date': start_date.isoformat(),
                        'end_date': today.isoformat()
                    }

        # Try to parse explicit dates
        date_matches = re.findall(r'\d{4}-\d{2}-\d{2}', question)
        if len(date_matches) >= 2:
            return {
                'start_date': date_matches[0],
                'end_date': date_matches[1]
            }
        elif len(date_matches) == 1:
            return {
                'start_date': date_matches[0],
                'end_date': today.isoformat()
            }

        # Default: last 30 days
        return {
            'start_date': (today - timedelta(days=30)).isoformat(),
            'end_date': today.isoformat()
        }

    def _check_required_params(self, query: QueryTemplate, params: Dict[str, Any]) -> List[str]:
        """Check which required parameters are missing"""
        missing = []
        for param in query.parameters:
            if param not in params:
                missing.append(param)
        return missing

    def _add_default_params(self, params: Dict[str, Any], missing: List[str]) -> Dict[str, Any]:
        """Add default values for missing parameters"""
        defaults = {
            'start_date': (datetime.now().date() - timedelta(days=30)).isoformat(),
            'end_date': datetime.now().date().isoformat(),
            'developer': None,  # Will need to prompt user or use wildcard
        }

        for param in missing:
            if param in defaults:
                params[param] = defaults[param]

        return params

    def get_clarification_message(self, missing_params: List[str]) -> str:
        """Generate a clarification message for missing parameters"""
        if 'developer' in missing_params:
            return "Which developer are you asking about? Please specify a name or email."
        if 'start_date' in missing_params or 'end_date' in missing_params:
            return "What time period do you want to analyze? (e.g., 'last month', 'this quarter')"
        return "Could you provide more details? I need: " + ", ".join(missing_params)


# Convenience function
def classify_intent(question: str) -> Tuple[Optional[QueryTemplate], Dict[str, Any], float]:
    """Classify a natural language question"""
    classifier = IntentClassifier()
    return classifier.classify(question)
