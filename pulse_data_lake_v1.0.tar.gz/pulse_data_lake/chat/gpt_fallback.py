"""
Configurable LLM Fallback for Complex Queries

When intent classifier fails, fall back to LLM (GPT-4o, Claude, Gemini, etc.)
to generate SQL from natural language with full schema context.
"""

from typing import Dict, Any, Optional, List
from enum import Enum
import json
from openai import OpenAI


class LLMProvider(Enum):
    """Supported LLM providers"""
    OPENAI = "openai"  # GPT-4o, GPT-4, etc.
    ANTHROPIC = "anthropic"  # Claude Sonnet, Opus, etc.
    GOOGLE = "google"  # Gemini Pro, etc.
    CUSTOM = "custom"  # Any OpenAI-compatible API


class LLMFallback:
    """
    LLM fallback for generating SQL from natural language
    Supports multiple providers via configuration
    """

    def __init__(
        self,
        provider: str = "openai",
        model: str = "gpt-4o",
        api_key: str = None,
        base_url: str = None,
        schema_context: str = None
    ):
        """
        Initialize LLM fallback

        Args:
            provider: LLM provider (openai, anthropic, google, custom)
            model: Model name (gpt-4o, claude-sonnet-4, gemini-pro, etc.)
            api_key: API key for the provider
            base_url: Custom API endpoint (for OpenAI-compatible APIs)
            schema_context: Database schema description
        """
        self.provider = provider
        self.model = model
        self.schema_context = schema_context or self._get_default_schema()

        # Initialize client based on provider
        if provider == "openai" or provider == "custom":
            self.client = OpenAI(
                api_key=api_key,
                base_url=base_url  # None for OpenAI, custom URL for others
            )
        elif provider == "anthropic":
            # Would use anthropic library here
            raise NotImplementedError("Anthropic support coming soon - use OpenAI-compatible endpoint for now")
        elif provider == "google":
            # Would use google.generativeai here
            raise NotImplementedError("Google support coming soon - use OpenAI-compatible endpoint for now")

    def _get_default_schema(self) -> str:
        """Get default schema description for context"""
        return """
# Database Schema

## Main Table: unified_events

This is a denormalized table containing all activity across systems.

Columns:
- id: Primary key
- source: TEXT - Data source ('github', 'jira', 'freshdesk', 'windsurf')
- event_type: TEXT - Type of event ('commit', 'pr_created', 'pr_merged', 'issue_created', 'issue_closed', 'ticket_created', 'ticket_resolved', etc.)
- event_date: DATE - Date of event
- event_timestamp: DATETIME - Full timestamp
- actor: TEXT - Person who performed the action (email or username)
- actor_email: TEXT - Actor's email
- assignee: TEXT - Person assigned to work item
- work_item_id: TEXT - External ID (PR#123, TICKET-456, etc.)
- work_item_title: TEXT - Title/subject
- work_item_status: TEXT - Current status
- duration_seconds: INTEGER - Time spent (for worklogs/time tracking)
- change_volume: INTEGER - Lines of code changed, file count, etc.
- metadata: JSON - Additional source-specific fields

## Event Types by Source

GitHub:
- commit
- pr_created
- pr_merged
- pr_reviewed
- issue_created
- issue_closed

JIRA:
- issue_created
- issue_closed
- status_change
- worklog

Freshdesk:
- ticket_created
- ticket_resolved
- ticket_closed
- conversation

Windsurf:
- code_activity (contains AI usage metrics in metadata)

## Common Query Patterns

1. Count events: SELECT COUNT(*) FROM unified_events WHERE ...
2. Group by actor: GROUP BY actor
3. Time ranges: WHERE event_date >= :start AND event_date <= :end
4. Filter by source: WHERE source = 'github'
5. Join metadata: WHERE json_extract(metadata, '$.field') = 'value'

## Important Notes
- Always use parameterized queries with :param_name syntax
- Dates should be in ISO format (YYYY-MM-DD)
- SQLite JSON functions: json_extract(column, '$.path')
- Time calculations: julianday() for date math
"""

    def generate_sql(
        self,
        question: str,
        parameters: Dict[str, Any] = None
    ) -> tuple[Optional[str], Optional[str]]:
        """
        Generate SQL query from natural language question

        Args:
            question: Natural language question
            parameters: Extracted parameters (optional)

        Returns:
            Tuple of (SQL query string, error message if any)
        """
        system_prompt = f"""You are a SQL expert. Generate SQLite queries based on user questions.

{self.schema_context}

Rules:
1. Generate ONLY valid SQLite SELECT queries
2. Use parameterized queries with :param_name for user inputs
3. Return ONLY the SQL query, no explanations
4. Use proper date handling with julianday() for calculations
5. Group and aggregate appropriately
6. Add LIMIT clauses for large result sets
7. Validate against the schema - don't hallucinate columns

If the question cannot be answered with the available data, return: "CANNOT_ANSWER: reason"
"""

        user_prompt = f"Question: {question}"

        if parameters:
            user_prompt += f"\n\nExtracted parameters: {json.dumps(parameters)}"

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.1,  # Low temperature for consistent SQL generation
                max_tokens=500
            )

            sql_query = response.choices[0].message.content.strip()

            # Basic validation
            if sql_query.startswith("CANNOT_ANSWER:"):
                return None, sql_query.replace("CANNOT_ANSWER:", "").strip()

            # Remove markdown code blocks if present
            sql_query = sql_query.replace("```sql", "").replace("```", "").strip()

            # Basic SQL injection prevention
            if not self._is_safe_query(sql_query):
                return None, "Generated query failed safety validation"

            return sql_query, None

        except Exception as e:
            return None, f"LLM error: {str(e)}"

    def _is_safe_query(self, sql: str) -> bool:
        """Basic safety check for generated SQL"""
        sql_upper = sql.upper()

        # Must be a SELECT query
        if not sql_upper.strip().startswith("SELECT"):
            return False

        # No dangerous operations
        dangerous_keywords = [
            "DROP", "DELETE", "INSERT", "UPDATE", "ALTER",
            "CREATE", "TRUNCATE", "EXEC", "EXECUTE", "--", ";"
        ]

        for keyword in dangerous_keywords:
            if keyword in sql_upper:
                return False

        return True

    def generate_explanation(self, sql: str, results: List[Dict[str, Any]]) -> str:
        """
        Generate natural language explanation of SQL results

        Args:
            sql: The SQL query that was executed
            results: Query results

        Returns:
            Natural language explanation
        """
        if not results:
            return "No results found for your query."

        system_prompt = """You are a helpful assistant that explains data insights.
Given a SQL query and its results, provide a concise natural language summary.
Focus on key insights and trends. Be specific with numbers."""

        user_prompt = f"""SQL Query:
{sql}

Results (showing first 10 rows):
{json.dumps(results[:10], indent=2)}

Provide a brief, insightful summary of these results."""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.7,
                max_tokens=300
            )

            return response.choices[0].message.content.strip()

        except Exception as e:
            # Fallback to simple summary
            return f"Found {len(results)} results. Top result: {json.dumps(results[0])}"


def create_llm_fallback(config: Dict[str, Any]) -> LLMFallback:
    """
    Create LLM fallback from configuration

    Config format:
    {
        "provider": "openai",  # or "anthropic", "google", "custom"
        "model": "gpt-4o",
        "api_key": "sk-...",
        "base_url": None  # For custom OpenAI-compatible APIs
    }
    """
    return LLMFallback(
        provider=config.get("provider", "openai"),
        model=config.get("model", "gpt-4o"),
        api_key=config.get("api_key"),
        base_url=config.get("base_url")
    )
