"""
Comprehensive Query Bank for Operational Metrics

This module contains 40+ predefined SQL query templates covering:
- Individual developer metrics
- Team performance
- Cross-system insights
- Time-based trends
"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import json


@dataclass
class QueryTemplate:
    """Template for a predefined analytical query"""
    id: str
    category: str
    name: str
    description: str
    keywords: List[str]  # For intent matching
    sql_template: str
    parameters: List[str]  # Expected parameter names
    example_question: str


# ============================================
# INDIVIDUAL DEVELOPER METRICS (12 queries)
# ============================================

DEVELOPER_QUERIES = [
    QueryTemplate(
        id="dev_pr_count",
        category="developer",
        name="PR Count by Developer",
        description="Count pull requests created by a developer in a time period",
        keywords=["pull request", "pr", "created", "authored", "developer", "how many"],
        sql_template="""
            SELECT
                actor as developer,
                COUNT(*) as pr_count
            FROM unified_events
            WHERE event_type = 'pr_created'
                AND actor = :developer
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY actor
        """,
        parameters=["developer", "start_date", "end_date"],
        example_question="How many PRs did john@example.com create last month?"
    ),

    QueryTemplate(
        id="dev_pr_merged",
        category="developer",
        name="PRs Merged by Developer",
        description="Count merged pull requests for a developer",
        keywords=["merged", "pr", "pull request", "completed", "developer"],
        sql_template="""
            SELECT
                actor as developer,
                COUNT(*) as merged_count
            FROM unified_events
            WHERE event_type = 'pr_merged'
                AND actor = :developer
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY actor
        """,
        parameters=["developer", "start_date", "end_date"],
        example_question="How many PRs did Sarah merge this quarter?"
    ),

    QueryTemplate(
        id="dev_commit_frequency",
        category="developer",
        name="Commit Frequency",
        description="Daily commit count for a developer",
        keywords=["commit", "frequency", "daily", "activity", "developer"],
        sql_template="""
            SELECT
                event_date as date,
                COUNT(*) as commit_count,
                SUM(change_volume) as total_lines_changed
            FROM unified_events
            WHERE event_type = 'commit'
                AND actor = :developer
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY event_date
            ORDER BY event_date DESC
        """,
        parameters=["developer", "start_date", "end_date"],
        example_question="What's John's daily commit activity this week?"
    ),

    QueryTemplate(
        id="dev_issue_resolution",
        category="developer",
        name="Issues Resolved by Developer",
        description="Count issues/tickets resolved by a developer",
        keywords=["issue", "resolved", "closed", "fixed", "developer", "tickets"],
        sql_template="""
            SELECT
                actor as developer,
                source,
                COUNT(*) as resolved_count
            FROM unified_events
            WHERE event_type IN ('issue_closed', 'ticket_resolved')
                AND actor = :developer
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY actor, source
        """,
        parameters=["developer", "start_date", "end_date"],
        example_question="How many issues did Jane resolve last sprint?"
    ),

    QueryTemplate(
        id="dev_time_spent",
        category="developer",
        name="Time Logged by Developer",
        description="Total time spent by developer on work items",
        keywords=["time", "hours", "spent", "worked", "logged", "developer"],
        sql_template="""
            SELECT
                actor as developer,
                SUM(duration_seconds) / 3600.0 as hours_logged,
                COUNT(DISTINCT work_item_id) as items_worked_on
            FROM unified_events
            WHERE duration_seconds IS NOT NULL
                AND actor = :developer
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY actor
        """,
        parameters=["developer", "start_date", "end_date"],
        example_question="How many hours did Bob log last week?"
    ),

    QueryTemplate(
        id="dev_code_review_activity",
        category="developer",
        name="Code Review Activity",
        description="PRs reviewed by a developer",
        keywords=["review", "reviewed", "code review", "pr review"],
        sql_template="""
            SELECT
                actor as reviewer,
                COUNT(*) as reviews_count
            FROM unified_events
            WHERE event_type = 'pr_reviewed'
                AND actor = :developer
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY actor
        """,
        parameters=["developer", "start_date", "end_date"],
        example_question="How many PRs did Alice review this month?"
    ),

    QueryTemplate(
        id="dev_ai_usage",
        category="developer",
        name="AI Tool Usage by Developer",
        description="Windsurf AI usage metrics for a developer",
        keywords=["ai", "windsurf", "copilot", "autocomplete", "assistant"],
        sql_template="""
            SELECT
                actor as developer,
                SUM(CASE WHEN metadata->>'metric_type' = 'autocomplete_accepted'
                    THEN CAST(metadata->>'value' AS INTEGER) ELSE 0 END) as autocomplete_used,
                SUM(CASE WHEN metadata->>'metric_type' = 'chat_messages'
                    THEN CAST(metadata->>'value' AS INTEGER) ELSE 0 END) as ai_chat_messages
            FROM unified_events
            WHERE source = 'windsurf'
                AND actor = :developer
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY actor
        """,
        parameters=["developer", "start_date", "end_date"],
        example_question="How much is Tom using AI coding assistants?"
    ),

    QueryTemplate(
        id="dev_work_distribution",
        category="developer",
        name="Work Distribution by Type",
        description="Breakdown of work types for a developer",
        keywords=["breakdown", "distribution", "work types", "activity"],
        sql_template="""
            SELECT
                event_type,
                COUNT(*) as count
            FROM unified_events
            WHERE actor = :developer
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY event_type
            ORDER BY count DESC
        """,
        parameters=["developer", "start_date", "end_date"],
        example_question="What type of work is Emma doing most?"
    ),

    QueryTemplate(
        id="dev_avg_pr_size",
        category="developer",
        name="Average PR Size",
        description="Average code change volume per PR",
        keywords=["average", "pr size", "lines changed", "code volume"],
        sql_template="""
            SELECT
                actor as developer,
                AVG(change_volume) as avg_lines_changed,
                MIN(change_volume) as min_lines,
                MAX(change_volume) as max_lines
            FROM unified_events
            WHERE event_type = 'pr_created'
                AND actor = :developer
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY actor
        """,
        parameters=["developer", "start_date", "end_date"],
        example_question="What's the average PR size for Mike?"
    ),

    QueryTemplate(
        id="dev_cross_system_activity",
        category="developer",
        name="Cross-System Activity",
        description="Activity across all systems for a developer",
        keywords=["all activity", "cross system", "everything", "overview"],
        sql_template="""
            SELECT
                source,
                event_type,
                COUNT(*) as activity_count
            FROM unified_events
            WHERE actor = :developer
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY source, event_type
            ORDER BY activity_count DESC
        """,
        parameters=["developer", "start_date", "end_date"],
        example_question="Show me all of Lisa's activity across systems"
    ),

    QueryTemplate(
        id="dev_busiest_days",
        category="developer",
        name="Busiest Days",
        description="Days with most activity for a developer",
        keywords=["busiest", "most active", "peak days", "busy"],
        sql_template="""
            SELECT
                event_date,
                COUNT(*) as activity_count,
                COUNT(DISTINCT event_type) as event_types
            FROM unified_events
            WHERE actor = :developer
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY event_date
            ORDER BY activity_count DESC
            LIMIT 10
        """,
        parameters=["developer", "start_date", "end_date"],
        example_question="What were David's busiest days this month?"
    ),

    QueryTemplate(
        id="dev_support_tickets_handled",
        category="developer",
        name="Support Tickets Handled",
        description="Support tickets resolved by a developer",
        keywords=["support", "tickets", "freshdesk", "customer issues"],
        sql_template="""
            SELECT
                actor as developer,
                COUNT(*) as tickets_resolved,
                AVG(duration_seconds) / 3600.0 as avg_hours_per_ticket
            FROM unified_events
            WHERE source = 'freshdesk'
                AND event_type = 'ticket_resolved'
                AND actor = :developer
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY actor
        """,
        parameters=["developer", "start_date", "end_date"],
        example_question="How many support tickets did Rachel handle?"
    ),
]


# ============================================
# TEAM PERFORMANCE METRICS (12 queries)
# ============================================

TEAM_QUERIES = [
    QueryTemplate(
        id="team_pr_velocity",
        category="team",
        name="Team PR Velocity",
        description="PRs created and merged by the team over time",
        keywords=["team", "velocity", "throughput", "pr", "merged"],
        sql_template="""
            SELECT
                event_date,
                COUNT(CASE WHEN event_type = 'pr_created' THEN 1 END) as created,
                COUNT(CASE WHEN event_type = 'pr_merged' THEN 1 END) as merged
            FROM unified_events
            WHERE source = 'github'
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY event_date
            ORDER BY event_date
        """,
        parameters=["start_date", "end_date"],
        example_question="What's our team's PR velocity this sprint?"
    ),

    QueryTemplate(
        id="team_commit_trends",
        category="team",
        name="Team Commit Trends",
        description="Daily commit activity across the team",
        keywords=["team", "commits", "trends", "daily activity"],
        sql_template="""
            SELECT
                event_date,
                COUNT(*) as commit_count,
                COUNT(DISTINCT actor) as active_developers,
                SUM(change_volume) as total_lines_changed
            FROM unified_events
            WHERE event_type = 'commit'
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY event_date
            ORDER BY event_date
        """,
        parameters=["start_date", "end_date"],
        example_question="Show me our team's commit trends this month"
    ),

    QueryTemplate(
        id="team_top_contributors",
        category="team",
        name="Top Contributors",
        description="Most active developers by activity count",
        keywords=["top", "most active", "contributors", "leaderboard"],
        sql_template="""
            SELECT
                actor as developer,
                COUNT(*) as total_activities,
                COUNT(DISTINCT event_type) as activity_types,
                COUNT(DISTINCT source) as systems_used
            FROM unified_events
            WHERE event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY actor
            ORDER BY total_activities DESC
            LIMIT 10
        """,
        parameters=["start_date", "end_date"],
        example_question="Who are our top contributors this quarter?"
    ),

    QueryTemplate(
        id="team_issue_burndown",
        category="team",
        name="Issue Burndown",
        description="Issues created vs resolved over time",
        keywords=["burndown", "issues", "backlog", "resolved vs created"],
        sql_template="""
            SELECT
                event_date,
                COUNT(CASE WHEN event_type IN ('issue_created', 'ticket_created') THEN 1 END) as created,
                COUNT(CASE WHEN event_type IN ('issue_closed', 'ticket_resolved') THEN 1 END) as resolved
            FROM unified_events
            WHERE source IN ('github', 'jira', 'freshdesk')
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY event_date
            ORDER BY event_date
        """,
        parameters=["start_date", "end_date"],
        example_question="Show me our issue burndown chart"
    ),

    QueryTemplate(
        id="team_sprint_completion",
        category="team",
        name="Sprint Completion Rate",
        description="Sprint work completion metrics",
        keywords=["sprint", "completion", "velocity", "story points"],
        sql_template="""
            SELECT
                json_extract(metadata, '$.sprint_name') as sprint,
                COUNT(CASE WHEN event_type = 'issue_created' THEN 1 END) as planned,
                COUNT(CASE WHEN event_type = 'issue_closed' THEN 1 END) as completed,
                ROUND(100.0 * COUNT(CASE WHEN event_type = 'issue_closed' THEN 1 END) /
                    NULLIF(COUNT(CASE WHEN event_type = 'issue_created' THEN 1 END), 0), 2) as completion_rate
            FROM unified_events
            WHERE source = 'jira'
                AND json_extract(metadata, '$.sprint_name') IS NOT NULL
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY json_extract(metadata, '$.sprint_name')
        """,
        parameters=["start_date", "end_date"],
        example_question="What's our sprint completion rate?"
    ),

    QueryTemplate(
        id="team_cycle_time",
        category="team",
        name="Average Cycle Time",
        description="Time from issue creation to resolution",
        keywords=["cycle time", "lead time", "duration", "time to resolve"],
        sql_template="""
            WITH issue_lifecycle AS (
                SELECT
                    work_item_id,
                    MIN(CASE WHEN event_type IN ('issue_created', 'ticket_created') THEN event_timestamp END) as created_at,
                    MAX(CASE WHEN event_type IN ('issue_closed', 'ticket_resolved') THEN event_timestamp END) as resolved_at
                FROM unified_events
                WHERE event_date >= :start_date
                    AND event_date <= :end_date
                GROUP BY work_item_id
            )
            SELECT
                AVG((julianday(resolved_at) - julianday(created_at)) * 24) as avg_hours,
                MIN((julianday(resolved_at) - julianday(created_at)) * 24) as min_hours,
                MAX((julianday(resolved_at) - julianday(created_at)) * 24) as max_hours
            FROM issue_lifecycle
            WHERE resolved_at IS NOT NULL
        """,
        parameters=["start_date", "end_date"],
        example_question="What's our average cycle time?"
    ),

    QueryTemplate(
        id="team_pr_review_time",
        category="team",
        name="PR Review Time",
        description="Average time to review and merge PRs",
        keywords=["pr review", "review time", "merge time"],
        sql_template="""
            WITH pr_lifecycle AS (
                SELECT
                    work_item_id,
                    MIN(CASE WHEN event_type = 'pr_created' THEN event_timestamp END) as created_at,
                    MAX(CASE WHEN event_type = 'pr_merged' THEN event_timestamp END) as merged_at
                FROM unified_events
                WHERE source = 'github'
                    AND event_date >= :start_date
                    AND event_date <= :end_date
                GROUP BY work_item_id
            )
            SELECT
                AVG((julianday(merged_at) - julianday(created_at)) * 24) as avg_hours_to_merge,
                COUNT(*) as total_prs_merged
            FROM pr_lifecycle
            WHERE merged_at IS NOT NULL
        """,
        parameters=["start_date", "end_date"],
        example_question="How long does it take to review PRs?"
    ),

    QueryTemplate(
        id="team_workload_distribution",
        category="team",
        name="Workload Distribution",
        description="Distribution of work across team members",
        keywords=["workload", "distribution", "balance", "assigned"],
        sql_template="""
            SELECT
                assignee,
                COUNT(*) as assigned_items,
                COUNT(DISTINCT source) as systems,
                SUM(duration_seconds) / 3600.0 as hours_logged
            FROM unified_events
            WHERE assignee IS NOT NULL
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY assignee
            ORDER BY assigned_items DESC
        """,
        parameters=["start_date", "end_date"],
        example_question="How is work distributed across the team?"
    ),

    QueryTemplate(
        id="team_collaboration_score",
        category="team",
        name="Team Collaboration Score",
        description="PR reviews and collaborative activities",
        keywords=["collaboration", "teamwork", "reviews", "pair"],
        sql_template="""
            SELECT
                COUNT(CASE WHEN event_type = 'pr_reviewed' THEN 1 END) as reviews_given,
                COUNT(DISTINCT actor) as reviewers,
                COUNT(DISTINCT work_item_id) as prs_reviewed
            FROM unified_events
            WHERE source = 'github'
                AND event_type = 'pr_reviewed'
                AND event_date >= :start_date
                AND event_date <= :end_date
        """,
        parameters=["start_date", "end_date"],
        example_question="How collaborative is our team?"
    ),

    QueryTemplate(
        id="team_ai_adoption",
        category="team",
        name="AI Tool Adoption",
        description="Team-wide AI coding assistant usage",
        keywords=["ai adoption", "windsurf", "ai usage", "team ai"],
        sql_template="""
            SELECT
                actor,
                SUM(CASE WHEN metadata->>'metric_type' = 'autocomplete_accepted'
                    THEN CAST(metadata->>'value' AS INTEGER) ELSE 0 END) as autocomplete_uses,
                SUM(CASE WHEN metadata->>'metric_type' = 'chat_messages'
                    THEN CAST(metadata->>'value' AS INTEGER) ELSE 0 END) as ai_chats
            FROM unified_events
            WHERE source = 'windsurf'
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY actor
            ORDER BY autocomplete_uses DESC
        """,
        parameters=["start_date", "end_date"],
        example_question="How is our team adopting AI tools?"
    ),

    QueryTemplate(
        id="team_blockers",
        category="team",
        name="Blocked Items",
        description="Items marked as blocked or stalled",
        keywords=["blocked", "blockers", "stuck", "stalled"],
        sql_template="""
            SELECT
                work_item_id,
                work_item_title,
                assignee,
                event_date as blocked_since,
                source
            FROM unified_events
            WHERE work_item_status = 'blocked'
                AND event_date >= :start_date
                AND event_date <= :end_date
            ORDER BY event_date
        """,
        parameters=["start_date", "end_date"],
        example_question="What items are currently blocked?"
    ),

    QueryTemplate(
        id="team_support_load",
        category="team",
        name="Support Ticket Load",
        description="Support ticket volume and response metrics",
        keywords=["support", "tickets", "freshdesk", "customer"],
        sql_template="""
            SELECT
                event_date,
                COUNT(CASE WHEN event_type = 'ticket_created' THEN 1 END) as created,
                COUNT(CASE WHEN event_type = 'ticket_resolved' THEN 1 END) as resolved,
                COUNT(DISTINCT actor) as agents_active
            FROM unified_events
            WHERE source = 'freshdesk'
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY event_date
            ORDER BY event_date
        """,
        parameters=["start_date", "end_date"],
        example_question="What's our support ticket load?"
    ),
]


# ============================================
# CROSS-SYSTEM INSIGHTS (8 queries)
# ============================================

CROSS_SYSTEM_QUERIES = [
    QueryTemplate(
        id="cross_code_to_ticket",
        category="cross_system",
        name="Code to Ticket Linking",
        description="Developers working on both code and tickets",
        keywords=["code and tickets", "dev and support", "cross system"],
        sql_template="""
            SELECT
                actor,
                COUNT(CASE WHEN source = 'github' THEN 1 END) as github_events,
                COUNT(CASE WHEN source IN ('jira', 'freshdesk') THEN 1 END) as ticket_events
            FROM unified_events
            WHERE event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY actor
            HAVING github_events > 0 AND ticket_events > 0
            ORDER BY (github_events + ticket_events) DESC
        """,
        parameters=["start_date", "end_date"],
        example_question="Who's working on both code and support tickets?"
    ),

    QueryTemplate(
        id="cross_bug_fix_correlation",
        category="cross_system",
        name="Bug Fixes vs Support Tickets",
        description="Correlation between bugs and support volume",
        keywords=["bugs", "support correlation", "bug fixes", "tickets"],
        sql_template="""
            SELECT
                event_date,
                COUNT(CASE WHEN source = 'jira' AND json_extract(metadata, '$.issue_type') = 'Bug' THEN 1 END) as bugs,
                COUNT(CASE WHEN source = 'freshdesk' AND event_type = 'ticket_created' THEN 1 END) as support_tickets
            FROM unified_events
            WHERE event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY event_date
            ORDER BY event_date
        """,
        parameters=["start_date", "end_date"],
        example_question="Is there correlation between bugs and support tickets?"
    ),

    QueryTemplate(
        id="cross_deployment_impact",
        category="cross_system",
        name="Deployment Impact on Support",
        description="Support ticket trends around deployment dates",
        keywords=["deployment", "release", "support impact"],
        sql_template="""
            SELECT
                event_date,
                COUNT(CASE WHEN source = 'github' AND event_type = 'pr_merged' THEN 1 END) as deployments,
                COUNT(CASE WHEN source = 'freshdesk' AND event_type = 'ticket_created' THEN 1 END) as new_tickets
            FROM unified_events
            WHERE event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY event_date
            ORDER BY event_date
        """,
        parameters=["start_date", "end_date"],
        example_question="How do deployments affect support tickets?"
    ),

    QueryTemplate(
        id="cross_ai_code_quality",
        category="cross_system",
        name="AI Usage vs Code Quality",
        description="AI tool usage correlation with PR metrics",
        keywords=["ai", "code quality", "windsurf", "pr"],
        sql_template="""
            SELECT
                e1.actor,
                COUNT(CASE WHEN e1.source = 'windsurf' THEN 1 END) as ai_events,
                COUNT(CASE WHEN e1.source = 'github' AND e1.event_type = 'pr_created' THEN 1 END) as prs_created,
                AVG(CASE WHEN e1.source = 'github' AND e1.event_type = 'pr_created' THEN e1.change_volume END) as avg_pr_size
            FROM unified_events e1
            WHERE e1.event_date >= :start_date
                AND e1.event_date <= :end_date
            GROUP BY e1.actor
            HAVING ai_events > 0 AND prs_created > 0
        """,
        parameters=["start_date", "end_date"],
        example_question="Does AI usage affect code quality?"
    ),

    QueryTemplate(
        id="cross_work_handoffs",
        category="cross_system",
        name="Work Handoffs Between Systems",
        description="Work items transitioning between systems",
        keywords=["handoff", "transition", "system change"],
        sql_template="""
            SELECT
                work_item_id,
                work_item_title,
                actor,
                GROUP_CONCAT(DISTINCT source) as systems_touched,
                COUNT(DISTINCT source) as system_count
            FROM unified_events
            WHERE event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY work_item_id, work_item_title, actor
            HAVING system_count > 1
            ORDER BY system_count DESC
        """,
        parameters=["start_date", "end_date"],
        example_question="Which work items span multiple systems?"
    ),

    QueryTemplate(
        id="cross_developer_context_switching",
        category="cross_system",
        name="Developer Context Switching",
        description="How often developers switch between systems",
        keywords=["context switch", "multitasking", "system hopping"],
        sql_template="""
            WITH system_changes AS (
                SELECT
                    actor,
                    event_date,
                    source,
                    LAG(source) OVER (PARTITION BY actor ORDER BY event_timestamp) as prev_source
                FROM unified_events
                WHERE event_date >= :start_date
                    AND event_date <= :end_date
            )
            SELECT
                actor,
                COUNT(CASE WHEN source != prev_source THEN 1 END) as context_switches,
                COUNT(DISTINCT source) as systems_used
            FROM system_changes
            GROUP BY actor
            ORDER BY context_switches DESC
        """,
        parameters=["start_date", "end_date"],
        example_question="Who's context switching the most?"
    ),

    QueryTemplate(
        id="cross_feature_delivery_flow",
        category="cross_system",
        name="Feature Delivery Flow",
        description="End-to-end feature flow: ticket -> code -> deployment",
        keywords=["feature flow", "end to end", "delivery pipeline"],
        sql_template="""
            SELECT
                json_extract(metadata, '$.feature_id') as feature,
                MIN(CASE WHEN event_type = 'issue_created' THEN event_timestamp END) as started,
                MAX(CASE WHEN event_type = 'pr_merged' THEN event_timestamp END) as deployed,
                COUNT(DISTINCT actor) as people_involved,
                COUNT(DISTINCT source) as systems_touched
            FROM unified_events
            WHERE json_extract(metadata, '$.feature_id') IS NOT NULL
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY json_extract(metadata, '$.feature_id')
        """,
        parameters=["start_date", "end_date"],
        example_question="Show me feature delivery flow"
    ),

    QueryTemplate(
        id="cross_system_health",
        category="cross_system",
        name="Overall System Health",
        description="Activity levels across all systems",
        keywords=["system health", "activity levels", "overview"],
        sql_template="""
            SELECT
                source,
                COUNT(*) as total_events,
                COUNT(DISTINCT actor) as active_users,
                COUNT(DISTINCT event_date) as active_days
            FROM unified_events
            WHERE event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY source
            ORDER BY total_events DESC
        """,
        parameters=["start_date", "end_date"],
        example_question="How healthy are our systems?"
    ),
]


# ============================================
# TIME-BASED TRENDS (8 queries)
# ============================================

TREND_QUERIES = [
    QueryTemplate(
        id="trend_weekly_summary",
        category="trends",
        name="Weekly Activity Summary",
        description="Week-over-week activity comparison",
        keywords=["weekly", "week over week", "trends"],
        sql_template="""
            SELECT
                strftime('%Y-W%W', event_date) as week,
                COUNT(*) as total_activities,
                COUNT(DISTINCT actor) as active_developers,
                COUNT(DISTINCT work_item_id) as work_items
            FROM unified_events
            WHERE event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY strftime('%Y-W%W', event_date)
            ORDER BY week
        """,
        parameters=["start_date", "end_date"],
        example_question="Show me weekly activity trends"
    ),

    QueryTemplate(
        id="trend_monthly_velocity",
        category="trends",
        name="Monthly Velocity Trends",
        description="Monthly throughput and completion metrics",
        keywords=["monthly", "velocity", "throughput", "trends"],
        sql_template="""
            SELECT
                strftime('%Y-%m', event_date) as month,
                COUNT(CASE WHEN event_type = 'pr_merged' THEN 1 END) as prs_merged,
                COUNT(CASE WHEN event_type IN ('issue_closed', 'ticket_resolved') THEN 1 END) as items_completed,
                COUNT(DISTINCT actor) as active_people
            FROM unified_events
            WHERE event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY strftime('%Y-%m', event_date)
            ORDER BY month
        """,
        parameters=["start_date", "end_date"],
        example_question="What's our monthly velocity trend?"
    ),

    QueryTemplate(
        id="trend_day_of_week",
        category="trends",
        name="Activity by Day of Week",
        description="Which days are most productive",
        keywords=["day of week", "weekday", "productivity"],
        sql_template="""
            SELECT
                CASE CAST(strftime('%w', event_date) AS INTEGER)
                    WHEN 0 THEN 'Sunday'
                    WHEN 1 THEN 'Monday'
                    WHEN 2 THEN 'Tuesday'
                    WHEN 3 THEN 'Wednesday'
                    WHEN 4 THEN 'Thursday'
                    WHEN 5 THEN 'Friday'
                    WHEN 6 THEN 'Saturday'
                END as day_of_week,
                COUNT(*) as activity_count,
                AVG(change_volume) as avg_change_size
            FROM unified_events
            WHERE event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY strftime('%w', event_date)
            ORDER BY strftime('%w', event_date)
        """,
        parameters=["start_date", "end_date"],
        example_question="Which day of the week are we most productive?"
    ),

    QueryTemplate(
        id="trend_growth_rate",
        category="trends",
        name="Activity Growth Rate",
        description="Growth/decline in activity over time",
        keywords=["growth", "decline", "trend", "increasing"],
        sql_template="""
            WITH weekly_counts AS (
                SELECT
                    strftime('%Y-W%W', event_date) as week,
                    COUNT(*) as activity_count
                FROM unified_events
                WHERE event_date >= :start_date
                    AND event_date <= :end_date
                GROUP BY strftime('%Y-W%W', event_date)
            )
            SELECT
                week,
                activity_count,
                LAG(activity_count) OVER (ORDER BY week) as prev_week_count,
                ROUND(100.0 * (activity_count - LAG(activity_count) OVER (ORDER BY week)) /
                    NULLIF(LAG(activity_count) OVER (ORDER BY week), 0), 2) as growth_rate_pct
            FROM weekly_counts
            ORDER BY week
        """,
        parameters=["start_date", "end_date"],
        example_question="Is our activity increasing or decreasing?"
    ),

    QueryTemplate(
        id="trend_sprint_over_sprint",
        category="trends",
        name="Sprint-over-Sprint Comparison",
        description="Compare sprint performance over time",
        keywords=["sprint", "sprint comparison", "sprint trends"],
        sql_template="""
            SELECT
                json_extract(metadata, '$.sprint_name') as sprint,
                COUNT(CASE WHEN event_type = 'issue_closed' THEN 1 END) as completed,
                SUM(CASE WHEN json_extract(metadata, '$.story_points') IS NOT NULL
                    THEN CAST(json_extract(metadata, '$.story_points') AS INTEGER) ELSE 0 END) as story_points
            FROM unified_events
            WHERE source = 'jira'
                AND json_extract(metadata, '$.sprint_name') IS NOT NULL
                AND event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY json_extract(metadata, '$.sprint_name')
            ORDER BY sprint
        """,
        parameters=["start_date", "end_date"],
        example_question="Compare sprint performance over time"
    ),

    QueryTemplate(
        id="trend_issue_age",
        category="trends",
        name="Issue Age Distribution",
        description="How long issues stay open",
        keywords=["issue age", "open duration", "stale"],
        sql_template="""
            WITH issue_ages AS (
                SELECT
                    work_item_id,
                    MIN(CASE WHEN event_type IN ('issue_created', 'ticket_created') THEN event_timestamp END) as created_at,
                    MAX(CASE WHEN event_type IN ('issue_closed', 'ticket_resolved') THEN event_timestamp END) as resolved_at,
                    COALESCE(MAX(CASE WHEN event_type IN ('issue_closed', 'ticket_resolved') THEN event_timestamp END),
                        datetime('now')) as end_time
                FROM unified_events
                WHERE event_date >= :start_date
                    AND event_date <= :end_date
                GROUP BY work_item_id
            )
            SELECT
                CASE
                    WHEN (julianday(end_time) - julianday(created_at)) <= 1 THEN '0-1 days'
                    WHEN (julianday(end_time) - julianday(created_at)) <= 7 THEN '1-7 days'
                    WHEN (julianday(end_time) - julianday(created_at)) <= 30 THEN '1-4 weeks'
                    ELSE '1+ months'
                END as age_bucket,
                COUNT(*) as issue_count
            FROM issue_ages
            WHERE created_at IS NOT NULL
            GROUP BY age_bucket
        """,
        parameters=["start_date", "end_date"],
        example_question="How long do issues stay open?"
    ),

    QueryTemplate(
        id="trend_peak_hours",
        category="trends",
        name="Peak Activity Hours",
        description="What time of day is most active",
        keywords=["peak hours", "time of day", "hourly"],
        sql_template="""
            SELECT
                strftime('%H', event_timestamp) as hour,
                COUNT(*) as activity_count
            FROM unified_events
            WHERE event_date >= :start_date
                AND event_date <= :end_date
            GROUP BY strftime('%H', event_timestamp)
            ORDER BY hour
        """,
        parameters=["start_date", "end_date"],
        example_question="What are our peak activity hours?"
    ),

    QueryTemplate(
        id="trend_forecast",
        category="trends",
        name="Simple Forecast",
        description="Project next period activity based on trends",
        keywords=["forecast", "prediction", "projection"],
        sql_template="""
            WITH recent_avg AS (
                SELECT
                    AVG(daily_count) as avg_daily_activity
                FROM (
                    SELECT
                        event_date,
                        COUNT(*) as daily_count
                    FROM unified_events
                    WHERE event_date >= :start_date
                        AND event_date <= :end_date
                    GROUP BY event_date
                )
            )
            SELECT
                avg_daily_activity,
                avg_daily_activity * 7 as projected_weekly,
                avg_daily_activity * 30 as projected_monthly
            FROM recent_avg
        """,
        parameters=["start_date", "end_date"],
        example_question="What's the forecast for next month?"
    ),
]


# Combine all queries
ALL_QUERIES = DEVELOPER_QUERIES + TEAM_QUERIES + CROSS_SYSTEM_QUERIES + TREND_QUERIES


def get_query_by_id(query_id: str) -> Optional[QueryTemplate]:
    """Get a specific query template by ID"""
    for query in ALL_QUERIES:
        if query.id == query_id:
            return query
    return None


def get_queries_by_category(category: str) -> List[QueryTemplate]:
    """Get all queries in a category"""
    return [q for q in ALL_QUERIES if q.category == category]


def search_queries(keywords: List[str]) -> List[QueryTemplate]:
    """Search queries by keywords"""
    matches = []
    for query in ALL_QUERIES:
        for keyword in keywords:
            if any(keyword.lower() in qk.lower() for qk in query.keywords):
                matches.append(query)
                break
    return matches
