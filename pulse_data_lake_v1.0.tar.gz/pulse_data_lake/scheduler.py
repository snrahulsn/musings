"""Scheduler for automated data ingestion"""

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
import structlog

from db.database import get_db
from config.settings import get_settings
from ingest.github_poller import GitHubPoller
from ingest.jira_poller import JiraPoller
from ingest.freshdesk_poller import FreshdeskPoller
from ingest.windsurf_poller import WindsurfPoller

logger = structlog.get_logger()


def setup_scheduler():
    """Setup and start the polling scheduler"""
    config = get_settings()
    db = get_db()
    scheduler = BackgroundScheduler()

    # GitHub polling
    if config.sources.github and config.sources.github.enabled:
        github_poller = GitHubPoller(db, config.sources.github.dict())
        scheduler.add_job(
            func=github_poller.poll,
            trigger=IntervalTrigger(minutes=config.sources.github.poll_interval_minutes),
            id="github_poll",
            name="GitHub Data Sync",
            replace_existing=True
        )
        logger.info("github_scheduler_added", interval=config.sources.github.poll_interval_minutes)

    # JIRA polling
    if config.sources.jira and config.sources.jira.enabled:
        jira_poller = JiraPoller(db, config.sources.jira.dict())
        scheduler.add_job(
            func=jira_poller.poll,
            trigger=IntervalTrigger(minutes=config.sources.jira.poll_interval_minutes),
            id="jira_poll",
            name="JIRA Data Sync",
            replace_existing=True
        )
        logger.info("jira_scheduler_added", interval=config.sources.jira.poll_interval_minutes)

    # Freshdesk polling
    if config.sources.freshdesk and config.sources.freshdesk.enabled:
        freshdesk_poller = FreshdeskPoller(db, config.sources.freshdesk.dict())
        scheduler.add_job(
            func=freshdesk_poller.poll,
            trigger=IntervalTrigger(minutes=config.sources.freshdesk.poll_interval_minutes),
            id="freshdesk_poll",
            name="Freshdesk Data Sync",
            replace_existing=True
        )
        logger.info("freshdesk_scheduler_added", interval=config.sources.freshdesk.poll_interval_minutes)

    # Windsurf polling
    if config.sources.windsurf and config.sources.windsurf.enabled:
        windsurf_poller = WindsurfPoller(db, config.sources.windsurf.dict())
        scheduler.add_job(
            func=windsurf_poller.poll,
            trigger=IntervalTrigger(minutes=config.sources.windsurf.poll_interval_minutes),
            id="windsurf_poll",
            name="Windsurf Data Sync",
            replace_existing=True
        )
        logger.info("windsurf_scheduler_added", interval=config.sources.windsurf.poll_interval_minutes)

    scheduler.start()
    logger.info("scheduler_started")
    return scheduler
