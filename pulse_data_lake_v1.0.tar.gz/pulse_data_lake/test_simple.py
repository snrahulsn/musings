#!/usr/bin/env python3
"""Simple test without external dependencies"""

import sys
import os
import sqlite3

sys.path.insert(0, os.path.dirname(__file__))

print("=" * 60)
print("PULSE DATA LAKE - BASIC VALIDATION")
print("=" * 60)

# Test 1: Schema loads without errors
print("\n1. Testing database schema...")
try:
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()
    with open('db/schema.sql') as f:
        cursor.executescript(f.read())

    # Count tables
    cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")
    table_count = cursor.fetchone()[0]
    print(f"   ✅ Schema loaded successfully ({table_count} tables)")

    # Check key tables
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
    tables = [row[0] for row in cursor.fetchall()]

    required_tables = [
        'github_commits', 'github_pull_requests', 'github_issues',
        'jira_issues', 'jira_worklogs', 'jira_status_transitions',
        'freshdesk_tickets', 'freshdesk_conversations', 'freshdesk_time_entries',
        'windsurf_user_activity', 'windsurf_tool_usage',
        'unified_events', 'sync_watermarks', 'person_mapping'
    ]

    for table in required_tables:
        if table in tables:
            print(f"   ✅ {table}")
        else:
            print(f"   ❌ Missing table: {table}")

    conn.close()
except Exception as e:
    print(f"   ❌ Schema test failed: {e}")
    sys.exit(1)

# Test 2: Python files compile
print("\n2. Testing Python syntax...")
modules = [
    'db/database.py',
    'ingest/base.py',
    'ingest/github_poller.py',
    'ingest/jira_poller.py',
    'ingest/freshdesk_poller.py',
    'ingest/windsurf_poller.py',
    'chat/query_bank.py',
    'chat/intent_classifier.py',
    'chat/gpt_fallback.py',
    'api/main.py',
    'config/settings.py',
    'scheduler.py',
    'main.py'
]

all_compile = True
for module in modules:
    try:
        with open(module) as f:
            compile(f.read(), module, 'exec')
        print(f"   ✅ {module}")
    except Exception as e:
        print(f"   ❌ {module}: {e}")
        all_compile = False

if not all_compile:
    sys.exit(1)

# Test 3: Query bank structure
print("\n3. Testing query bank...")
try:
    with open('chat/query_bank.py') as f:
        code = f.read()

    # Check for key patterns
    if 'QueryTemplate' in code:
        print("   ✅ QueryTemplate dataclass defined")
    if 'DEVELOPER_QUERIES' in code:
        print("   ✅ Developer queries defined")
    if 'TEAM_QUERIES' in code:
        print("   ✅ Team queries defined")
    if 'CROSS_SYSTEM_QUERIES' in code:
        print("   ✅ Cross-system queries defined")
    if 'TREND_QUERIES' in code:
        print("   ✅ Trend queries defined")
    if 'ALL_QUERIES' in code:
        print("   ✅ ALL_QUERIES collection defined")

except Exception as e:
    print(f"   ❌ Query bank test failed: {e}")
    sys.exit(1)

# Test 4: Configuration files exist
print("\n4. Testing configuration...")
files_to_check = [
    ('config/config.example.yaml', 'Example config'),
    ('requirements.txt', 'Dependencies'),
    ('DEPLOYMENT_GUIDE.md', 'Deployment guide'),
    ('README.md', 'README'),
    ('COMPREHENSIVE_DATA_FETCHING.md', 'Data fetching docs')
]

for file_path, description in files_to_check:
    if os.path.exists(file_path):
        print(f"   ✅ {description}: {file_path}")
    else:
        print(f"   ⚠️  Missing {description}: {file_path}")

print("\n" + "=" * 60)
print("🎉 ALL BASIC TESTS PASSED")
print("=" * 60)
print("\nNext steps:")
print("1. Copy config/config.example.yaml to config/config.yaml")
print("2. Fill in your API credentials")
print("3. Run: python3 main.py")
print("=" * 60)
