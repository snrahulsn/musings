"""
Configuration management using Pydantic
Loads from config.yaml and environment variables
"""

from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings
import yaml
from pathlib import Path
import os


class DatabaseConfig(BaseModel):
    """Database configuration"""
    path: str = "pulse_data.db"


class GitHubConfig(BaseModel):
    """GitHub API configuration"""
    enabled: bool = True
    token: str
    repos: List[str] = []
    poll_interval_minutes: int = 30


class JiraConfig(BaseModel):
    """JIRA API configuration"""
    enabled: bool = True
    base_url: str
    email: str
    api_token: str
    projects: List[str] = []
    poll_interval_minutes: int = 30


class FreshdeskConfig(BaseModel):
    """Freshdesk API configuration"""
    enabled: bool = True
    domain: str
    api_key: str
    poll_interval_minutes: int = 30


class WindsurfConfig(BaseModel):
    """Windsurf Analytics API configuration"""
    enabled: bool = False
    api_url: str = "https://server.codeium.com/api/v1"
    service_key: str = ""
    team_id: str = ""
    poll_interval_minutes: int = 60


class SourcesConfig(BaseModel):
    """All data source configurations"""
    github: Optional[GitHubConfig] = None
    jira: Optional[JiraConfig] = None
    freshdesk: Optional[FreshdeskConfig] = None
    windsurf: Optional[WindsurfConfig] = None


class LLMConfig(BaseModel):
    """LLM fallback configuration"""
    provider: str = "openai"
    model: str = "gpt-4o"
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    enabled: bool = True


class QueryConfig(BaseModel):
    """Query engine configuration"""
    intent_classifier_threshold: int = 30
    default_time_range_days: int = 30


class APIConfig(BaseModel):
    """API server configuration"""
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False


class LoggingConfig(BaseModel):
    """Logging configuration"""
    level: str = "INFO"
    format: str = "json"


class Settings(BaseSettings):
    """Main application settings"""
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    sources: SourcesConfig = Field(default_factory=SourcesConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    query: QueryConfig = Field(default_factory=QueryConfig)
    api: APIConfig = Field(default_factory=APIConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        env_nested_delimiter = "__"

    @classmethod
    def load_from_yaml(cls, config_path: str = "config/config.yaml") -> "Settings":
        """Load settings from YAML file"""
        config_file = Path(config_path)

        if not config_file.exists():
            # Try to use example config
            example_config = Path("config/config.example.yaml")
            if example_config.exists():
                print(f"Warning: {config_path} not found. Please copy config.example.yaml to config.yaml")
                print("Using example config for now (API keys will be missing)")
                config_file = example_config
            else:
                raise FileNotFoundError(f"Config file not found: {config_path}")

        with open(config_file, 'r') as f:
            config_data = yaml.safe_load(f)

        # Override with environment variables if present
        config_data = cls._override_from_env(config_data)

        return cls(**config_data)

    @classmethod
    def _override_from_env(cls, config_data: Dict[str, Any]) -> Dict[str, Any]:
        """Override config values with environment variables"""
        # GitHub token
        if os.getenv("GITHUB_TOKEN"):
            if "sources" not in config_data:
                config_data["sources"] = {}
            if "github" not in config_data["sources"]:
                config_data["sources"]["github"] = {}
            config_data["sources"]["github"]["token"] = os.getenv("GITHUB_TOKEN")

        # JIRA token
        if os.getenv("JIRA_API_TOKEN"):
            if "sources" not in config_data:
                config_data["sources"] = {}
            if "jira" not in config_data["sources"]:
                config_data["sources"]["jira"] = {}
            config_data["sources"]["jira"]["api_token"] = os.getenv("JIRA_API_TOKEN")

        # Freshdesk API key
        if os.getenv("FRESHDESK_API_KEY"):
            if "sources" not in config_data:
                config_data["sources"] = {}
            if "freshdesk" not in config_data["sources"]:
                config_data["sources"]["freshdesk"] = {}
            config_data["sources"]["freshdesk"]["api_key"] = os.getenv("FRESHDESK_API_KEY")

        # Windsurf service key
        if os.getenv("WINDSURF_SERVICE_KEY"):
            if "sources" not in config_data:
                config_data["sources"] = {}
            if "windsurf" not in config_data["sources"]:
                config_data["sources"]["windsurf"] = {}
            config_data["sources"]["windsurf"]["service_key"] = os.getenv("WINDSURF_SERVICE_KEY")

        # OpenAI API key
        if os.getenv("OPENAI_API_KEY"):
            if "llm" not in config_data:
                config_data["llm"] = {}
            config_data["llm"]["api_key"] = os.getenv("OPENAI_API_KEY")

        return config_data


# Global settings instance
_settings: Optional[Settings] = None


def get_settings(config_path: str = "config/config.yaml") -> Settings:
    """Get or create global settings instance"""
    global _settings
    if _settings is None:
        _settings = Settings.load_from_yaml(config_path)
    return _settings


def reload_settings(config_path: str = "config/config.yaml") -> Settings:
    """Force reload settings from config file"""
    global _settings
    _settings = Settings.load_from_yaml(config_path)
    return _settings
