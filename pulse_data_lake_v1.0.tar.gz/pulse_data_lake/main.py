"""Main entry point for Pulse Data Lake"""

import uvicorn
import structlog
import sys

from config.settings import get_settings
from db.database import init_db
from scheduler import setup_scheduler

logger = structlog.get_logger()


def main():
    """Start the application"""
    logger.info("pulse_data_lake_starting")

    try:
        # Load configuration
        config = get_settings()
        logger.info("config_loaded")

        # Initialize database
        init_db(config.database.path)
        logger.info("database_initialized")

        # Start background scheduler
        scheduler = setup_scheduler()
        logger.info("scheduler_initialized")

        # Start API server
        logger.info("starting_api_server", host=config.api.host, port=config.api.port)
        uvicorn.run(
            "api.main:app",
            host=config.api.host,
            port=config.api.port,
            reload=config.api.debug,
            log_level="info"
        )

    except KeyboardInterrupt:
        logger.info("shutting_down")
        sys.exit(0)
    except Exception as e:
        logger.error("startup_failed", error=str(e))
        sys.exit(1)


if __name__ == "__main__":
    main()
